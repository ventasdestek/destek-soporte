// ============================================================
// CONSTANTES DE LA APLICACIÓN
// ============================================================

// Configuración de la empresa (valores por defecto, se sobrescriben con DB)
export const COMPANY_CONFIG = {
  name: 'Destek Soporte',
  tagline: 'Tecnología que impulsa tu negocio',
  email: 'contacto@desteksoporte.com',
  phone: '+34 600 000 000',
  whatsapp: '34600000000',
  address: 'Calle Ejemplo 123, 28001 Madrid, España',
  whatsappMessage: 'Hola, me gustaría más información sobre sus servicios.',
} as const

// Redes sociales
export const SOCIAL_LINKS = {
  facebook: 'https://facebook.com',
  twitter: 'https://twitter.com',
  linkedin: 'https://linkedin.com',
  instagram: 'https://instagram.com',
  youtube: 'https://youtube.com',
} as const

// Modalidades de servicio
export const SERVICE_MODALITIES = [
  { value: 'online', label: 'Online', icon: 'monitor' },
  { value: 'presencial', label: 'Presencial', icon: 'map-pin' },
  { value: 'hibrido', label: 'Híbrido', icon: 'cpu' },
] as const

// Estados de pedido
export const ORDER_STATUSES = [
  { value: 'pendiente', label: 'Pendiente', color: 'yellow', icon: 'clock' },
  { value: 'procesando', label: 'Procesando', color: 'blue', icon: 'loader' },
  { value: 'completado', label: 'Completado', color: 'green', icon: 'check-circle' },
  { value: 'cancelado', label: 'Cancelado', color: 'red', icon: 'x-circle' },
  { value: 'reembolsado', label: 'Reembolsado', color: 'gray', icon: 'rotate-ccw' },
] as const

// Roles de usuario
export const USER_ROLES = [
  { value: 'admin', label: 'Administrador', color: 'purple' },
  { value: 'cliente', label: 'Cliente', color: 'blue' },
] as const

// Categorías por defecto (para formularios antes de cargar BD)
export const DEFAULT_CATEGORIES = [
  { id: '1', nombre: 'Sistemas / Software' },
  { id: '2', nombre: 'Cámaras de seguridad (CCTV)' },
  { id: '3', nombre: 'Accesorios / Hardware' },
  { id: '4', nombre: 'Redes y Conectividad' },
  { id: '5', nombre: 'Servicios Profesionales' },
] as const

// Paginación
export const PAGINATION = {
  defaultPageSize: 10,
  pageSizeOptions: [5, 10, 20, 50],
} as const

// Configuración de imágenes
export const IMAGE_CONFIG = {
  maxSize: 5 * 1024 * 1024, // 5MB
  allowedTypes: ['image/jpeg', 'image/png', 'image/webp', 'image/gif'],
  thumbnailSizes: {
    small: { width: 150, height: 150 },
    medium: { width: 300, height: 300 },
    large: { width: 600, height: 600 },
  },
} as const

// SEO por defecto
export const DEFAULT_SEO = {
  title: 'Destek Soporte | Servicios Tecnológicos, Soporte y Desarrollo',
  description: 'Empresa de servicios tecnológicos: asesoría, soporte remoto, desarrollo de software a medida y venta de hardware. ¡Contáctanos!',
  ogImage: '/images/og-default.jpg',
  twitterHandle: '@desteksoporte',
} as const

// Rutas de la aplicación
export const ROUTES = {
  // Públicas
  home: '/',
  inicio: '/',
  servicios: '/servicios',
  productos: '/productos',
  nosotros: '/nosotros',
  contacto: '/contacto',
  login: '/login',
  registro: '/registro',
  recuperarPassword: '/recuperar-password',
  whatsapp: `https://wa.me/${COMPANY_CONFIG.whatsapp}?text=${encodeURIComponent(COMPANY_CONFIG.whatsappMessage)}`,

  // Legal
  privacidad: '/politica-privacidad',
  politicaPrivacidad: '/politica-privacidad',
  terminos: '/aviso-legal',
  avisoLegal: '/aviso-legal',
  cookies: '/politica-cookies',
  politicaCookies: '/politica-cookies',

  // Información / soporte
  blog: '/blog',
  trabajo: '/contacto',
  ayuda: '/contacto',
  faq: '/contacto',
  estado: '/contacto',
  api: '/contacto',
  
  // Privadas (cliente)
  dashboard: '/dashboard',
  perfil: '/dashboard/perfil',
  misSolicitudes: '/dashboard/mis-solicitudes',
  
  // Admin
  admin: '/admin',
  adminServicios: '/admin/servicios',
  adminProductos: '/admin/productos',
  adminCategorias: '/admin/categorias',
  adminUsuarios: '/admin/usuarios',
  adminPedidos: '/admin/pedidos',
  adminMensajes: '/admin/mensajes',
  adminConfiguracion: '/admin/configuracion',
} as const

// Claves de configuración pública
export const PUBLIC_CONFIG_KEYS = [
  'public_hero_title',
  'public_hero_subtitle',
  'public_hero_cta_text',
  'public_hero_cta_link',
  'public_company_logo_url',
  'public_company_name',
  'public_company_tagline',
  'public_contact_email',
  'public_contact_phone',
  'public_contact_whatsapp',
  'public_contact_address',
  'public_social_facebook',
  'public_social_twitter',
  'public_social_linkedin',
  'public_social_instagram',
  'public_social_youtube',
  'public_whatsapp_message',
  'public_seo_title',
  'public_seo_description',
] as const

// Claves de configuración privada (solo admin)
export const PRIVATE_CONFIG_KEYS = [
  'private_admin_email',
] as const