import { z } from 'zod'

// ============================================================
// ESQUEMAS DE VALIDACIÓN - ZOD
// ============================================================

// --- Autenticación ---
export const loginSchema = z.object({
  email: z.string().email('Email inválido'),
  password: z.string().min(6, 'La contraseña debe tener al menos 6 caracteres'),
})

export const registerSchema = z.object({
  nombre: z.string().min(2, 'El nombre debe tener al menos 2 caracteres'),
  apellido: z.string().min(2, 'El apellido debe tener al menos 2 caracteres'),
  email: z.string().email('Email inválido'),
  password: z.string().min(6, 'La contraseña debe tener al menos 6 caracteres'),
  confirmPassword: z.string(),
}).refine((data) => data.password === data.confirmPassword, {
  message: 'Las contraseñas no coinciden',
  path: ['confirmPassword'],
})

export const resetPasswordSchema = z.object({
  email: z.string().email('Email inválido'),
})

export const updatePasswordSchema = z.object({
  password: z.string().min(6, 'La contraseña debe tener al menos 6 caracteres'),
  confirmPassword: z.string(),
}).refine((data) => data.password === data.confirmPassword, {
  message: 'Las contraseñas no coinciden',
  path: ['confirmPassword'],
})

// --- Perfil de usuario ---
export const profileSchema = z.object({
  nombre: z.string().min(2, 'El nombre debe tener al menos 2 caracteres').optional(),
  apellido: z.string().min(2, 'El apellido debe tener al menos 2 caracteres').optional(),
  telefono: z.string().regex(/^[\+]?[(]?[0-9]{3}[)]?[-\s\.]?[0-9]{3}[-\s\.]?[0-9]{4,6}$/, 'Teléfono inválido').optional().or(z.literal('')),
  direccion: z.string().optional(),
})

// --- Contacto ---
export const contactSchema = z.object({
  nombre: z.string().min(2, 'El nombre debe tener al menos 2 caracteres'),
  email: z.string().email('Email inválido'),
  telefono: z.string().regex(/^[\+]?[(]?[0-9]{3}[)]?[-\s\.]?[0-9]{3}[-\s\.]?[0-9]{4,6}$/, 'Teléfono inválido').optional().or(z.literal('')),
  asunto: z.string().min(5, 'El asunto debe tener al menos 5 caracteres').optional(),
  mensaje: z.string().min(10, 'El mensaje debe tener al menos 10 caracteres'),
})

// --- Servicios (Admin) ---
export const serviceSchema = z.object({
  titulo: z.string().min(3, 'El título debe tener al menos 3 caracteres').max(100),
  descripcion: z.string().min(20, 'La descripción debe tener al menos 20 caracteres'),
  precio: z.coerce.number().min(0, 'El precio no puede ser negativo'),
  duracion: z.string().max(50).optional(),
  modalidad: z.enum(['online', 'presencial', 'hibrido']),
  imagen_url: z.string().url('URL de imagen inválida').optional().or(z.literal('')),
  activo: z.boolean().default(true),
  orden: z.coerce.number().int().min(0).default(0),
})

// --- Productos (Admin) ---
export const productSchema = z.object({
  nombre: z.string().min(3, 'El nombre debe tener al menos 3 caracteres').max(100),
  descripcion: z.string().optional(),
  precio: z.coerce.number().min(0, 'El precio no puede ser negativo'),
  stock: z.coerce.number().int().min(0, 'El stock no puede ser negativo').default(0),
  categoria_id: z.string().uuid('Categoría inválida').optional(),
  imagen_url: z.string().url('URL de imagen inválida').optional().or(z.literal('')),
  activo: z.boolean().default(true),
  destacado: z.boolean().default(false),
})

// --- Categorías (Admin) ---
export const categorySchema = z.object({
  nombre: z.string().min(2, 'El nombre debe tener al menos 2 caracteres').max(50),
  descripcion: z.string().optional(),
  imagen_url: z.string().url('URL de imagen inválida').optional().or(z.literal('')),
  activo: z.boolean().default(true),
  orden: z.coerce.number().int().min(0).default(0),
})

// --- Configuración (Admin) ---
export const configSchema = z.object({
  clave: z.string().min(1, 'La clave es requerida'),
  valor: z.string().min(1, 'El valor es requerido'),
  descripcion: z.string().optional(),
})

// --- Pedidos ---
export const orderSchema = z.object({
  tipo: z.enum(['servicio', 'producto']),
  item_id: z.string().uuid('ID de item inválido'),
  cantidad: z.coerce.number().int().min(1, 'Cantidad mínima 1'),
})

// Tipos TypeScript inferidos
export type LoginInput = z.infer<typeof loginSchema>
export type RegisterInput = z.infer<typeof registerSchema>
export type ResetPasswordInput = z.infer<typeof resetPasswordSchema>
export type UpdatePasswordInput = z.infer<typeof updatePasswordSchema>
export type ProfileInput = z.infer<typeof profileSchema>
export type ContactInput = z.infer<typeof contactSchema>
export type ServiceInput = z.infer<typeof serviceSchema>
export type ProductInput = z.infer<typeof productSchema>
export type CategoryInput = z.infer<typeof categorySchema>
export type ConfigInput = z.infer<typeof configSchema>
export type OrderInput = z.infer<typeof orderSchema>