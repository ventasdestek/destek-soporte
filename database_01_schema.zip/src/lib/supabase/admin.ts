import { createClient } from '@supabase/supabase-js'

// Cliente con service_role key para operaciones administrativas
// SOLO USAR EN SERVER-SIDE (API routes, Server Actions)
export function createAdminClient() {
  return createClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL || 'https://placeholder.supabase.co',
    process.env.SUPABASE_SERVICE_ROLE_KEY || 'placeholder',
    {
      auth: {
        autoRefreshToken: false,
        persistSession: false,
      },
    }
  )
}

// Helper para verificar si el usuario es admin
export async function isAdmin(supabase: ReturnType<typeof createAdminClient>, userId: string) {
  const { data, error } = await supabase
    .from('profiles')
    .select('role')
    .eq('id', userId)
    .single()
  
  if (error || !data) return false
  return data.role === 'admin'
}