﻿import { type NextRequest, NextResponse } from 'next/server'
import { updateSession } from '@/lib/supabase/middleware'

// Rutas que NO requieren autenticación
const publicRoutes = [
  '/',
  '/servicios',
  '/productos',
  '/nosotros',
  '/contacto',
  '/login',
  '/registro',
  '/recuperar-password',
  '/api/auth/callback',
]

// Rutas que requieren rol de administrador
const adminRoutes = [
  '/admin',
  '/admin/servicios',
  '/admin/productos',
  '/admin/categorias',
  '/admin/usuarios',
  '/admin/pedidos',
  '/admin/mensajes',
  '/admin/configuracion',
]

// Rutas privadas (requieren autenticación pero no admin)
const privateRoutes = [
  '/dashboard',
  '/dashboard/perfil',
  '/dashboard/mis-solicitudes',
]

export async function proxy(request: NextRequest) {
  const { supabase, supabaseResponse, user } = await updateSession(request)
  const { pathname } = request.nextUrl

  // Verificar si es ruta pública
  const isPublicRoute = publicRoutes.some(route =>
    pathname === route || pathname.startsWith(route + '/')
  )

  // Verificar si es ruta de admin
  const isAdminRoute = adminRoutes.some(route =>
    pathname === route || pathname.startsWith(route + '/')
  )

  // Verificar si es ruta privada
  const isPrivateRoute = privateRoutes.some(route =>
    pathname === route || pathname.startsWith(route + '/')
  )

  // Rutas de API y assets - permitir
  if (
    pathname.startsWith('/api') ||
    pathname.startsWith('/_next') ||
    pathname.startsWith('/static') ||
    pathname.includes('.')
  ) {
    return supabaseResponse
  }

  // Si no hay usuario y la ruta requiere auth
  if (!user && (isPrivateRoute || isAdminRoute)) {
    const redirectUrl = request.nextUrl.clone()
    redirectUrl.pathname = '/login'
    redirectUrl.searchParams.set('redirect', pathname)
    return NextResponse.redirect(redirectUrl)
  }

  // Si hay usuario, verificar rol para rutas admin
  if (user && isAdminRoute) {
    const { data: profile } = await supabase
      .from('profiles')
      .select('role')
      .eq('id', user.id)
      .single()

    if (!profile || profile.role !== 'admin') {
      const redirectUrl = request.nextUrl.clone()
      redirectUrl.pathname = '/dashboard'
      return NextResponse.redirect(redirectUrl)
    }
  }

  // Redirigir usuarios autenticados lejos de login/registro
  if (user && (pathname === '/login' || pathname === '/registro')) {
    const redirectUrl = request.nextUrl.clone()
    const role = user.user_metadata?.role
    redirectUrl.pathname = role === 'admin' ? '/admin' : '/dashboard'
    return NextResponse.redirect(redirectUrl)
  }

  return supabaseResponse
}

export const config = {
  matcher: [
    '/((?!_next/static|_next/image|favicon.ico|.*\.(?:svg|png|jpg|jpeg|gif|webp)$).*)',
  ],
}
