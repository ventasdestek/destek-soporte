// ============================================================
// UTILIDADES DE FORMATO
// ============================================================

/**
 * Configuración centralizada de moneda.
 * Para cambiar la moneda de todo el sitio, edita únicamente estos valores.
 * Ejemplos: MXN (peso mexicano), USD (dólar), EUR (euro), COP (peso colombiano)
 */
export const CURRENCY_CONFIG = {
  code: 'MXN',
  locale: 'es-MX',
} as const

/**
 * Formatea un número como moneda usando la configuración centralizada.
 * Ejemplo: formatPrice(299) -> "$299.00"
 */
export function formatPrice(amount: number): string {
  return new Intl.NumberFormat(CURRENCY_CONFIG.locale, {
    style: 'currency',
    currency: CURRENCY_CONFIG.code,
    minimumFractionDigits: 2,
  }).format(amount)
}
