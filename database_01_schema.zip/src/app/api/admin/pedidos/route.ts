import { NextRequest, NextResponse } from 'next/server'
import { createClient } from '@/lib/supabase/server'
import { createAdminClient } from '@/lib/supabase/admin'

// Verifica que la petición proviene de un usuario autenticado con rol admin
async function requireAdmin() {
  const supabase = await createClient()
  const { data: { user } } = await supabase.auth.getUser()

  if (!user) {
    return { authorized: false as const, response: NextResponse.json({ error: 'No autenticado' }, { status: 401 }) }
  }

  const { data: profile } = await supabase
    .from('profiles')
    .select('role')
    .eq('id', user.id)
    .single()

  if (!profile || profile.role !== 'admin') {
    return { authorized: false as const, response: NextResponse.json({ error: 'No autorizado' }, { status: 403 }) }
  }

  return { authorized: true as const, user }
}

// GET /api/admin/pedidos - Lista todos los pedidos con datos del cliente
export async function GET() {
  const check = await requireAdmin()
  if (!check.authorized) return check.response

  const admin = createAdminClient()
  // Usamos la vista pedidos_con_cliente (definida en database_completo.sql)
  // en lugar de un JOIN embebido, que requiere que el schema cache de
  // PostgREST reconozca la FK entre pedidos.cliente_id y auth.users.id.
  // La vista ejecuta el JOIN en el servidor de BD, evitando ese problema.
  const { data, error } = await admin
    .from('pedidos_con_cliente')
    .select('id, item, total, estado, tipo, notas, created_at, nombre, apellido, email')
    .order('created_at', { ascending: false })

  if (error) {
    return NextResponse.json({ error: error.message }, { status: 500 })
  }

  // Aplanar la respuesta para el frontend
  const pedidos = (data || []).map((p: any) => {
    const nombre = p.nombre || ''
    const apellido = p.apellido || ''
    const cliente = [nombre, apellido].filter(Boolean).join(' ') || 'Cliente sin nombre'
    return {
      id: p.id,
      cliente,
      email: p.email || '',
      tipo: p.tipo,
      item: p.item,
      monto: Number(p.total) || 0,
      estado: p.estado,
      notas: p.notas || '',
      fecha: p.created_at,
    }
  })

  return NextResponse.json({ pedidos })
}

// PATCH /api/admin/pedidos - Actualiza el estado (u otros campos) de un pedido
export async function PATCH(request: NextRequest) {
  const check = await requireAdmin()
  if (!check.authorized) return check.response

  const body = await request.json()
  const { id, estado, notas } = body

  if (!id) {
    return NextResponse.json({ error: 'ID de pedido requerido' }, { status: 400 })
  }

  const estadosValidos = ['pendiente', 'procesando', 'completado', 'cancelado']
  if (estado !== undefined && !estadosValidos.includes(estado)) {
    return NextResponse.json({ error: `Estado inválido. Debe ser uno de: ${estadosValidos.join(', ')}` }, { status: 400 })
  }

  const updateData: Record<string, unknown> = {}
  if (estado !== undefined) updateData.estado = estado
  if (notas !== undefined) updateData.notas = notas

  const admin = createAdminClient()
  const { data, error } = await admin
    .from('pedidos')
    .update(updateData)
    .eq('id', id)
    .select()
    .single()

  if (error) {
    return NextResponse.json({ error: error.message }, { status: 500 })
  }

  return NextResponse.json({ pedido: data })
}

// DELETE /api/admin/pedidos?id=xxx - Elimina un pedido
export async function DELETE(request: NextRequest) {
  const check = await requireAdmin()
  if (!check.authorized) return check.response

  const id = request.nextUrl.searchParams.get('id')
  if (!id) {
    return NextResponse.json({ error: 'ID de pedido requerido' }, { status: 400 })
  }

  const admin = createAdminClient()
  const { error } = await admin
    .from('pedidos')
    .delete()
    .eq('id', id)

  if (error) {
    return NextResponse.json({ error: error.message }, { status: 500 })
  }

  return NextResponse.json({ success: true })
}
