import { NextResponse } from 'next/server'
import { createClient } from '@/lib/supabase/server'
import { createAdminClient } from '@/lib/supabase/admin'

// Verifica que la peticion proviene de un usuario autenticado con rol admin
async function requireAdmin() {
  const supabase = await createClient()
  const { data: { user } } = await supabase.auth.getUser()

  if (!user) {
    return { authorized: false as const, response: NextResponse.json({ error: 'No autenticado' }, { status: 401 }) }
  }

  const { data: profile } = await supabase
    .from('profiles')
    .select('role')
    .eq('id', user.id)
    .single()

  if (!profile || profile.role !== 'admin') {
    return { authorized: false as const, response: NextResponse.json({ error: 'No autorizado' }, { status: 403 }) }
  }

  return { authorized: true as const, user }
}

// GET /api/admin/diagnostico
// Ejecuta una bateria de pruebas contra la base de datos Supabase
// para verificar la conexion en tiempo real.
export async function GET() {
  const check = await requireAdmin()
  if (!check.authorized) return check.response

  const startedAt = Date.now()
  const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL || ''

  // Tablas que esperamos encontrar (las que usa la aplicacion)
  const expectedTables = [
    'profiles',
    'servicios',
    'categorias',
    'pedidos',
    'productos',
  ]

  const admin = createAdminClient()
  const checks: Array<{
    name: string
    status: 'ok' | 'fail' | 'warn'
    message: string
    durationMs?: number
  }> = []

  // 1) Verificacion de variables de entorno
  const hasUrl = !!supabaseUrl && /^https:\/\/.+\.supabase\.co$/.test(supabaseUrl)
  const hasServiceKey = !!process.env.SUPABASE_SERVICE_ROLE_KEY
  checks.push({
    name: 'Variables de entorno',
    status: hasUrl && hasServiceKey ? 'ok' : 'fail',
    message: hasUrl && hasServiceKey
      ? `URL y service_role key configuradas`
      : `Faltan variables: ${!hasUrl ? 'URL ' : ''}${!hasServiceKey ? 'SERVICE_ROLE_KEY' : ''}`.trim(),
  })

  // 2) Ping HTTP al endpoint REST
  const restStart = Date.now()
  let restStatus = 0
  let restOk = false
  try {
    const r = await fetch(`${supabaseUrl}/rest/v1/`, {
      method: 'GET',
      headers: {
        apikey: process.env.SUPABASE_SERVICE_ROLE_KEY || '',
        Authorization: `Bearer ${process.env.SUPABASE_SERVICE_ROLE_KEY || ''}`,
      },
      // Timeout manual
      signal: AbortSignal.timeout(8000),
    })
    restStatus = r.status
    restOk = r.ok
    checks.push({
      name: 'Endpoint REST',
      status: restOk ? 'ok' : 'fail',
      message: `HTTP ${restStatus} en /rest/v1/`,
      durationMs: Date.now() - restStart,
    })
  } catch (e) {
    checks.push({
      name: 'Endpoint REST',
      status: 'fail',
      message: `Error de red: ${(e as Error).message}`,
      durationMs: Date.now() - restStart,
    })
  }

  // 3) Sondeo de tablas esperadas (lectura real con select)
  const tablesResult: Array<{ name: string; accessible: boolean; rows: number | null; error?: string }> = []
  let tablesOk = 0
  for (const table of expectedTables) {
    const t0 = Date.now()
    const { data, error, count } = await admin
      .from(table)
      .select('*', { count: 'exact', head: true })

    const accessible = !error
    if (accessible) tablesOk++
    tablesResult.push({
      name: table,
      accessible,
      rows: accessible ? count ?? null : null,
      error: error ? error.message : undefined,
    })
  }

  checks.push({
    name: 'Tablas del esquema public',
    status: tablesOk === expectedTables.length ? 'ok' : tablesOk > 0 ? 'warn' : 'fail',
    message: `${tablesOk}/${expectedTables.length} tablas accesibles`,
  })

  // 4) Verificacion de auth (anon key)
  const authStart = Date.now()
  const { error: authErr } = await admin.auth.getSession()
  checks.push({
    name: 'Servicio de Auth',
    status: !authErr ? 'ok' : 'fail',
    message: !authErr ? 'Respondiendo correctamente' : `Error: ${authErr.message}`,
    durationMs: Date.now() - authStart,
  })

  // 5) Query de smoke test (lectura real de 1 fila)
  const smokeStart = Date.now()
  const { data: smokeData, error: smokeErr } = await admin
    .from('profiles')
    .select('id, email, role')
    .limit(1)
  checks.push({
    name: 'Lectura de datos (smoke test)',
    status: !smokeErr ? 'ok' : 'fail',
    message: !smokeErr
      ? `OK - ${smokeData?.length ?? 0} fila(s) leida(s) de profiles`
      : `Error: ${smokeErr.message}`,
    durationMs: Date.now() - smokeStart,
  })

  const totalDurationMs = Date.now() - startedAt
  const failed = checks.filter(c => c.status === 'fail').length
  const warned = checks.filter(c => c.status === 'warn').length
  const overallOk = failed === 0

  return NextResponse.json({
    ok: overallOk,
    timestamp: new Date().toISOString(),
    latencyMs: totalDurationMs,
    supabase: {
      url: supabaseUrl,
      host: (() => { try { return new URL(supabaseUrl).hostname } catch { return 'invalid' } })(),
      restStatus,
    },
    summary: overallOk
      ? warned > 0
        ? `Conexion correcta con ${warned} advertencia(s)`
        : 'Conexion correcta con Supabase'
      : `${failed} verificacion(es) fallaron`,
    checks,
    tables: tablesResult,
  }, {
    status: overallOk ? 200 : 503,
  })
}
