import { NextRequest, NextResponse } from 'next/server'
import { createClient } from '@/lib/supabase/server'
import { createAdminClient } from '@/lib/supabase/admin'

// Verifica que la petición proviene de un usuario autenticado con rol admin
async function requireAdmin() {
  const supabase = await createClient()
  const { data: { user } } = await supabase.auth.getUser()

  if (!user) {
    return { authorized: false as const, response: NextResponse.json({ error: 'No autenticado' }, { status: 401 }) }
  }

  const { data: profile } = await supabase
    .from('profiles')
    .select('role')
    .eq('id', user.id)
    .single()

  if (!profile || profile.role !== 'admin') {
    return { authorized: false as const, response: NextResponse.json({ error: 'No autorizado' }, { status: 403 }) }
  }

  return { authorized: true as const, user }
}

// GET /api/admin/configuracion - Obtener toda la configuración pública y privada
export async function GET() {
  const check = await requireAdmin()
  if (!check.authorized) return check.response

  const admin = createAdminClient()
  const { data, error } = await admin
    .from('configuracion')
    .select('*')

  if (error) {
    return NextResponse.json({ error: error.message }, { status: 500 })
  }

  // Separar configuración pública (clave que empieza con 'public_') de la privada
  const publicConfig = (data || []).map((c: { clave: string; valor: any }) => {
    // Quitar el prefijo 'public_' y deserializar el JSONB si viene string
    const clave = c.clave.startsWith('public_') ? c.clave.replace('public_', '') : c.clave
    let valor = c.valor
    if (typeof valor === 'string') {
      try { valor = JSON.parse(valor) } catch { /* keep as string */ }
    }
    return { clave, valor }
  })

  return NextResponse.json({ public: publicConfig, private: [] })
}

// POST /api/admin/configuracion - Actualizar configuración (claves con prefijo 'public_')
export async function POST(request: NextRequest) {
  const check = await requireAdmin()
  if (!check.authorized) return check.response

  const body = await request.json()
  const admin = createAdminClient()

  // Guardar cada par clave/valor con prefijo 'public_' en columna JSONB
  const updates = Object.entries(body).map(async ([key, value]) => {
    const { error } = await admin
      .from('configuracion')
      .upsert(
        { clave: `public_${key}`, valor: value as any, updated_at: new Date().toISOString() },
        { onConflict: 'clave' }
      )
    if (error) throw new Error(`${key}: ${error.message}`)
  })

  try {
    await Promise.all(updates)
  } catch (err) {
    return NextResponse.json({ error: (err as Error).message }, { status: 500 })
  }

  return NextResponse.json({ success: true, updated: Object.keys(body) })
}