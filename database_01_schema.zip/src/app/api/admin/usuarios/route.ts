import { NextRequest, NextResponse } from 'next/server'
import { createClient } from '@/lib/supabase/server'
import { createAdminClient } from '@/lib/supabase/admin'

// Verifica que la petición proviene de un usuario autenticado con rol admin
async function requireAdmin() {
  const supabase = await createClient()
  const { data: { user } } = await supabase.auth.getUser()

  if (!user) {
    return { authorized: false as const, response: NextResponse.json({ error: 'No autenticado' }, { status: 401 }) }
  }

  const { data: profile } = await supabase
    .from('profiles')
    .select('role')
    .eq('id', user.id)
    .single()

  if (!profile || profile.role !== 'admin') {
    return { authorized: false as const, response: NextResponse.json({ error: 'No autorizado' }, { status: 403 }) }
  }

  return { authorized: true as const, user }
}

// GET /api/admin/usuarios - Lista todos los usuarios (perfiles)
export async function GET() {
  const check = await requireAdmin()
  if (!check.authorized) return check.response

  const admin = createAdminClient()
  const { data, error } = await admin
    .from('profiles')
    .select('*')
    .order('created_at', { ascending: false })

  if (error) {
    return NextResponse.json({ error: error.message }, { status: 500 })
  }

  return NextResponse.json({ usuarios: data })
}

// PATCH /api/admin/usuarios - Edita un usuario (perfil) por id
export async function PATCH(request: NextRequest) {
  const check = await requireAdmin()
  if (!check.authorized) return check.response

  const body = await request.json()
  const { id, nombre, apellido, telefono, direccion, role } = body

  if (!id) {
    return NextResponse.json({ error: 'ID de usuario requerido' }, { status: 400 })
  }

  if (role && !['admin', 'cliente'].includes(role)) {
    return NextResponse.json({ error: 'Rol inválido' }, { status: 400 })
  }

  const admin = createAdminClient()
  const updateData: Record<string, unknown> = {}
  if (nombre !== undefined) updateData.nombre = nombre
  if (apellido !== undefined) updateData.apellido = apellido
  if (telefono !== undefined) updateData.telefono = telefono
  if (direccion !== undefined) updateData.direccion = direccion
  if (role !== undefined) updateData.role = role

  const { data, error } = await admin
    .from('profiles')
    .update(updateData)
    .eq('id', id)
    .select()
    .single()

  if (error) {
    return NextResponse.json({ error: error.message }, { status: 500 })
  }

  // Si se cambió el rol, sincronizar también en los metadatos de auth.users
  if (role !== undefined) {
    await admin.auth.admin.updateUserById(id, {
      user_metadata: { role },
    })
  }

  return NextResponse.json({ usuario: data })
}

// DELETE /api/admin/usuarios?id=xxx - Elimina un usuario completamente (auth + perfil)
export async function DELETE(request: NextRequest) {
  const check = await requireAdmin()
  if (!check.authorized) return check.response

  const id = request.nextUrl.searchParams.get('id')
  if (!id) {
    return NextResponse.json({ error: 'ID de usuario requerido' }, { status: 400 })
  }

  if (id === check.user.id) {
    return NextResponse.json({ error: 'No puedes eliminar tu propia cuenta' }, { status: 400 })
  }

  const admin = createAdminClient()

  // Elimina el usuario de auth.users; el trigger ON DELETE CASCADE
  // en public.profiles elimina también su perfil automáticamente
  const { error } = await admin.auth.admin.deleteUser(id)

  if (error) {
    return NextResponse.json({ error: error.message }, { status: 500 })
  }

  return NextResponse.json({ success: true })
}
