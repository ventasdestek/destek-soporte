import type { Metadata, Viewport } from 'next'
import { Inter } from 'next/font/google'
import '@/styles/globals.css'
import { Providers } from '@/components/providers'
import { Toaster } from 'react-hot-toast'

const inter = Inter({
  subsets: ['latin'],
  variable: '--font-inter',
  display: 'swap',
})

export const metadata: Metadata = {
  metadataBase: new URL(process.env.NEXT_PUBLIC_APP_URL || 'https://desteksoporte.es'),
  title: {
    default: 'Destek Soporte | Servicios Tecnológicos, Soporte y Desarrollo',
    template: '%s | Destek Soporte',
  },
  description: 'Empresa de servicios tecnológicos: asesoría, soporte remoto, desarrollo de software a medida y venta de hardware. ¡Contáctanos!',
  keywords: ['servicios tecnológicos', 'soporte IT', 'desarrollo software', 'reparación PC', 'mantenimiento informático', 'seguridad informática'],
  authors: [{ name: 'Destek Soporte' }],
  creator: 'Destek Soporte',
  publisher: 'Destek Soporte',
  robots: 'index, follow',
  openGraph: {
    type: 'website',
    locale: 'es_ES',
    url: 'https://desteksoporte.es',
    siteName: 'Destek Soporte',
    title: 'Destek Soporte | Servicios Tecnológicos, Soporte y Desarrollo',
    description: 'Empresa de servicios tecnológicos: asesoría, soporte remoto, desarrollo de software a medida y venta de hardware.',
    images: [
      {
        url: '/images/og-default.jpg',
        width: 1200,
        height: 630,
        alt: 'Destek Soporte',
      },
    ],
  },
  twitter: {
    card: 'summary_large_image',
    title: 'Destek Soporte | Servicios Tecnológicos',
    description: 'Empresa de servicios tecnológicos: asesoría, soporte remoto, desarrollo de software a medida y venta de hardware.',
    images: ['/images/og-default.jpg'],
    creator: '@desteksoporte',
  },
  verification: {
    google: 'google-site-verification-code',
  },
}

export const viewport: Viewport = {
  themeColor: [
    { media: '(prefers-color-scheme: light)', color: '#ffffff' },
    { media: '(prefers-color-scheme: dark)', color: '#030712' },
  ],
  width: 'device-width',
  initialScale: 1,
  maximumScale: 5,
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="es" className={`${inter.variable} antialiased`} suppressHydrationWarning>
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link rel="dns-prefetch" href="https://fonts.googleapis.com" />
        <link rel="dns-prefetch" href="https://fonts.gstatic.com" />
      </head>
      <body className="min-h-screen bg-white dark:bg-gray-950 text-gray-900 dark:text-gray-100 font-sans transition-colors duration-300">
        <Providers>
          {children}
          <Toaster
            position="bottom-right"
            toastOptions={{
              duration: 4000,
              style: {
                background: 'var(--toast-bg, #1f2937)',
                color: 'var(--toast-color, #f9fafb)',
                borderRadius: '0.75rem',
                padding: '1rem 1.25rem',
                boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1), 0 4px 6px -4px rgb(0 0 0 / 0.1)',
              },
              success: {
                iconTheme: {
                  primary: '#10b981',
                  secondary: '#f9fafb',
                },
              },
              error: {
                iconTheme: {
                  primary: '#ef4444',
                  secondary: '#f9fafb',
                },
              },
            }}
          />
        </Providers>
      </body>
    </html>
  )
}