'use client'

import { useEffect, useState } from 'react'
import { Mail, Check, Trash2, Loader2, MailOpen, Search, Inbox } from 'lucide-react'
import { Button, Badge } from '@/components/ui'
import { createClient } from '@/lib/supabase/client'
import toast from 'react-hot-toast'

interface Mensaje {
  id: string
  nombre: string
  email: string
  telefono: string | null
  empresa: string | null
  tipo_consulta: string | null
  mensaje: string
  leido: boolean
  created_at: string
}

export default function AdminMensajesPage() {
  const supabase = createClient()
  const [mensajes, setMensajes] = useState<Mensaje[]>([])
  const [loading, setLoading] = useState(true)
  const [busqueda, setBusqueda] = useState('')
  const [filtro, setFiltro] = useState<'todos' | 'no_leidos' | 'leidos'>('todos')
  const [procesandoId, setProcesandoId] = useState<string | null>(null)

  const cargarMensajes = async () => {
    setLoading(true)
    try {
      const { data, error } = await supabase
        .from('mensajes_contacto')
        .select('*')
        .order('created_at', { ascending: false })

      if (error) throw error
      setMensajes(data || [])
    } catch (err: any) {
      console.error('[admin/mensajes] Error al cargar:', err)
      toast.error('Error al cargar mensajes: ' + (err?.message || 'desconocido'))
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    cargarMensajes()
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])
  const handleToggleLeido = async (msg: Mensaje) => {
    setProcesandoId(msg.id)
    try {
      const { error } = await supabase
        .from('mensajes_contacto')
        .update({ leido: !msg.leido })
        .eq('id', msg.id)
      if (error) throw error
      toast.success(msg.leido ? 'Marcado como no leido' : 'Marcado como leido')
      await cargarMensajes()
    } catch (err: any) {
      console.error('[admin/mensajes] Error al cambiar estado:', err)
      toast.error('Error: ' + (err?.message || 'desconocido'))
    } finally {
      setProcesandoId(null)
    }
  }

  const handleEliminar = async (id: string) => {
    if (!confirm('¿Eliminar este mensaje? Esta accion no se puede deshacer.')) return
    setProcesandoId(id)
    try {
      const { error } = await supabase
        .from('mensajes_contacto')
        .delete()
        .eq('id', id)
      if (error) throw error
      toast.success('Mensaje eliminado')
      await cargarMensajes()
    } catch (err: any) {
      console.error('[admin/mensajes] Error al eliminar:', err)
      toast.error('Error al eliminar: ' + (err?.message || 'desconocido'))
    } finally {
      setProcesandoId(null)
    }
  }

  const formatFecha = (iso: string) => {
    try {
      return new Date(iso).toLocaleString('es-ES', {
        year: 'numeric', month: '2-digit', day: '2-digit',
        hour: '2-digit', minute: '2-digit'
      })
    } catch {
      return iso
    }
  }

  const filtrados = mensajes.filter((m) => {
    if (filtro === 'no_leidos' && m.leido) return false
    if (filtro === 'leidos' && !m.leido) return false
    if (!busqueda) return true
    const q = busqueda.toLowerCase()
    return (
      m.nombre.toLowerCase().includes(q) ||
      m.email.toLowerCase().includes(q) ||
      m.mensaje.toLowerCase().includes(q)
    )
  })

  const noLeidos = mensajes.filter((m) => !m.leido).length

  return (
    <div className="space-y-6 max-w-5xl">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold text-gray-900 dark:text-white">Mensajes de Contacto</h1>
          <p className="text-xs text-gray-500 mt-0.5">
            {mensajes.length} mensaje{mensajes.length === 1 ? '' : 's'} en total
            {noLeidos > 0 && (
              <span className="ml-2 inline-flex items-center px-2 py-0.5 rounded-full text-xs font-semibold bg-primary-100 text-primary-800 dark:bg-primary-950/40 dark:text-primary-300">
                {noLeidos} sin leer
              </span>
            )}
          </p>
        </div>
      </div>

      <div className="card-base p-3 flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1">
          <input
            type="text"
            placeholder="Buscar por nombre, email o mensaje..."
            value={busqueda}
            onChange={(e) => setBusqueda(e.target.value)}
            className="input-base pl-9 text-sm py-1.5"
          />
          <Search className="w-4 h-4 text-gray-400 absolute left-3 top-1/2 -translate-y-1/2" />
        </div>
        <div className="flex gap-1">
          <Button
            variant={filtro === 'todos' ? 'primary' : 'outline'}
            size="sm"
            onClick={() => setFiltro('todos')}
          >
            Todos ({mensajes.length})
          </Button>
          <Button
            variant={filtro === 'no_leidos' ? 'primary' : 'outline'}
            size="sm"
            onClick={() => setFiltro('no_leidos')}
          >
            Sin leer ({noLeidos})
          </Button>
          <Button
            variant={filtro === 'leidos' ? 'primary' : 'outline'}
            size="sm"
            onClick={() => setFiltro('leidos')}
          >
            Leidos ({mensajes.length - noLeidos})
          </Button>
        </div>
      </div>

      {loading ? (
        <div className="card-base p-12 flex items-center justify-center text-gray-500">
          <Loader2 className="w-5 h-5 mr-2 animate-spin" /> Cargando mensajes...
        </div>
      ) : filtrados.length === 0 ? (
        <div className="card-base p-12 text-center text-gray-500">
          <Inbox className="w-10 h-10 mx-auto mb-2 opacity-30" />
          <p className="text-sm">
            {mensajes.length === 0
              ? 'No hay mensajes todavia. Cuando alguien contacte desde la web aparecera aqui.'
              : 'No hay mensajes que coincidan con el filtro o busqueda.'}
          </p>
        </div>
      ) : (
        <div className="space-y-4">
          {filtrados.map((msg) => (
            <div
              key={msg.id}
              className={`card-base p-6 transition-all ${
                !msg.leido ? 'border-l-4 border-l-primary-600 bg-primary-50/20 dark:bg-primary-950/20' : ''
              }`}
            >
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-3">
                <div className="min-w-0 flex-1">
                  <span className="font-bold text-gray-900 dark:text-white text-base">{msg.nombre}</span>
                  <span className="text-xs text-gray-500 ml-2 break-all">
                    ({msg.email}{msg.telefono ? ` • ${msg.telefono}` : ''})
                  </span>
                  {msg.empresa && (
                    <span className="text-xs text-gray-500 ml-2">• {msg.empresa}</span>
                  )}
                </div>
                <div className="flex items-center gap-3 flex-shrink-0">
                  <span className="text-xs text-gray-400">{formatFecha(msg.created_at)}</span>
                  {msg.tipo_consulta && (
                    <Badge variant="info" className="text-[10px]">{msg.tipo_consulta}</Badge>
                  )}
                  <Badge variant={msg.leido ? 'secondary' : 'warning'}>
                    {msg.leido ? 'Leido' : 'Sin Leer'}
                  </Badge>
                </div>
              </div>
              <p className="text-sm text-gray-700 dark:text-gray-300 bg-gray-50 dark:bg-gray-800 p-4 rounded-xl mb-4 whitespace-pre-wrap">
                {msg.mensaje}
              </p>
              <div className="flex justify-end gap-2">
                <a href={`mailto:${msg.email}?subject=Respuesta Destek Soporte`}>
                  <Button variant="outline" size="sm">
                    <Mail className="w-4 h-4 mr-1" /> Responder Email
                  </Button>
                </a>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => handleToggleLeido(msg)}
                  disabled={procesandoId === msg.id}
                >
                  {procesandoId === msg.id ? (
                    <Loader2 className="w-4 h-4 mr-1 animate-spin" />
                  ) : msg.leido ? (
                    <MailOpen className="w-4 h-4 mr-1" />
                  ) : (
                    <Check className="w-4 h-4 mr-1" />
                  )}
                  {msg.leido ? 'Marcar No Leido' : 'Marcar Leido'}
                </Button>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => handleEliminar(msg.id)}
                  className="text-red-600"
                  disabled={procesandoId === msg.id}
                >
                  {procesandoId === msg.id ? (
                    <Loader2 className="w-4 h-4 animate-spin" />
                  ) : (
                    <Trash2 className="w-4 h-4" />
                  )}
                </Button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  )
}
