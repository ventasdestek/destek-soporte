'use client'

import { useEffect, useState } from 'react'
import { Plus, Search, Edit2, Trash2, Loader2 } from 'lucide-react'
import { Button, Badge, Modal } from '@/components/ui'
import { formatPrice, CURRENCY_CONFIG } from '@/utils/format'
import { createClient } from '@/lib/supabase/client'
import toast from 'react-hot-toast'

interface Servicio {
  id: string
  titulo: string
  descripcion: string | null
  precio: number
  duracion: string | null
  modalidad: 'online' | 'presencial' | 'hibrido'
  activo: boolean
}

interface ServicioForm {
  id?: string
  titulo: string
  descripcion: string
  precio: number
  duracion: string
  modalidad: 'online' | 'presencial' | 'hibrido'
  activo: boolean
}

const emptyForm: ServicioForm = {
  titulo: '',
  descripcion: '',
  precio: 0,
  duracion: '',
  modalidad: 'online',
  activo: true,
}

export default function AdminServiciosPage() {
  const supabase = createClient()
  const [servicios, setServicios] = useState<Servicio[]>([])
  const [busqueda, setBusqueda] = useState('')
  const [loading, setLoading] = useState(true)
  const [guardando, setGuardando] = useState(false)
  const [eliminandoId, setEliminandoId] = useState<string | null>(null)
  const [modalAbierto, setModalAbierto] = useState(false)
  const [form, setForm] = useState<ServicioForm>(emptyForm)
  const cargarDatos = async () => {
    setLoading(true)
    try {
      const { data, error } = await supabase
        .from('servicios')
        .select('*')
        .order('orden', { ascending: true })
        .order('created_at', { ascending: false })

      if (error) throw error

      const formateados: Servicio[] = (data || []).map((s: any) => ({
        id: s.id,
        titulo: s.titulo,
        descripcion: s.descripcion,
        precio: Number(s.precio) || 0,
        duracion: s.duracion,
        modalidad: s.modalidad,
        activo: s.activo,
      }))

      setServicios(formateados)
    } catch (err: any) {
      console.error('[admin/servicios] Error al cargar:', err)
      toast.error('Error al cargar servicios: ' + (err?.message || 'desconocido'))
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    cargarDatos()
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  const handleAbrirModalNuevo = () => {
    setForm({ ...emptyForm })
    setModalAbierto(true)
  }

  const handleAbrirModalEditar = (item: Servicio) => {
    setForm({
      id: item.id,
      titulo: item.titulo,
      descripcion: item.descripcion || '',
      precio: item.precio,
      duracion: item.duracion || '',
      modalidad: item.modalidad,
      activo: item.activo,
    })
    setModalAbierto(true)
  }

  const handleGuardar = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!form.titulo.trim()) {
      toast.error('El titulo es obligatorio')
      return
    }
    if (form.precio < 0) {
      toast.error('El precio no puede ser negativo')
      return
    }

    setGuardando(true)
    try {
      const payload = {
        titulo: form.titulo.trim(),
        descripcion: form.descripcion.trim() || null,
        precio: form.precio,
        duracion: form.duracion.trim() || null,
        modalidad: form.modalidad,
        activo: form.activo,
      }

      if (form.id) {
        // UPDATE
        const { error } = await supabase
          .from('servicios')
          .update(payload)
          .eq('id', form.id)
        if (error) throw error
        toast.success('Servicio actualizado')
      } else {
        // INSERT
        const { error } = await supabase
          .from('servicios')
          .insert(payload)
        if (error) throw error
        toast.success('Servicio creado')
      }

      setModalAbierto(false)
      await cargarDatos()
    } catch (err: any) {
      console.error('[admin/servicios] Error al guardar:', err)
      toast.error('Error al guardar: ' + (err?.message || 'desconocido'))
    } finally {
      setGuardando(false)
    }
  }

  const handleEliminar = async (id: string) => {
    if (!confirm('¿Eliminar este servicio? Esta accion no se puede deshacer.')) return
    setEliminandoId(id)
    try {
      const { error } = await supabase.from('servicios').delete().eq('id', id)
      if (error) throw error
      toast.success('Servicio eliminado')
      await cargarDatos()
    } catch (err: any) {
      console.error('[admin/servicios] Error al eliminar:', err)
      toast.error('Error al eliminar: ' + (err?.message || 'desconocido'))
    } finally {
      setEliminandoId(null)
    }
  }

  const filtrados = servicios.filter((s) =>
    s.titulo.toLowerCase().includes(busqueda.toLowerCase())
  )

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold text-gray-900 dark:text-white">Gestion de Servicios</h1>
          <p className="text-xs text-gray-500 mt-0.5">
            {servicios.length} servicio{servicios.length === 1 ? '' : 's'} en catalogo
          </p>
        </div>
        <Button onClick={handleAbrirModalNuevo} size="sm" disabled={loading}>
          <Plus className="w-4 h-4 mr-1" /> Nuevo Servicio
        </Button>
      </div>

      <div className="card-base p-3">
        <div className="relative max-w-sm">
          <input
            type="text"
            placeholder="Buscar por titulo..."
            value={busqueda}
            onChange={(e) => setBusqueda(e.target.value)}
            className="input-base pl-9 text-sm py-1.5"
          />
          <Search className="w-4 h-4 text-gray-400 absolute left-3 top-1/2 -translate-y-1/2" />
        </div>
      </div>

      <div className="card-base overflow-hidden">
        {loading ? (
          <div className="p-12 flex items-center justify-center text-gray-500">
            <Loader2 className="w-5 h-5 mr-2 animate-spin" /> Cargando servicios...
          </div>
        ) : filtrados.length === 0 ? (
          <div className="p-12 text-center text-gray-500">
            <p className="text-sm">
              {servicios.length === 0
                ? 'No hay servicios todavia. Crea el primero con el boton "Nuevo Servicio".'
                : 'No se encontraron servicios con esa busqueda.'}
            </p>
          </div>
        ) : (
          <table className="w-full text-left text-sm">
            <thead className="bg-gray-50 dark:bg-gray-800 text-xs uppercase text-gray-400 border-b border-gray-200 dark:border-gray-800">
              <tr>
                <th className="p-3">Titulo</th>
                <th className="p-3">Modalidad</th>
                <th className="p-3">Duracion</th>
                <th className="p-3">Precio</th>
                <th className="p-3">Estado</th>
                <th className="p-3 text-right">Acciones</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100 dark:divide-gray-800">
              {filtrados.map((item) => (
                <tr key={item.id} className="hover:bg-gray-50 dark:hover:bg-gray-800/30">
                  <td className="p-3 font-semibold text-gray-900 dark:text-white">{item.titulo}</td>
                  <td className="p-3 capitalize">{item.modalidad}</td>
                  <td className="p-3 text-gray-500">{item.duracion || '-'}</td>
                  <td className="p-3 font-bold text-primary-600">{formatPrice(item.precio)}</td>
                  <td className="p-3"><Badge variant={item.activo ? 'success' : 'secondary'}>{item.activo ? 'Activo' : 'Inactivo'}</Badge></td>
                  <td className="p-3 text-right space-x-1">
                    <Button variant="ghost" size="sm" onClick={() => handleAbrirModalEditar(item)}><Edit2 className="w-4 h-4" /></Button>
                    <Button variant="ghost" size="sm" onClick={() => handleEliminar(item.id)} className="text-red-600" disabled={eliminandoId === item.id}>
                      {eliminandoId === item.id ? <Loader2 className="w-4 h-4 animate-spin" /> : <Trash2 className="w-4 h-4" />}
                    </Button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>

      <Modal
        isOpen={modalAbierto}
        onClose={() => !guardando && setModalAbierto(false)}
        title={form.id ? 'Editar Servicio' : 'Nuevo Servicio'}
        size="lg"
      >
        <form onSubmit={handleGuardar} className="space-y-3 pt-2">
          <div>
            <label className="block text-xs font-medium mb-1">Titulo *</label>
            <input
              type="text"
              value={form.titulo}
              onChange={(e) => setForm({ ...form, titulo: e.target.value })}
              required
              className="input-base text-sm"
              placeholder="Ej: Asesoria tecnologica online"
            />
          </div>
          <div>
            <label className="block text-xs font-medium mb-1">Descripcion</label>
            <textarea
              value={form.descripcion}
              onChange={(e) => setForm({ ...form, descripcion: e.target.value })}
              rows={2}
              className="input-base text-sm"
              placeholder="Descripcion breve del servicio"
            />
          </div>
          <div className="grid grid-cols-3 gap-3">
            <div>
              <label className="block text-xs font-medium mb-1">Precio ({CURRENCY_CONFIG.code}) *</label>
              <input
                type="number"
                step="0.01"
                min="0"
                value={form.precio}
                onChange={(e) => setForm({ ...form, precio: Number(e.target.value) })}
                className="input-base text-sm"
                required
              />
            </div>
            <div>
              <label className="block text-xs font-medium mb-1">Duracion</label>
              <input
                type="text"
                value={form.duracion}
                onChange={(e) => setForm({ ...form, duracion: e.target.value })}
                className="input-base text-sm"
                placeholder="60 min, Mensual..."
              />
            </div>
            <div>
              <label className="block text-xs font-medium mb-1">Modalidad</label>
              <select
                value={form.modalidad}
                onChange={(e) => setForm({ ...form, modalidad: e.target.value as ServicioForm['modalidad'] })}
                className="input-base text-sm"
              >
                <option value="online">Online</option>
                <option value="presencial">Presencial</option>
                <option value="hibrido">Hibrido</option>
              </select>
            </div>
          </div>
          <div>
            <label className="block text-xs font-medium mb-1">Estado</label>
            <select
              value={form.activo ? '1' : '0'}
              onChange={(e) => setForm({ ...form, activo: e.target.value === '1' })}
              className="input-base text-sm"
            >
              <option value="1">Activo (visible al publico)</option>
              <option value="0">Inactivo (oculto)</option>
            </select>
          </div>
          <div className="pt-3 flex justify-end gap-2">
            <Button variant="outline" size="sm" type="button" onClick={() => setModalAbierto(false)} disabled={guardando}>
              Cancelar
            </Button>
            <Button size="sm" type="submit" disabled={guardando}>
              {guardando ? <><Loader2 className="w-4 h-4 mr-1 animate-spin" /> Guardando...</> : 'Guardar'}
            </Button>
          </div>
        </form>
      </Modal>
    </div>
  )
}
