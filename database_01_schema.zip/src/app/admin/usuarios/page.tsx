'use client'

import { useState, useEffect, useCallback } from 'react'
import { Search, Shield, User, Pencil, Trash2, RefreshCw } from 'lucide-react'
import { Button, Badge, Modal, Input, Select } from '@/components/ui'
import { ConfirmModal } from '@/components/ui'
import toast from 'react-hot-toast'

interface UsuarioItem {
  id: string
  email: string
  role: 'admin' | 'cliente'
  nombre?: string | null
  apellido?: string | null
  telefono?: string | null
  created_at?: string
}

export default function AdminUsuariosPage() {
  const [usuarios, setUsuarios] = useState<UsuarioItem[]>([])
  const [cargando, setCargando] = useState(true)
  const [busqueda, setBusqueda] = useState('')
  const [editando, setEditando] = useState<UsuarioItem | null>(null)
  const [form, setForm] = useState({ nombre: '', apellido: '', telefono: '', rol: 'cliente' })
  const [guardando, setGuardando] = useState(false)
  const [eliminando, setEliminando] = useState<UsuarioItem | null>(null)
  const [borrando, setBorrando] = useState(false)

  const cargarUsuarios = useCallback(async () => {
    setCargando(true)
    try {
      const res = await fetch('/api/admin/usuarios')
      const data = await res.json()
      if (!res.ok) throw new Error(data.error || 'Error al cargar usuarios')
      setUsuarios(data.usuarios || [])
    } catch (err) {
      toast.error((err as Error).message || 'No se pudieron cargar los usuarios')
    } finally {
      setCargando(false)
    }
  }, [])

  useEffect(() => {
    cargarUsuarios()
  }, [cargarUsuarios])

  const abrirEdicion = (user: UsuarioItem) => {
    setEditando(user)
    setForm({
      nombre: user.nombre || '',
      apellido: user.apellido || '',
      telefono: user.telefono || '',
      rol: user.role || 'cliente',
    })
  }

  const handleGuardar = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!editando) return
    setGuardando(true)
    try {
      const res = await fetch('/api/admin/usuarios', {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          id: editando.id,
          nombre: form.nombre,
          apellido: form.apellido,
          telefono: form.telefono,
          role: form.rol,
        }),
      })
      const data = await res.json()
      if (!res.ok) throw new Error(data.error || 'Error al actualizar usuario')
      toast.success('Usuario actualizado correctamente')
      setEditando(null)
      cargarUsuarios()
    } catch (err) {
      toast.error((err as Error).message)
    } finally {
      setGuardando(false)
    }
  }

  const handleEliminar = async () => {
    if (!eliminando) return
    setBorrando(true)
    try {
      const res = await fetch(`/api/admin/usuarios?id=${eliminando.id}`, { method: 'DELETE' })
      const data = await res.json()
      if (!res.ok) throw new Error(data.error || 'Error al eliminar usuario')
      toast.success('Usuario eliminado correctamente')
      setEliminando(null)
      cargarUsuarios()
    } catch (err) {
      toast.error((err as Error).message)
    } finally {
      setBorrando(false)
    }
  }

  const filtrados = usuarios.filter(
    (u) =>
      (u.nombre || '').toLowerCase().includes(busqueda.toLowerCase()) ||
      (u.email || '').toLowerCase().includes(busqueda.toLowerCase())
  )

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-gray-900 dark:text-white">Gestión de Usuarios</h1>
          <p className="text-xs text-gray-500 mt-0.5">Administra los usuarios registrados y asigna permisos de administración.</p>
        </div>
        <Button variant="outline" size="sm" onClick={cargarUsuarios} disabled={cargando}>
          <RefreshCw className={`w-4 h-4 mr-2 ${cargando ? 'animate-spin' : ''}`} />
          Recargar
        </Button>
      </div>

      <div className="card-base p-3">
        <div className="relative max-w-sm">
          <input
            type="text"
            placeholder="Buscar usuario por nombre o email..."
            value={busqueda}
            onChange={(e) => setBusqueda(e.target.value)}
            className="input-base pl-9 text-sm py-1.5"
          />
          <Search className="w-4 h-4 text-gray-400 absolute left-3 top-1/2 -translate-y-1/2" />
        </div>
      </div>

      <div className="card-base overflow-hidden">
        {cargando ? (
          <div className="p-10 text-center text-sm text-gray-500">Cargando usuarios...</div>
        ) : filtrados.length === 0 ? (
          <div className="p-10 text-center text-sm text-gray-500">No hay usuarios registrados.</div>
        ) : (
          <table className="w-full text-left text-sm">
            <thead className="bg-gray-50 dark:bg-gray-800 text-xs uppercase text-gray-400 border-b border-gray-200 dark:border-gray-800">
              <tr>
                <th className="p-3">Usuario / Email</th>
                <th className="p-3">Registro</th>
                <th className="p-3">Rol Actual</th>
                <th className="p-3 text-right">Acciones</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100 dark:divide-gray-800">
              {filtrados.map((item) => (
                <tr key={item.id} className="hover:bg-gray-50 dark:hover:bg-gray-800/30">
                  <td className="p-3 font-semibold text-gray-900 dark:text-white">
                    {item.nombre || item.apellido ? `${item.nombre || ''} ${item.apellido || ''}`.trim() : '—'}
                    <span className="text-xs text-gray-500 font-normal block">{item.email}</span>
                  </td>
                  <td className="p-3 text-xs text-gray-500">
                    {item.created_at ? new Date(item.created_at).toLocaleDateString() : '—'}
                  </td>
                  <td className="p-3">
                    <Badge variant={item.role === 'admin' ? 'default' : 'secondary'} className="capitalize">
                      {item.role === 'admin' ? <Shield className="w-3 h-3 mr-1 inline" /> : <User className="w-3 h-3 mr-1 inline" />}
                      {item.role}
                    </Badge>
                  </td>
                  <td className="p-3 text-right space-x-1">
                    <Button variant="ghost" size="sm" onClick={() => abrirEdicion(item)} aria-label={`Editar ${item.email}`}>
                      <Pencil className="w-4 h-4" />
                    </Button>
                    <Button variant="ghost" size="sm" onClick={() => setEliminando(item)} className="text-red-600" aria-label={`Eliminar ${item.email}`}>
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>

      <Modal
        isOpen={!!editando}
        onClose={() => setEditando(null)}
        title={editando ? `Editar usuario: ${editando.email}` : 'Editar usuario'}
        size="md"
      >
        <form onSubmit={handleGuardar} className="space-y-4 pt-1">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <Input
              label="Nombre"
              value={form.nombre}
              onChange={(e) => setForm({ ...form, nombre: e.target.value })}
              placeholder="Nombre"
            />
            <Input
              label="Apellido"
              value={form.apellido}
              onChange={(e) => setForm({ ...form, apellido: e.target.value })}
              placeholder="Apellido"
            />
          </div>
          <Input
            label="Teléfono"
            value={form.telefono}
            onChange={(e) => setForm({ ...form, telefono: e.target.value })}
            placeholder="+34 600 000 000"
          />
          <Select
            label="Rol"
            value={form.rol}
            onChange={(e) => setForm({ ...form, rol: e.target.value })}
            options={[
              { value: 'cliente', label: 'Cliente' },
              { value: 'admin', label: 'Administrador' },
            ]}
          />
          <div className="pt-2 flex justify-end gap-2">
            <Button variant="outline" size="sm" type="button" onClick={() => setEditando(null)}>
              Cancelar
            </Button>
            <Button size="sm" type="submit" loading={guardando}>
              Guardar
            </Button>
          </div>
        </form>
      </Modal>

      <ConfirmModal
        isOpen={!!eliminando}
        onClose={() => setEliminando(null)}
        onConfirm={handleEliminar}
        loading={borrando}
        title="Eliminar usuario"
        message={
          eliminando
            ? `¿Seguro que deseas eliminar al usuario "${eliminando.email}"? Se borrará su cuenta y perfil de forma permanente.`
            : ''
        }
        confirmText="Eliminar"
      />
    </div>
  )
}