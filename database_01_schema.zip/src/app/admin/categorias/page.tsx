'use client'

import { useEffect, useState } from 'react'
import { Plus, Edit2, Trash2, Loader2, Power, PowerOff } from 'lucide-react'
import { Button, Badge, Modal } from '@/components/ui'
import { createClient } from '@/lib/supabase/client'
import toast from 'react-hot-toast'

interface Categoria {
  id: string
  nombre: string
  descripcion: string | null
  imagen_url: string | null
  activo: boolean
  orden: number
  created_at: string
  updated_at: string
}

interface CategoriaForm {
  id?: string
  nombre: string
  descripcion: string
  imagen_url: string
  activo: boolean
  orden: number
}

const emptyForm: CategoriaForm = {
  nombre: '',
  descripcion: '',
  imagen_url: '',
  activo: true,
  orden: 0,
}

export default function AdminCategoriasPage() {
  const supabase = createClient()
  const [categorias, setCategorias] = useState<Categoria[]>([])
  const [loading, setLoading] = useState(true)
  const [guardando, setGuardando] = useState(false)
  const [eliminandoId, setEliminandoId] = useState<string | null>(null)
  const [modalAbierto, setModalAbierto] = useState(false)
  const [form, setForm] = useState<CategoriaForm>(emptyForm)
  const cargarDatos = async () => {
    setLoading(true)
    try {
      const { data, error } = await supabase
        .from('categorias')
        .select('*')
        .order('orden', { ascending: true })
        .order('nombre', { ascending: true })

      if (error) throw error
      setCategorias(data || [])
    } catch (err: any) {
      console.error('[admin/categorias] Error al cargar:', err)
      toast.error('Error al cargar categorias: ' + (err?.message || 'desconocido'))
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    cargarDatos()
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  const handleAbrirModalNueva = () => {
    // Sugerir el siguiente orden automaticamente
    const maxOrden = categorias.reduce((acc, c) => Math.max(acc, c.orden || 0), 0)
    setForm({ ...emptyForm, orden: maxOrden + 1 })
    setModalAbierto(true)
  }

  const handleAbrirModalEditar = (item: Categoria) => {
    setForm({
      id: item.id,
      nombre: item.nombre,
      descripcion: item.descripcion || '',
      imagen_url: item.imagen_url || '',
      activo: item.activo,
      orden: item.orden || 0,
    })
    setModalAbierto(true)
  }

  const handleGuardar = async (e: React.FormEvent) => {
    e.preventDefault()
    const nombreLimpio = form.nombre.trim()
    if (!nombreLimpio) {
      toast.error('El nombre es obligatorio')
      return
    }

    setGuardando(true)
    try {
      const payload = {
        nombre: nombreLimpio,
        descripcion: form.descripcion.trim() || null,
        imagen_url: form.imagen_url.trim() || null,
        activo: form.activo,
        orden: Number.isFinite(form.orden) ? form.orden : 0,
      }

      if (form.id) {
        // UPDATE
        const { error } = await supabase
          .from('categorias')
          .update(payload)
          .eq('id', form.id)
        if (error) throw error
        toast.success('Categoria actualizada')
      } else {
        // INSERT
        const { error } = await supabase
          .from('categorias')
          .insert(payload)
        if (error) throw error
        toast.success('Categoria creada')
      }

      setModalAbierto(false)
      await cargarDatos()
    } catch (err: any) {
      console.error('[admin/categorias] Error al guardar:', err)
      // El UNIQUE constraint en 'nombre' devuelve codigo 23505
      if (err?.code === '23505' || /duplicate key|unique/i.test(err?.message || '')) {
        toast.error('Ya existe una categoria con ese nombre')
      } else {
        toast.error('Error al guardar: ' + (err?.message || 'desconocido'))
      }
    } finally {
      setGuardando(false)
    }
  }

  const handleEliminar = async (item: Categoria) => {
    const productosAsociados = 0 // Se podria consultar pero el FK es ON DELETE SET NULL
    if (!confirm(
      `¿Eliminar la categoria "${item.nombre}"?\n\n` +
      'Los productos asociados no se eliminaran, solo se desasociaran.'
    )) return
    setEliminandoId(item.id)
    try {
      const { error } = await supabase.from('categorias').delete().eq('id', item.id)
      if (error) throw error
      toast.success('Categoria eliminada')
      await cargarDatos()
    } catch (err: any) {
      console.error('[admin/categorias] Error al eliminar:', err)
      toast.error('Error al eliminar: ' + (err?.message || 'desconocido'))
    } finally {
      setEliminandoId(null)
    }
  }

  // Activar / desactivar sin abrir el modal
  const handleToggleActivo = async (item: Categoria) => {
    try {
      const { error } = await supabase
        .from('categorias')
        .update({ activo: !item.activo })
        .eq('id', item.id)
      if (error) throw error
      toast.success(item.activo ? 'Categoria desactivada' : 'Categoria activada')
      await cargarDatos()
    } catch (err: any) {
      console.error('[admin/categorias] Error al cambiar estado:', err)
      toast.error('Error al cambiar estado: ' + (err?.message || 'desconocido'))
    }
  }

  return (
    <div className="space-y-6 max-w-5xl">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold text-gray-900 dark:text-white">Categorias de Productos y Servicios</h1>
          <p className="text-xs text-gray-500 mt-0.5">
            {categorias.length} categoria{categorias.length === 1 ? '' : 's'} en el sistema
          </p>
        </div>
        <Button onClick={handleAbrirModalNueva} size="sm" disabled={loading}>
          <Plus className="w-4 h-4 mr-1" /> Nueva Categoria
        </Button>
      </div>

      {loading ? (
        <div className="card-base p-12 flex items-center justify-center text-gray-500">
          <Loader2 className="w-5 h-5 mr-2 animate-spin" /> Cargando categorias...
        </div>
      ) : categorias.length === 0 ? (
        <div className="card-base p-12 text-center text-gray-500">
          <p className="text-sm">No hay categorias todavia. Crea la primera con el boton "Nueva Categoria".</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {categorias.map((cat) => (
            <div
              key={cat.id}
              className={`card-base p-5 flex items-center justify-between transition-opacity ${
                cat.activo ? '' : 'opacity-60'
              }`}
            >
              <div className="flex-1 min-w-0 pr-3">
                <div className="flex items-center gap-2 flex-wrap">
                  <h3 className="font-bold text-gray-900 dark:text-white text-base truncate">
                    {cat.nombre}
                  </h3>
                  <Badge variant={cat.activo ? 'success' : 'secondary'}>
                    {cat.activo ? 'Activa' : 'Inactiva'}
                  </Badge>
                  <span className="text-xs text-gray-400 font-mono">orden: {cat.orden}</span>
                </div>
                <p className="text-xs text-gray-500 mt-1 line-clamp-2">
                  {cat.descripcion || <span className="italic text-gray-400">Sin descripcion</span>}
                </p>
              </div>
              <div className="flex gap-1 flex-shrink-0">
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => handleToggleActivo(cat)}
                  title={cat.activo ? 'Desactivar' : 'Activar'}
                  className={cat.activo ? 'text-orange-500' : 'text-green-600'}
                >
                  {cat.activo ? <PowerOff className="w-4 h-4" /> : <Power className="w-4 h-4" />}
                </Button>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => handleAbrirModalEditar(cat)}
                  title="Editar"
                >
                  <Edit2 className="w-4 h-4" />
                </Button>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => handleEliminar(cat)}
                  className="text-red-600"
                  disabled={eliminandoId === cat.id}
                  title="Eliminar"
                >
                  {eliminandoId === cat.id ? (
                    <Loader2 className="w-4 h-4 animate-spin" />
                  ) : (
                    <Trash2 className="w-4 h-4" />
                  )}
                </Button>
              </div>
            </div>
          ))}
        </div>
      )}

      <Modal
        isOpen={modalAbierto}
        onClose={() => !guardando && setModalAbierto(false)}
        title={form.id ? 'Editar Categoria' : 'Nueva Categoria'}
        size="lg"
      >
        <form onSubmit={handleGuardar} className="space-y-3 pt-2">
          <div>
            <label className="block text-xs font-medium mb-1">Nombre *</label>
            <input
              type="text"
              value={form.nombre}
              onChange={(e) => setForm({ ...form, nombre: e.target.value })}
              required
              maxLength={100}
              className="input-base text-sm"
              placeholder="Ej: Sistemas / Software"
            />
            <p className="text-[10px] text-gray-400 mt-1">
              El nombre debe ser unico. Se usara para agrupar productos y servicios.
            </p>
          </div>
          <div>
            <label className="block text-xs font-medium mb-1">Descripcion</label>
            <textarea
              value={form.descripcion}
              onChange={(e) => setForm({ ...form, descripcion: e.target.value })}
              rows={2}
              maxLength={500}
              className="input-base text-sm"
              placeholder="Breve descripcion de la categoria"
            />
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-medium mb-1">Orden</label>
              <input
                type="number"
                value={form.orden}
                onChange={(e) => setForm({ ...form, orden: Number(e.target.value) })}
                className="input-base text-sm"
                placeholder="0"
              />
              <p className="text-[10px] text-gray-400 mt-1">Menor numero = aparece primero</p>
            </div>
            <div>
              <label className="block text-xs font-medium mb-1">Estado</label>
              <select
                value={form.activo ? '1' : '0'}
                onChange={(e) => setForm({ ...form, activo: e.target.value === '1' })}
                className="input-base text-sm"
              >
                <option value="1">Activa (visible al publico)</option>
                <option value="0">Inactiva (oculta)</option>
              </select>
            </div>
          </div>
          <div>
            <label className="block text-xs font-medium mb-1">URL de imagen (opcional)</label>
            <input
              type="text"
              value={form.imagen_url}
              onChange={(e) => setForm({ ...form, imagen_url: e.target.value })}
              className="input-base text-sm"
              placeholder="https://... o ruta de Storage"
            />
          </div>
          <div className="pt-3 flex justify-end gap-2">
            <Button
              variant="outline"
              size="sm"
              type="button"
              onClick={() => setModalAbierto(false)}
              disabled={guardando}
            >
              Cancelar
            </Button>
            <Button size="sm" type="submit" disabled={guardando}>
              {guardando ? (
                <>
                  <Loader2 className="w-4 h-4 mr-1 animate-spin" /> Guardando...
                </>
              ) : (
                'Guardar'
              )}
            </Button>
          </div>
        </form>
      </Modal>
    </div>
  )
}
