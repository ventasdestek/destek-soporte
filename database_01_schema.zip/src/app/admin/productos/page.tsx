'use client'

import { useEffect, useState } from 'react'
import { Plus, Search, Edit2, Trash2, Loader2 } from 'lucide-react'
import { Button, Badge, Modal } from '@/components/ui'
import { formatPrice, CURRENCY_CONFIG } from '@/utils/format'
import { createClient } from '@/lib/supabase/client'
import toast from 'react-hot-toast'

interface Categoria {
  id: string
  nombre: string
}

interface Producto {
  id: string
  nombre: string
  descripcion: string | null
  precio: number
  stock: number
  categoria_id: string | null
  imagen_url: string | null
  activo: boolean
  categoria_nombre?: string | null
}

interface ProductoForm {
  id?: string
  nombre: string
  descripcion: string
  precio: number
  stock: number
  categoria_id: string
  imagen_url: string
  activo: boolean
}

const emptyForm: ProductoForm = {
  nombre: '',
  descripcion: '',
  precio: 0,
  stock: 0,
  categoria_id: '',
  imagen_url: '',
  activo: true,
}

export default function AdminProductosPage() {
  const supabase = createClient()
  const [productos, setProductos] = useState<Producto[]>([])
  const [categorias, setCategorias] = useState<Categoria[]>([])
  const [busqueda, setBusqueda] = useState('')
  const [loading, setLoading] = useState(true)
  const [guardando, setGuardando] = useState(false)
  const [eliminandoId, setEliminandoId] = useState<string | null>(null)
  const [modalAbierto, setModalAbierto] = useState(false)
  const [form, setForm] = useState<ProductoForm>(emptyForm)
  // Cargar productos + categorias desde Supabase al montar
  const cargarDatos = async () => {
    setLoading(true)
    try {
      const [{ data: prods, error: pErr }, { data: cats, error: cErr }] = await Promise.all([
        supabase
          .from('productos')
          .select('*, categorias(nombre)')
          .order('orden', { ascending: true })
          .order('created_at', { ascending: false }),
        supabase
          .from('categorias')
          .select('id, nombre')
          .eq('activo', true)
          .order('orden', { ascending: true }),
      ])

      if (pErr) throw pErr
      if (cErr) throw cErr

      const productosFormateados: Producto[] = (prods || []).map((p: any) => ({
        id: p.id,
        nombre: p.nombre,
        descripcion: p.descripcion,
        precio: Number(p.precio) || 0,
        stock: Number(p.stock) || 0,
        categoria_id: p.categoria_id,
        imagen_url: p.imagen_url,
        activo: p.activo,
        categoria_nombre: p.categorias?.nombre || null,
      }))

      setProductos(productosFormateados)
      setCategorias(cats || [])
    } catch (err: any) {
      console.error('[admin/productos] Error al cargar:', err)
      toast.error('Error al cargar productos: ' + (err?.message || 'desconocido'))
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    cargarDatos()
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  const handleAbrirModalNuevo = () => {
    setForm({ ...emptyForm, categoria_id: categorias[0]?.id || '' })
    setModalAbierto(true)
  }

  const handleAbrirModalEditar = (item: Producto) => {
    setForm({
      id: item.id,
      nombre: item.nombre,
      descripcion: item.descripcion || '',
      precio: item.precio,
      stock: item.stock,
      categoria_id: item.categoria_id || '',
      imagen_url: item.imagen_url || '',
      activo: item.activo,
    })
    setModalAbierto(true)
  }

  const handleGuardar = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!form.nombre.trim()) {
      toast.error('El nombre es obligatorio')
      return
    }
    if (form.precio < 0 || form.stock < 0) {
      toast.error('Precio y stock no pueden ser negativos')
      return
    }

    setGuardando(true)
    try {
      const payload = {
        nombre: form.nombre.trim(),
        descripcion: form.descripcion.trim() || null,
        precio: form.precio,
        stock: form.stock,
        categoria_id: form.categoria_id || null,
        imagen_url: form.imagen_url.trim() || null,
        activo: form.activo,
      }

      if (form.id) {
        // UPDATE
        const { error } = await supabase
          .from('productos')
          .update(payload)
          .eq('id', form.id)
        if (error) throw error
        toast.success('Producto actualizado')
      } else {
        // INSERT
        const { error } = await supabase
          .from('productos')
          .insert(payload)
        if (error) throw error
        toast.success('Producto creado')
      }

      setModalAbierto(false)
      await cargarDatos()
    } catch (err: any) {
      console.error('[admin/productos] Error al guardar:', err)
      toast.error('Error al guardar: ' + (err?.message || 'desconocido'))
    } finally {
      setGuardando(false)
    }
  }

  const handleEliminar = async (id: string) => {
    if (!confirm('¿Eliminar este producto? Esta acción no se puede deshacer.')) return
    setEliminandoId(id)
    try {
      const { error } = await supabase.from('productos').delete().eq('id', id)
      if (error) throw error
      toast.success('Producto eliminado')
      await cargarDatos()
    } catch (err: any) {
      console.error('[admin/productos] Error al eliminar:', err)
      toast.error('Error al eliminar: ' + (err?.message || 'desconocido'))
    } finally {
      setEliminandoId(null)
    }
  }

  const filtrados = productos.filter((p) =>
    p.nombre.toLowerCase().includes(busqueda.toLowerCase())
  )

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold text-gray-900 dark:text-white">Gestión de Productos</h1>
          <p className="text-xs text-gray-500 mt-0.5">
            {productos.length} producto{productos.length === 1 ? '' : 's'} en catálogo
          </p>
        </div>
        <Button onClick={handleAbrirModalNuevo} size="sm" disabled={loading || categorias.length === 0}>
          <Plus className="w-4 h-4 mr-1" /> Nuevo Producto
        </Button>
      </div>

      <div className="card-base p-3">
        <div className="relative max-w-sm">
          <input
            type="text"
            placeholder="Buscar por nombre..."
            value={busqueda}
            onChange={(e) => setBusqueda(e.target.value)}
            className="input-base pl-9 text-sm py-1.5"
          />
          <Search className="w-4 h-4 text-gray-400 absolute left-3 top-1/2 -translate-y-1/2" />
        </div>
      </div>

      <div className="card-base overflow-hidden">
        {loading ? (
          <div className="p-12 flex items-center justify-center text-gray-500">
            <Loader2 className="w-5 h-5 mr-2 animate-spin" /> Cargando productos...
          </div>
        ) : filtrados.length === 0 ? (
          <div className="p-12 text-center text-gray-500">
            <p className="text-sm">
              {productos.length === 0
                ? 'No hay productos todavía. Crea el primero con el botón "Nuevo Producto".'
                : 'No se encontraron productos con esa búsqueda.'}
            </p>
          </div>
        ) : (
          <table className="w-full text-left text-sm">
            <thead className="bg-gray-50 dark:bg-gray-800 text-xs uppercase text-gray-400 border-b border-gray-200 dark:border-gray-800">
              <tr>
                <th className="p-3">Nombre</th>
                <th className="p-3">Categoría</th>
                <th className="p-3">Precio</th>
                <th className="p-3">Stock</th>
                <th className="p-3">Estado</th>
                <th className="p-3 text-right">Acciones</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100 dark:divide-gray-800">
              {filtrados.map((item) => (
                <tr key={item.id} className="hover:bg-gray-50 dark:hover:bg-gray-800/30">
                  <td className="p-3 font-semibold text-gray-900 dark:text-white">{item.nombre}</td>
                  <td className="p-3 text-gray-500">{item.categoria_nombre || '—'}</td>
                  <td className="p-3 font-bold text-primary-600">{formatPrice(item.precio)}</td>
                  <td className="p-3 font-mono">{item.stock} uds.</td>
                  <td className="p-3">
                    <Badge variant={item.activo ? 'success' : 'secondary'}>
                      {item.activo ? 'Activo' : 'Inactivo'}
                    </Badge>
                  </td>
                  <td className="p-3 text-right space-x-1">
                    <Button variant="ghost" size="sm" onClick={() => handleAbrirModalEditar(item)}>
                      <Edit2 className="w-4 h-4" />
                    </Button>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => handleEliminar(item.id)}
                      className="text-red-600"
                      disabled={eliminandoId === item.id}
                    >
                      {eliminandoId === item.id ? (
                        <Loader2 className="w-4 h-4 animate-spin" />
                      ) : (
                        <Trash2 className="w-4 h-4" />
                      )}
                    </Button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>

      <Modal
        isOpen={modalAbierto}
        onClose={() => !guardando && setModalAbierto(false)}
        title={form.id ? 'Editar Producto' : 'Nuevo Producto'}
        size="lg"
      >
        <form onSubmit={handleGuardar} className="space-y-3 pt-2">
          <div>
            <label className="block text-xs font-medium mb-1">Nombre *</label>
            <input
              type="text"
              value={form.nombre}
              onChange={(e) => setForm({ ...form, nombre: e.target.value })}
              required
              className="input-base text-sm"
              placeholder="Ej: Camara IP 4K"
            />
          </div>
          <div>
            <label className="block text-xs font-medium mb-1">Descripcion</label>
            <textarea
              value={form.descripcion}
              onChange={(e) => setForm({ ...form, descripcion: e.target.value })}
              rows={2}
              className="input-base text-sm"
              placeholder="Descripcion breve del producto"
            />
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-medium mb-1">Categoria</label>
              <select
                value={form.categoria_id}
                onChange={(e) => setForm({ ...form, categoria_id: e.target.value })}
                className="input-base text-sm"
                disabled={categorias.length === 0}
              >
                <option value="">-- Sin categoria --</option>
                {categorias.map((c) => (
                  <option key={c.id} value={c.id}>{c.nombre}</option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-xs font-medium mb-1">Precio ({CURRENCY_CONFIG.code}) *</label>
              <input
                type="number"
                step="0.01"
                min="0"
                value={form.precio}
                onChange={(e) => setForm({ ...form, precio: Number(e.target.value) })}
                className="input-base text-sm"
                required
              />
            </div>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-medium mb-1">Stock</label>
              <input
                type="number"
                min="0"
                value={form.stock}
                onChange={(e) => setForm({ ...form, stock: Number(e.target.value) })}
                className="input-base text-sm"
              />
            </div>
            <div>
              <label className="block text-xs font-medium mb-1">Estado</label>
              <select
                value={form.activo ? '1' : '0'}
                onChange={(e) => setForm({ ...form, activo: e.target.value === '1' })}
                className="input-base text-sm"
              >
                <option value="1">Activo (visible al publico)</option>
                <option value="0">Inactivo (oculto)</option>
              </select>
            </div>
          </div>
          <div>
            <label className="block text-xs font-medium mb-1">URL de imagen (opcional)</label>
            <input
              type="text"
              value={form.imagen_url}
              onChange={(e) => setForm({ ...form, imagen_url: e.target.value })}
              className="input-base text-sm"
              placeholder="https://... o ruta de Storage"
            />
          </div>
          <div className="pt-3 flex justify-end gap-2">
            <Button variant="outline" size="sm" type="button" onClick={() => setModalAbierto(false)} disabled={guardando}>
              Cancelar
            </Button>
            <Button size="sm" type="submit" disabled={guardando}>
              {guardando ? <><Loader2 className="w-4 h-4 mr-1 animate-spin" /> Guardando...</> : 'Guardar'}
            </Button>
          </div>
        </form>
      </Modal>
    </div>
  )
}
