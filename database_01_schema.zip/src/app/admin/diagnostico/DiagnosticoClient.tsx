'use client'

import { useState, useCallback, useEffect } from 'react'
import {
  Activity, RefreshCw, CheckCircle2, XCircle, AlertTriangle,
  Database, Zap, Clock, Server, Table2, ShieldCheck
} from 'lucide-react'
import { Button, Badge } from '@/components/ui'
import { cn } from '@/utils/cn'

interface TableCheck {
  name: string
  accessible: boolean
  rows: number | null
  error?: string
}

interface Check {
  name: string
  status: 'ok' | 'fail' | 'warn'
  message: string
  durationMs?: number
}

interface DiagnosticoResult {
  ok: boolean
  timestamp: string
  latencyMs: number
  supabase: { url: string; host: string; restStatus: number }
  summary: string
  checks: Check[]
  tables: TableCheck[]
}

type Status = 'idle' | 'loading' | 'success' | 'error'

function StatusIcon({ status }: { status: Check['status'] }) {
  if (status === 'ok') return <CheckCircle2 className="w-5 h-5 text-green-500" />
  if (status === 'warn') return <AlertTriangle className="w-5 h-5 text-yellow-500" />
  return <XCircle className="w-5 h-5 text-red-500" />
}

function StatusBadge({ ok }: { ok: boolean }) {
  if (ok) return <Badge variant="success">Operativo</Badge>
  return <Badge variant="danger">Con problemas</Badge>
}

function formatDate(iso: string) {
  try {
    return new Date(iso).toLocaleString('es-ES', {
      day: '2-digit', month: '2-digit', year: 'numeric',
      hour: '2-digit', minute: '2-digit', second: '2-digit',
    })
  } catch {
    return iso
  }
}

export default function DiagnosticoClient() {
  const [result, setResult] = useState<DiagnosticoResult | null>(null)
  const [status, setStatus] = useState<Status>('idle')
  const [errorMsg, setErrorMsg] = useState<string | null>(null)
  const [autoCheck, setAutoCheck] = useState(true)

  const runCheck = useCallback(async () => {
    setStatus('loading')
    setErrorMsg(null)
    try {
      const res = await fetch('/api/admin/diagnostico', {
        method: 'GET',
        cache: 'no-store',
        headers: { 'Cache-Control': 'no-cache' },
      })
      const data: DiagnosticoResult = await res.json()
      if (!res.ok) {
        setStatus('error')
        setErrorMsg((data as any).error || `Error HTTP ${res.status}`)
        return
      }
      setResult(data)
      setStatus('success')
    } catch (e) {
      setStatus('error')
      setErrorMsg((e as Error).message || 'Error de red al consultar la API')
    }
  }, [])

  useEffect(() => {
    if (autoCheck) {
      runCheck()
      setAutoCheck(false)
    }
  }, [autoCheck, runCheck])

  const isLoading = status === 'loading'

  return (
    <div className="space-y-6">
      {/* Cabecera */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl md:text-3xl font-bold text-gray-900 dark:text-white flex items-center gap-3">
            <Activity className="w-7 h-7 text-primary-500" />
            Diagnostico de Base de Datos
          </h1>
          <p className="text-sm text-gray-600 dark:text-gray-400 mt-1">
            Verificacion en tiempo real de la conexion entre Vercel y Supabase.
          </p>
        </div>
        <div className="flex items-center gap-3">
          {result && (
            <div className="flex items-center gap-2 text-xs text-gray-500">
              <Clock className="w-3.5 h-3.5" />
              <span>Ultima revision: {formatDate(result.timestamp)}</span>
            </div>
          )}
          <Button
            onClick={runCheck}
            disabled={isLoading}
            size="md"
            aria-label="Verificar conexion con la base de datos"
          >
            <RefreshCw className={cn('w-4 h-4 mr-2', isLoading && 'animate-spin')} />
            {isLoading ? 'Verificando...' : 'Verificar conexion ahora'}
          </Button>
        </div>
      </div>

      {/* Estado de error */}
      {status === 'error' && errorMsg && (
        <div className="card-base p-6 border-l-4 border-red-500 bg-red-50 dark:bg-red-950/20">
          <div className="flex items-start gap-3">
            <XCircle className="w-6 h-6 text-red-500 flex-shrink-0 mt-0.5" />
            <div>
              <p className="font-semibold text-red-700 dark:text-red-400">No se pudo ejecutar la verificacion</p>
              <p className="text-sm text-red-600 dark:text-red-300 mt-1">{errorMsg}</p>
              <p className="text-xs text-red-600 dark:text-red-400 mt-2">
                Comprueba que estas autenticado como administrador y que la API responde.
              </p>
            </div>
          </div>
        </div>
      )}

      {result && (
        <>
          {/* Tarjeta resumen */}
          <div className={cn(
            'card-base p-6 border-l-4',
            result.ok ? 'border-l-green-500' : 'border-l-red-500'
          )}>
            <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
              <div className="flex items-start gap-4">
                {result.ok ? (
                  <div className="w-12 h-12 rounded-2xl bg-green-100 dark:bg-green-950/40 flex items-center justify-center flex-shrink-0">
                    <ShieldCheck className="w-6 h-6 text-green-600" />
                  </div>
                ) : (
                  <div className="w-12 h-12 rounded-2xl bg-red-100 dark:bg-red-950/40 flex items-center justify-center flex-shrink-0">
                    <XCircle className="w-6 h-6 text-red-600" />
                  </div>
                )}
                <div>
                  <div className="flex items-center gap-2 mb-1">
                    <h2 className="text-lg font-bold text-gray-900 dark:text-white">
                      {result.ok ? 'Conexion correcta' : 'Conexion con problemas'}
                    </h2>
                    <StatusBadge ok={result.ok} />
                  </div>
                  <p className="text-sm text-gray-600 dark:text-gray-400">{result.summary}</p>
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4 md:gap-6 text-sm">
                <div>
                  <p className="text-xs text-gray-500 uppercase tracking-wide">Latencia total</p>
                  <p className="text-xl font-bold text-gray-900 dark:text-white flex items-center gap-1.5">
                    <Zap className="w-4 h-4 text-primary-500" />
                    {result.latencyMs} ms
                  </p>
                </div>
                <div>
                  <p className="text-xs text-gray-500 uppercase tracking-wide">Endpoint REST</p>
                  <p className="text-xl font-bold text-gray-900 dark:text-white flex items-center gap-1.5">
                    <Server className="w-4 h-4 text-primary-500" />
                    HTTP {result.supabase.restStatus}
                  </p>
                </div>
              </div>
            </div>
          </div>

          {/* Metricas rapidas */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="card-base p-5">
              <div className="flex items-center gap-2 text-xs text-gray-500 uppercase tracking-wide">
                <Database className="w-3.5 h-3.5" />
                Host Supabase
              </div>
              <p className="mt-2 text-sm font-mono text-gray-900 dark:text-white break-all">
                {result.supabase.host}
              </p>
            </div>
            <div className="card-base p-5">
              <div className="flex items-center gap-2 text-xs text-gray-500 uppercase tracking-wide">
                <CheckCircle2 className="w-3.5 h-3.5" />
                Verificaciones OK
              </div>
              <p className="mt-2 text-2xl font-bold text-gray-900 dark:text-white">
                {result.checks.filter(c => c.status === 'ok').length}
                <span className="text-sm text-gray-400 font-normal">
                  {' / '}{result.checks.length}
                </span>
              </p>
            </div>
            <div className="card-base p-5">
              <div className="flex items-center gap-2 text-xs text-gray-500 uppercase tracking-wide">
                <Table2 className="w-3.5 h-3.5" />
                Tablas accesibles
              </div>
              <p className="mt-2 text-2xl font-bold text-gray-900 dark:text-white">
                {result.tables.filter(t => t.accessible).length}
                <span className="text-sm text-gray-400 font-normal">
                  {' / '}{result.tables.length}
                </span>
              </p>
            </div>
          </div>

          {/* Lista de checks */}
          <div className="card-base p-6">
            <h3 className="text-lg font-bold text-gray-900 dark:text-white mb-4">Verificaciones detalladas</h3>
            <div className="space-y-2">
              {result.checks.map((c, i) => (
                <div
                  key={i}
                  className={cn(
                    'flex items-center justify-between gap-3 p-3 rounded-xl border',
                    c.status === 'ok' && 'border-green-200 dark:border-green-900/40 bg-green-50/50 dark:bg-green-950/10',
                    c.status === 'warn' && 'border-yellow-200 dark:border-yellow-900/40 bg-yellow-50/50 dark:bg-yellow-950/10',
                    c.status === 'fail' && 'border-red-200 dark:border-red-900/40 bg-red-50/50 dark:bg-red-950/10',
                  )}
                >
                  <div className="flex items-center gap-3 min-w-0">
                    <StatusIcon status={c.status} />
                    <div className="min-w-0">
                      <p className="text-sm font-semibold text-gray-900 dark:text-white">{c.name}</p>
                      <p className="text-xs text-gray-600 dark:text-gray-400 truncate">{c.message}</p>
                    </div>
                  </div>
                  {c.durationMs !== undefined && (
                    <span className="text-xs font-mono text-gray-500 flex-shrink-0">
                      {c.durationMs} ms
                    </span>
                  )}
                </div>
              ))}
            </div>
          </div>
        </>
      )}
    </div>
  )
}
