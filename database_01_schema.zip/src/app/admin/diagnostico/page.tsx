import DiagnosticoClient from './DiagnosticoClient'

// Forzar renderizado dinamico: cada peticion lee datos frescos
export const dynamic = 'force-dynamic'
export const revalidate = 0

export default function DiagnosticoPage() {
  return <DiagnosticoClient />
}
