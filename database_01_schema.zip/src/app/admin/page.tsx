import { createClient } from '@/lib/supabase/server'
import AdminDashboardClient, { AdminStats, RecentOrder } from './AdminDashboardClient'

// Forzar renderizado dinámico: cada petición lee datos frescos de Supabase
export const dynamic = 'force-dynamic'
export const revalidate = 0

async function loadDashboardData(): Promise<{ stats: AdminStats; recentOrders: RecentOrder[] }> {
  // Valores por defecto (estado vacío / recién reseteado)
  const empty: AdminStats = {
    total_clientes: 0,
    total_servicios: 0,
    total_productos: 0,
    pedidos_pendientes: 0,
    pedidos_completados: 0,
    ingreso_total: 0,
    mensajes_no_leidos: 0,
  }

  try {
    const supabase = await createClient()

    // 1) Estadísticas agregadas desde la vista admin_stats
    const { data: statsData, error: statsError } = await supabase
      .from('admin_stats')
      .select('*')
      .single()

    // 2) Últimos pedidos con datos del cliente (vía pedidos_con_cliente)
    const { data: ordersData, error: ordersError } = await supabase
      .from('pedidos_con_cliente')
      .select('id, item, total, estado, tipo, created_at, nombre, apellido, email')
      .order('created_at', { ascending: false })
      .limit(5)

    if (statsError) {
      console.error('[admin/page] Error en admin_stats:', statsError.message)
    }
    if (ordersError) {
      console.error('[admin/page] Error en pedidos_con_cliente:', ordersError.message)
    }

    const stats: AdminStats = statsData
      ? {
          total_clientes: Number(statsData.total_clientes) || 0,
          total_servicios: Number(statsData.total_servicios) || 0,
          total_productos: Number(statsData.total_productos) || 0,
          pedidos_pendientes: Number(statsData.pedidos_pendientes) || 0,
          pedidos_completados: Number(statsData.pedidos_completados) || 0,
          ingreso_total: Number(statsData.ingreso_total) || 0,
          mensajes_no_leidos: Number(statsData.mensajes_no_leidos) || 0,
        }
      : empty

    const recentOrders: RecentOrder[] = (ordersData || []).map((o: any) => {
      const nombre = o.nombre || ''
      const apellido = o.apellido || ''
      const fullName = [nombre, apellido].filter(Boolean).join(' ').trim()
      return {
        id: o.id,
        cliente: fullName || o.email || 'Cliente',
        email: o.email || '',
        tipo: (o.tipo as 'producto' | 'servicio') || 'producto',
        item: o.item || '—',
        total: Number(o.total) || 0,
        estado: o.estado as RecentOrder['estado'],
        created_at: o.created_at,
      }
    })

    return { stats, recentOrders }
  } catch (err) {
    console.error('[admin/page] Error inesperado:', err)
    return { stats: empty, recentOrders: [] }
  }
}

export default async function AdminDashboardPage() {
  const { stats, recentOrders } = await loadDashboardData()
  return <AdminDashboardClient stats={stats} recentOrders={recentOrders} />
}

