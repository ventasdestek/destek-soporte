'use client'

import { useState, useEffect } from 'react'
import { Save, Building, Phone, Globe, Share2, Loader2 } from 'lucide-react'
import { Button } from '@/components/ui'
import { COMPANY_CONFIG } from '@/lib/constants'
import toast from 'react-hot-toast'

// Mapeo entre los nombres que usa el formulario y las claves reales en la BD
// (todas se guardan con prefijo 'public_' en la tabla 'configuracion')
const FIELD_TO_KEY: Record<string, string> = {
  name: 'company_name',
  tagline: 'company_tagline',
  phone: 'contact_phone',
  email: 'contact_email',
  address: 'contact_address',
  whatsapp: 'contact_whatsapp',
  heroTitle: 'hero_title',
  heroSubtitle: 'hero_subtitle',
  socialFacebook: 'social_facebook',
  socialTwitter: 'social_twitter',
  socialLinkedin: 'social_linkedin',
  socialInstagram: 'social_instagram',
  socialYoutube: 'social_youtube',
  seoTitle: 'seo_title',
  seoDescription: 'seo_description',
}

export default function AdminConfiguracionPage() {
  const [loading, setLoading] = useState(true)
  const [saving, setSaving] = useState(false)

  const valoresPorDefecto = {
    name: COMPANY_CONFIG.name,
    tagline: COMPANY_CONFIG.tagline,
    phone: COMPANY_CONFIG.phone,
    email: COMPANY_CONFIG.email,
    address: COMPANY_CONFIG.address,
    whatsapp: COMPANY_CONFIG.whatsapp,
    heroTitle: 'Soluciones Tecnológicas Integrales para Tu Empresa',
    heroSubtitle: 'Soporte técnico remoto, mantenimiento de servidores y sistemas de videovigilancia profesional.',
    socialFacebook: 'https://facebook.com',
    socialTwitter: 'https://twitter.com',
    socialLinkedin: 'https://linkedin.com',
    socialInstagram: 'https://instagram.com',
    socialYoutube: 'https://youtube.com',
    seoTitle: 'Destek Soporte | Servicios Tecnológicos, Soporte y Desarrollo',
    seoDescription: 'Empresa de servicios tecnológicos: asesoría, soporte remoto, desarrollo de software a medida y venta de hardware.',
  }

  const [config, setConfig] = useState(valoresPorDefecto)

  // Cargar configuración actual desde el API al montar
  const cargarConfig = async () => {
    setLoading(true)
    try {
      const res = await fetch('/api/admin/configuracion', { cache: 'no-store' })
      const data = await res.json()
      if (!res.ok) throw new Error(data.error || 'Error al cargar')

      // data.public es un array de { clave, valor } ya sin prefijo 'public_'
      const mapa: Record<string, any> = {}
      const reverseMap: Record<string, string> = {}
      Object.entries(FIELD_TO_KEY).forEach(([field, key]) => {
        reverseMap[key] = field
      })

      if (Array.isArray(data.public)) {
        data.public.forEach((c: { clave: string; valor: any }) => {
          const field = reverseMap[c.clave]
          if (field) {
            mapa[field] = typeof c.valor === 'string' ? c.valor : JSON.stringify(c.valor)
          }
        })
      }
      setConfig((prev) => ({ ...prev, ...mapa }))
    } catch (err) {
      console.error('[admin/configuracion] Error cargando:', err)
      toast.error('No se pudo cargar la configuración: ' + (err as Error).message)
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    cargarConfig()
  }, [])

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setConfig({ ...config, [e.target.name]: e.target.value })
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setSaving(true)
    try {
      // Traducir del nombre del campo al nombre real de la clave en BD
      const payload: Record<string, any> = {}
      Object.entries(config).forEach(([field, value]) => {
        const realKey = FIELD_TO_KEY[field] || field
        payload[realKey] = value
      })

      const res = await fetch('/api/admin/configuracion', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      })
      const data = await res.json()
      if (!res.ok) throw new Error(data.error || 'Error al guardar')

      toast.success('Configuración guardada correctamente')
      // Refrescar desde la BD para confirmar persistencia
      await cargarConfig()
    } catch (err) {
      console.error('[admin/configuracion] Error guardando:', err)
      toast.error('Error al guardar: ' + (err as Error).message)
    } finally {
      setSaving(false)
    }
  }

  return (
    <div className="space-y-6 max-w-4xl">
      <div>
        <h1 className="text-2xl font-bold text-gray-900 dark:text-white">Configuración del Sitio Web</h1>
        <p className="text-xs text-gray-500 mt-0.5">Edita la información pública de contacto, títulos hero y enlaces oficiales.</p>
      </div>

      {loading && (
        <div className="card-base p-12 flex items-center justify-center text-gray-500">
          <Loader2 className="w-5 h-5 mr-2 animate-spin" /> Cargando configuración...
        </div>
      )}

      <form onSubmit={handleSubmit} className="space-y-6">
        <div className="card-base p-6 space-y-4">
          <h2 className="text-lg font-bold text-gray-900 dark:text-white flex items-center gap-2">
            <Building className="w-5 h-5 text-primary-600" /> Información Institucional
          </h2>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-medium mb-1">Nombre Comercial</label>
              <input type="text" name="name" value={config.name} onChange={handleChange} className="input-base text-sm" />
            </div>
            <div>
              <label className="block text-xs font-medium mb-1">Eslogan Principal</label>
              <input type="text" name="tagline" value={config.tagline} onChange={handleChange} className="input-base text-sm" />
            </div>
          </div>

          <div>
            <label className="block text-xs font-medium mb-1">Título Banner Principal (Hero Home)</label>
            <input type="text" name="heroTitle" value={config.heroTitle} onChange={handleChange} className="input-base text-sm" />
          </div>

          <div>
            <label className="block text-xs font-medium mb-1">Subtítulo Banner Principal</label>
            <textarea name="heroSubtitle" value={config.heroSubtitle} onChange={handleChange} rows={2} className="input-base text-sm" />
          </div>
        </div>

        <div className="card-base p-6 space-y-4">
          <h2 className="text-lg font-bold text-gray-900 dark:text-white flex items-center gap-2">
            <Phone className="w-5 h-5 text-primary-600" /> Canales de Contacto Directo
          </h2>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-medium mb-1">Teléfono Principal</label>
              <input type="text" name="phone" value={config.phone} onChange={handleChange} className="input-base text-sm" />
            </div>
            <div>
              <label className="block text-xs font-medium mb-1">Email de Soporte</label>
              <input type="email" name="email" value={config.email} onChange={handleChange} className="input-base text-sm" />
            </div>
          </div>

          <div>
            <label className="block text-xs font-medium mb-1">Enlace de WhatsApp Directo</label>
            <input type="url" name="whatsapp" value={config.whatsapp} onChange={handleChange} className="input-base text-sm" />
          </div>

          <div>
            <label className="block text-xs font-medium mb-1">Dirección Física</label>
            <input type="text" name="address" value={config.address} onChange={handleChange} className="input-base text-sm" />
          </div>
        </div>

        <div className="flex justify-end">
          <Button type="submit" loading={saving} disabled={loading} size="lg">
            <Save className="w-4 h-4 mr-2" /> Guardar Cambios Globales
          </Button>
        </div>
      </form>
    </div>
  )
}
