'use client'

import Link from 'next/link'
import { usePathname, useRouter } from 'next/navigation'
import {
  LayoutDashboard, Wrench, Package, FolderTree, ShoppingCart, Users,
  Mail, Settings, LogOut, Home, Monitor, ShieldAlert
} from 'lucide-react'
import { useAuth } from '@/components/providers/AuthProvider'
import { ROUTES } from '@/lib/constants'
import { cn } from '@/utils/cn'

const adminNav = [
  { name: 'Dashboard', href: ROUTES.admin, icon: LayoutDashboard },
  { name: 'Servicios', href: `${ROUTES.admin}/servicios`, icon: Wrench },
  { name: 'Productos', href: `${ROUTES.admin}/productos`, icon: Package },
  { name: 'Categorías', href: `${ROUTES.admin}/categorias`, icon: FolderTree },
  { name: 'Pedidos / Solicitudes', href: `${ROUTES.admin}/pedidos`, icon: ShoppingCart },
  { name: 'Usuarios', href: `${ROUTES.admin}/usuarios`, icon: Users },
  { name: 'Mensajes Contacto', href: `${ROUTES.admin}/mensajes`, icon: Mail },
  { name: 'Configuración Web', href: `${ROUTES.admin}/configuracion`, icon: Settings },
]

export default function AdminLayout({ children }: { children: React.ReactNode }) {
  const pathname = usePathname()
  const router = useRouter()
  const { user, signOut } = useAuth()

  return (
    <div className="min-h-screen bg-gray-100 dark:bg-gray-950 flex flex-col md:flex-row">
      {/* Admin Sidebar */}
      <aside className="w-full md:w-64 bg-gray-900 text-white flex-shrink-0">
        <div className="p-6 border-b border-gray-800 flex items-center justify-between">
          <Link href={ROUTES.admin} className="flex items-center gap-2">
            <div className="w-9 h-9 rounded-xl bg-primary-500 flex items-center justify-center text-white font-bold">
              <Monitor className="w-5 h-5" />
            </div>
            <div>
              <span className="font-bold text-base block text-white">Destek Admin</span>
              <span className="text-[10px] uppercase font-semibold text-primary-400 tracking-wider">Panel de Control</span>
            </div>
          </Link>
        </div>

        {/* Admin user info */}
        <div className="p-4 mx-4 my-4 rounded-xl bg-gray-800/80 border border-gray-700/50 flex items-center gap-3">
          <div className="w-9 h-9 rounded-full bg-primary-600 text-white flex items-center justify-center font-bold text-sm">
            <ShieldAlert className="w-5 h-5 text-yellow-400" />
          </div>
          <div className="overflow-hidden">
            <p className="text-xs text-gray-400">Super Admin</p>
            <p className="text-sm font-semibold text-white truncate">{user?.email || 'admin@desteksoporte.es'}</p>
          </div>
        </div>

        {/* Navigation */}
        <nav className="p-4 space-y-1">
          {adminNav.map((item) => {
            const isActive = pathname === item.href || (item.href !== ROUTES.admin && pathname.startsWith(item.href))
            return (
              <Link
                key={item.name}
                href={item.href}
                className={cn(
                  'flex items-center gap-3 px-3.5 py-2.5 text-sm font-medium rounded-xl transition-colors',
                  isActive
                    ? 'bg-primary-600 text-white shadow-sm'
                    : 'text-gray-400 hover:bg-gray-800 hover:text-white'
                )}
              >
                <item.icon className="w-4 h-4" />
                {item.name}
              </Link>
            )
          })}

          <div className="pt-6 mt-6 border-t border-gray-800 space-y-1">
            <Link
              href={ROUTES.home}
              className="flex items-center gap-3 px-3.5 py-2.5 text-sm font-medium text-gray-400 hover:bg-gray-800 hover:text-white rounded-xl transition-colors"
            >
              <Home className="w-4 h-4" />
              Ir al Sitio Público
            </Link>
            <button
              onClick={async () => { await signOut(); router.push(ROUTES.login) }}
              className="w-full flex items-center gap-3 px-3.5 py-2.5 text-sm font-medium text-red-400 hover:bg-red-950/40 rounded-xl transition-colors text-left"
            >
              <LogOut className="w-4 h-4" />
              Cerrar Sesión Admin
            </button>
          </div>
        </nav>
      </aside>

      {/* Main Content */}
      <main className="flex-1 p-6 md:p-10 overflow-y-auto">
        {children}
      </main>
    </div>
  )
}
