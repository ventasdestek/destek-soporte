'use client'

import Link from 'next/link'
import { TrendingUp, Users, Wrench, Mail, ArrowUpRight, Package, ShoppingBag, MessageSquare } from 'lucide-react'
import { Button, Badge } from '@/components/ui'
import { formatPrice } from '@/utils/format'
import { ROUTES } from '@/lib/constants'

export interface AdminStats {
  total_clientes: number
  total_servicios: number
  total_productos: number
  pedidos_pendientes: number
  pedidos_completados: number
  ingreso_total: number
  mensajes_no_leidos: number
}

export interface RecentOrder {
  id: string
  cliente: string
  email: string
  tipo: 'producto' | 'servicio'
  item: string
  total: number
  estado: 'pendiente' | 'procesando' | 'completado' | 'cancelado'
  created_at: string
}

interface Props {
  stats: AdminStats
  recentOrders: RecentOrder[]
}

export default function AdminDashboardClient({ stats, recentOrders }: Props) {
  const hasIngresos = Number(stats.ingreso_total) > 0
  const ventasChange = hasIngresos
    ? `+${stats.pedidos_completados} cerrados`
    : 'Sin ventas aún'

  const cards = [
    {
      name: 'Ventas / Pedidos',
      value: formatPrice(Number(stats.ingreso_total) || 0),
      change: ventasChange,
      icon: TrendingUp,
      color: 'text-green-500 bg-green-50 dark:bg-green-950/40',
    },
    {
      name: 'Clientes Registrados',
      value: String(stats.total_clientes || 0),
      change: stats.total_clientes > 0 ? `${stats.total_clientes} total` : 'Sin clientes',
      icon: Users,
      color: 'text-blue-500 bg-blue-50 dark:bg-blue-950/40',
    },
    {
      name: 'Servicios Activos',
      value: String(stats.total_servicios || 0),
      change: 'En catálogo',
      icon: Wrench,
      color: 'text-purple-500 bg-purple-50 dark:bg-purple-950/40',
    },
    {
      name: 'Mensajes Contacto',
      value: String(stats.mensajes_no_leidos || 0),
      change: stats.mensajes_no_leidos > 0 ? 'Sin leer' : 'Al día',
      icon: Mail,
      color: 'text-orange-500 bg-orange-50 dark:bg-orange-950/40',
    },
  ]
  return (
    <div className="space-y-8">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl md:text-3xl font-bold text-gray-900 dark:text-white">Panel de Administración</h1>
          <p className="text-sm text-gray-600 dark:text-gray-400 mt-1">Resumen global de actividad e ingresos (datos en tiempo real).</p>
        </div>
        <div className="flex items-center gap-3">
          <Link href={`${ROUTES.admin}/productos`}><Button variant="outline" size="sm"><Package className="w-4 h-4 mr-2" /> Productos</Button></Link>
          <Link href={`${ROUTES.admin}/servicios`}><Button size="sm"><Wrench className="w-4 h-4 mr-2" /> Añadir Servicio</Button></Link>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
        {cards.map((stat) => (
          <div key={stat.name} className="card-base p-6">
            <div className="flex items-center justify-between">
              <div className={`p-3 rounded-2xl ${stat.color}`}><stat.icon className="w-6 h-6" /></div>
              <span className="text-xs font-semibold text-gray-500">{stat.change}</span>
            </div>
            <div className="mt-4">
              <p className="text-2xl font-bold text-gray-900 dark:text-white">{stat.value}</p>
              <p className="text-xs font-medium text-gray-500 mt-0.5">{stat.name}</p>
            </div>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
        <div className="card-base p-6 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 rounded-xl bg-yellow-100 dark:bg-yellow-950/40 text-yellow-600 flex items-center justify-center"><ShoppingBag className="w-6 h-6" /></div>
            <div>
              <p className="text-sm font-medium text-gray-500">Pedidos Pendientes</p>
              <p className="text-2xl font-bold text-gray-900 dark:text-white">{stats.pedidos_pendientes}</p>
            </div>
          </div>
          <Link href={`${ROUTES.admin}/pedidos`} className="text-xs text-primary-600 font-semibold flex items-center">Gestionar <ArrowUpRight className="w-4 h-4 ml-1" /></Link>
        </div>
        <div className="card-base p-6 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 rounded-xl bg-emerald-100 dark:bg-emerald-950/40 text-emerald-600 flex items-center justify-center"><MessageSquare className="w-6 h-6" /></div>
            <div>
              <p className="text-sm font-medium text-gray-500">Pedidos Completados</p>
              <p className="text-2xl font-bold text-gray-900 dark:text-white">{stats.pedidos_completados}</p>
            </div>
          </div>
          <Link href={`${ROUTES.admin}/pedidos`} className="text-xs text-primary-600 font-semibold flex items-center">Ver todos <ArrowUpRight className="w-4 h-4 ml-1" /></Link>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 card-base p-6">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-lg font-bold text-gray-900 dark:text-white">Últimas Solicitudes y Pedidos</h2>
            <Link href={`${ROUTES.admin}/pedidos`} className="text-xs text-primary-600 font-semibold flex items-center">Ver todos <ArrowUpRight className="w-4 h-4 ml-1" /></Link>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-left text-sm">
              <thead className="text-xs uppercase text-gray-400 bg-gray-50 dark:bg-gray-800/50 border-b border-gray-200 dark:border-gray-800">
                <tr>
                  <th className="p-3">ID / Cliente</th>
                  <th className="p-3">Tipo</th>
                  <th className="p-3">Total</th>
                  <th className="p-3">Estado</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-100 dark:divide-gray-800">
                {recentOrders.length === 0 ? (
                  <tr>
                    <td colSpan={4} className="p-8 text-center text-gray-500 dark:text-gray-400">
                      <ShoppingBag className="w-10 h-10 mx-auto mb-2 opacity-30" />
                      <p className="text-sm">No hay pedidos todavía.</p>
                      <p className="text-xs text-gray-400 mt-1">Los pedidos reales aparecerán aquí cuando los clientes compren.</p>
                    </td>
                  </tr>
                ) : (
                  recentOrders.map((order) => (
                    <tr key={order.id} className="hover:bg-gray-50 dark:hover:bg-gray-800/30">
                      <td className="p-3 font-medium text-gray-900 dark:text-white">
                        <span className="font-mono text-xs text-primary-600 block">#{order.id.slice(0, 8).toUpperCase()}</span>
                        {order.cliente}
                      </td>
                      <td className="p-3 text-gray-600 dark:text-gray-400">
                        <span>{order.item}</span>
                        <span className="text-xs text-gray-400 ml-1">({order.tipo})</span>
                      </td>
                      <td className="p-3 font-bold text-gray-900 dark:text-white">{formatPrice(Number(order.total))}</td>
                      <td className="p-3">
                        <Badge
                          variant={
                            order.estado === 'completado'
                              ? 'success'
                              : order.estado === 'procesando'
                              ? 'info'
                              : order.estado === 'cancelado'
                              ? 'danger'
                              : 'warning'
                          }
                          className="capitalize text-[11px]"
                        >
                          {order.estado}
                        </Badge>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>

        <div className="card-base p-6 space-y-4">
          <h2 className="text-lg font-bold text-gray-900 dark:text-white">Acceso Rápido</h2>
          <div className="space-y-3">
            <Link href={`${ROUTES.admin}/servicios`} className="block p-3 rounded-xl bg-gray-50 dark:bg-gray-800 hover:bg-primary-50 dark:hover:bg-primary-950/40 border border-gray-200 dark:border-gray-700">
              <p className="text-sm font-semibold text-gray-900 dark:text-white">Catálogo de Servicios</p>
              <p className="text-xs text-gray-500">Editar o publicar servicios</p>
            </Link>
            <Link href={`${ROUTES.admin}/productos`} className="block p-3 rounded-xl bg-gray-50 dark:bg-gray-800 hover:bg-primary-50 dark:hover:bg-primary-950/40 border border-gray-200 dark:border-gray-700">
              <p className="text-sm font-semibold text-gray-900 dark:text-white">Stock y Productos</p>
              <p className="text-xs text-gray-500">Gestionar inventario hardware</p>
            </Link>
            <Link href={`${ROUTES.admin}/mensajes`} className="block p-3 rounded-xl bg-gray-50 dark:bg-gray-800 hover:bg-primary-50 dark:hover:bg-primary-950/40 border border-gray-200 dark:border-gray-700">
              <p className="text-sm font-semibold text-gray-900 dark:text-white">Mensajes de Contacto</p>
              <p className="text-xs text-gray-500">
                {stats.mensajes_no_leidos > 0 ? `${stats.mensajes_no_leidos} sin leer` : 'Bandeja al día'}
              </p>
            </Link>
          </div>
        </div>
      </div>
    </div>
  )
}
