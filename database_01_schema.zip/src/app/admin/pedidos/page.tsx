'use client'

import { useState, useEffect } from 'react'
import { Search, Eye, Loader2, Trash2 } from 'lucide-react'
import { Button, Modal } from '@/components/ui'
import { formatPrice } from '@/utils/format'
import toast from 'react-hot-toast'

type EstadoPedido = 'pendiente' | 'procesando' | 'completado' | 'cancelado'

interface PedidoItem {
  id: string
  cliente: string
  email: string
  tipo: string
  item: string
  monto: number
  estado: EstadoPedido
  notas: string
  fecha: string
}

const estadoColor: Record<EstadoPedido, string> = {
  pendiente: 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900/40 dark:text-yellow-300',
  procesando: 'bg-blue-100 text-blue-800 dark:bg-blue-900/40 dark:text-blue-300',
  completado: 'bg-green-100 text-green-800 dark:bg-green-900/40 dark:text-green-300',
  cancelado: 'bg-red-100 text-red-800 dark:bg-red-900/40 dark:text-red-300',
}

const formatFecha = (iso: string) => {
  try {
    return new Date(iso).toLocaleDateString('es-ES', { year: 'numeric', month: '2-digit', day: '2-digit' })
  } catch {
    return iso
  }
}

const formatId = (uuid: string) => (uuid ? uuid.slice(0, 8).toUpperCase() : '—')

export default function AdminPedidosPage() {
  const [pedidos, setPedidos] = useState<PedidoItem[]>([])
  const [loading, setLoading] = useState(true)
  const [savingId, setSavingId] = useState<string | null>(null)
  const [deletingId, setDeletingId] = useState<string | null>(null)
  const [busqueda, setBusqueda] = useState('')
  const [pedidoSel, setPedidoSel] = useState<PedidoItem | null>(null)

  const cargarPedidos = async () => {
    setLoading(true)
    try {
      const res = await fetch('/api/admin/pedidos', { cache: 'no-store' })
      const data = await res.json()
      if (!res.ok) throw new Error(data.error || 'Error al cargar pedidos')
      setPedidos(data.pedidos || [])
    } catch (err) {
      console.error(err)
      toast.error((err as Error).message)
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    cargarPedidos()
  }, [])

  const handleCambiarEstado = async (id: string, nuevoEstado: EstadoPedido) => {
    const estadoAnterior = pedidos.find((p) => p.id === id)?.estado
    // Actualización optimista
    setPedidos((prev) => prev.map((p) => (p.id === id ? { ...p, estado: nuevoEstado } : p)))
    setSavingId(id)
    try {
      const res = await fetch('/api/admin/pedidos', {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id, estado: nuevoEstado }),
      })
      const data = await res.json()
      if (!res.ok) throw new Error(data.error || 'Error al guardar estado')
      toast.success(`Estado actualizado a "${nuevoEstado}"`)
    } catch (err) {
      // Revertir si falla
      if (estadoAnterior) {
        setPedidos((prev) => prev.map((p) => (p.id === id ? { ...p, estado: estadoAnterior } : p)))
      }
      toast.error((err as Error).message)
    } finally {
      setSavingId(null)
    }
  }

  const handleEliminar = async (id: string) => {
    if (!confirm('¿Eliminar este pedido? Esta acción no se puede deshacer.')) return
    setDeletingId(id)
    try {
      const res = await fetch(`/api/admin/pedidos?id=${id}`, { method: 'DELETE' })
      const data = await res.json()
      if (!res.ok) throw new Error(data.error || 'Error al eliminar')
      toast.success('Pedido eliminado')
      setPedidoSel(null)
      await cargarPedidos()
    } catch (err) {
      toast.error((err as Error).message)
    } finally {
      setDeletingId(null)
    }
  }

  const filtrados = pedidos.filter(
    (p) =>
      p.cliente.toLowerCase().includes(busqueda.toLowerCase()) ||
      p.id.toLowerCase().includes(busqueda.toLowerCase()) ||
      p.item.toLowerCase().includes(busqueda.toLowerCase())
  )

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-gray-900 dark:text-white">Gestión de Pedidos y Solicitudes</h1>
          <p className="text-xs text-gray-500 mt-0.5">Control y actualización de servicios contratados y ventas de productos.</p>
        </div>
        <Button variant="outline" size="sm" onClick={cargarPedidos} disabled={loading}>
          {loading ? <Loader2 className="w-4 h-4 mr-1 animate-spin" /> : null}
          {loading ? 'Cargando...' : 'Recargar'}
        </Button>
      </div>

      <div className="card-base p-3">
        <div className="relative max-w-sm">
          <input
            type="text"
            placeholder="Buscar por cliente, item o ID..."
            value={busqueda}
            onChange={(e) => setBusqueda(e.target.value)}
            className="input-base pl-9 text-sm py-1.5"
          />
          <Search className="w-4 h-4 text-gray-400 absolute left-3 top-1/2 -translate-y-1/2" />
        </div>
      </div>

      <div className="card-base overflow-hidden">
        {loading ? (
          <div className="p-10 text-center text-sm text-gray-500">
            <Loader2 className="w-6 h-6 mx-auto mb-2 animate-spin" />
            Cargando pedidos...
          </div>
        ) : filtrados.length === 0 ? (
          <div className="p-10 text-center text-sm text-gray-500">
            {pedidos.length === 0
              ? 'No hay pedidos registrados todavía.'
              : 'No se encontraron pedidos que coincidan con la búsqueda.'}
          </div>
        ) : (
          <table className="w-full text-left text-sm">
            <thead className="bg-gray-50 dark:bg-gray-800 text-xs uppercase text-gray-400 border-b border-gray-200 dark:border-gray-800">
              <tr>
                <th className="p-3">ID / Cliente</th>
                <th className="p-3">Concepto</th>
                <th className="p-3">Total</th>
                <th className="p-3">Estado</th>
                <th className="p-3 text-right">Acciones</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100 dark:divide-gray-800">
              {filtrados.map((item) => (
                <tr key={item.id} className="hover:bg-gray-50 dark:hover:bg-gray-800/30">
                  <td className="p-3 font-semibold text-gray-900 dark:text-white">
                    <span className="font-mono text-xs text-primary-600 block">#{formatId(item.id)}</span>
                    {item.cliente}
                  </td>
                  <td className="p-3 text-gray-600 dark:text-gray-400">
                    <div className="text-sm">{item.item}</div>
                    <div className="text-xs text-gray-400 capitalize">{item.tipo}</div>
                  </td>
                  <td className="p-3 font-bold text-gray-900 dark:text-white">{formatPrice(item.monto)}</td>
                  <td className="p-3">
                    <div className="flex items-center gap-2">
                      <select
                        value={item.estado}
                        disabled={savingId === item.id}
                        onChange={(e) => handleCambiarEstado(item.id, e.target.value as EstadoPedido)}
                        className={`text-xs font-semibold rounded-lg px-2 py-1 border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800 ${estadoColor[item.estado]}`}
                      >
                        <option value="pendiente">Pendiente</option>
                        <option value="procesando">Procesando</option>
                        <option value="completado">Completado</option>
                        <option value="cancelado">Cancelado</option>
                      </select>
                      {savingId === item.id && <Loader2 className="w-3 h-3 animate-spin text-primary-600" />}
                    </div>
                  </td>
                  <td className="p-3 text-right">
                    <div className="flex justify-end gap-1">
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => setPedidoSel(item)}
                        title="Ver detalle"
                      >
                        <Eye className="w-4 h-4" />
                      </Button>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => handleEliminar(item.id)}
                        className="text-red-600"
                        disabled={deletingId === item.id}
                        title="Eliminar pedido"
                      >
                        {deletingId === item.id ? (
                          <Loader2 className="w-4 h-4 animate-spin" />
                        ) : (
                          <Trash2 className="w-4 h-4" />
                        )}
                      </Button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>

      <Modal isOpen={!!pedidoSel} onClose={() => setPedidoSel(null)} title={`Detalle del Pedido #${pedidoSel ? formatId(pedidoSel.id) : ''}`}>
        {pedidoSel && (
          <div className="space-y-4 pt-2 text-sm">
            <div>
              <p className="text-xs text-gray-400 uppercase">Cliente</p>
              <p className="font-bold text-gray-900 dark:text-white">{pedidoSel.cliente}</p>
              <p className="text-xs text-gray-500">{pedidoSel.email}</p>
            </div>
            <div>
              <p className="text-xs text-gray-400 uppercase">Concepto Contratado</p>
              <p className="font-semibold text-gray-800 dark:text-gray-200">{pedidoSel.item} ({pedidoSel.tipo})</p>
              <p className="text-lg font-bold text-primary-600 mt-1">{formatPrice(pedidoSel.monto)}</p>
            </div>
            <div>
              <p className="text-xs text-gray-400 uppercase">Estado actual</p>
              <span className={`inline-block px-2 py-1 rounded text-xs font-semibold ${estadoColor[pedidoSel.estado]}`}>
                {pedidoSel.estado}
              </span>
            </div>
            {pedidoSel.notas && (
              <div>
                <p className="text-xs text-gray-400 uppercase">Notas</p>
                <p className="text-gray-700 dark:text-gray-300 whitespace-pre-wrap">{pedidoSel.notas}</p>
              </div>
            )}
            <div>
              <p className="text-xs text-gray-400 uppercase">Fecha de Solicitud</p>
              <p className="text-gray-700 dark:text-gray-300">{formatFecha(pedidoSel.fecha)}</p>
            </div>
            <div className="pt-3 flex justify-end">
              <Button size="sm" onClick={() => setPedidoSel(null)}>Cerrar</Button>
            </div>
          </div>
        )}
      </Modal>
    </div>
  )
}
