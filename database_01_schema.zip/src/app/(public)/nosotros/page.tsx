'use client'

import Link from 'next/link'
import { ArrowRight, Users, Target, Heart, Zap, Shield } from 'lucide-react'
import { Button } from '@/components/ui'
import { ROUTES } from '@/lib/constants'

const team = [
  {
    name: 'Carlos Rodríguez',
    role: 'CEO & Fundador',
    description: 'Más de 20 años en IT. Especialista en arquitectura de sistemas.',
    avatar: '👨💼',
  },
  {
    name: 'Ana Martínez',
    role: 'Directora Técnica',
    description: 'Ingeniera en Telecomunicaciones. Experta en redes y ciberseguridad.',
    avatar: '👩💻',
  },
  {
    name: 'David López',
    role: 'Jefe de Soporte',
    description: 'Certificado ITIL y Microsoft. 98% de satisfacción en soporte.',
    avatar: '🧑🔧',
  },
  {
    name: 'Laura García',
    role: 'Responsable Comercial',
    description: 'Especialista en soluciones B2B para empresas.',
    avatar: '👩💼',
  },
]

const values = [
  { icon: Heart, title: 'Compromiso', description: 'Nos comprometemos con cada cliente como si fuera nuestro propio negocio.' },
  { icon: Zap, title: 'Agilidad', description: 'Respondemos rápido porque el tiempo de inactividad cuesta dinero.' },
  { icon: Shield, title: 'Confianza', description: 'Transparencia total en presupuestos. Sin letra pequeña.' },
  { icon: Target, title: 'Excelencia', description: 'Formación continua y certificaciones actualizadas.' },
]

const timeline = [
  { year: '2008', title: 'Fundación', description: 'Nace como taller de reparación de PCs en Madrid.' },
  { year: '2012', title: 'Expansión B2B', description: 'Servicios de mantenimiento para empresas.' },
  { year: '2016', title: 'Servicios Cloud', description: 'Asesoría cloud, migraciones y ciberseguridad.' },
  { year: '2020', title: 'Soporte Remoto 24/7', description: 'Plataforma de soporte remoto en toda España.' },
  { year: '2024', title: 'Partner Certificado', description: 'Microsoft, Google Cloud y Cisco. +500 clientes.' },
]

const stats = [
  { value: '500+', label: 'Clientes activos' },
  { value: '15+', label: 'Años de experiencia' },
  { value: '98%', label: 'Satisfacción' },
  { value: '< 2h', label: 'Tiempo respuesta' },
]

export default function NosotrosPage() {
  return (
    <div className="min-h-screen">
      {/* Hero */}
      <section className="relative overflow-hidden bg-gradient-to-b from-primary-50 to-white dark:from-gray-900 dark:to-gray-950 py-20 md:py-32">
        <div className="section-container">
          <div className="mx-auto max-w-4xl text-center">
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-primary-100 dark:bg-primary-900/30 text-primary-700 dark:text-primary-300 text-sm font-medium mb-6">
              <Users className="w-4 h-4" aria-hidden="true" />
              Sobre nosotros
            </div>
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-gray-900 dark:text-white tracking-tight mb-6">
              Tecnología con{' '}
              <span className="text-gradient">rostro humano</span>
            </h1>
            <p className="text-lg md:text-xl text-gray-600 dark:text-gray-400 max-w-2xl mx-auto leading-relaxed">
              Somos un equipo de profesionales apasionados por la tecnología, dedicados a ofrecer soluciones IT que realmente funcionan para tu negocio.
            </p>
          </div>
        </div>
      </section>

      {/* Stats */}
      <section className="py-12 bg-white dark:bg-gray-950 border-b border-gray-200 dark:border-gray-800">
        <div className="section-container">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            {stats.map((stat) => (
              <div key={stat.label} className="text-center">
                <p className="text-3xl md:text-4xl font-bold text-primary-600 dark:text-primary-400">{stat.value}</p>
                <p className="text-sm md:text-base text-gray-600 dark:text-gray-400 mt-1">{stat.label}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Historia + Timeline */}
      <section className="py-20 md:py-32 bg-white dark:bg-gray-950">
        <div className="section-container">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
            <div>
              <h2 className="section-title mb-6">Nuestra historia</h2>
              <p className="text-lg text-gray-600 dark:text-gray-400 leading-relaxed mb-6">
                Destek Soporte nació en 2008 con una misión clara: democratizar el acceso a servicios tecnológicos de calidad. Lo que empezó como un pequeño taller en Madrid se ha convertido en una referencia del sector IT en España.
              </p>
              <p className="text-lg text-gray-600 dark:text-gray-400 leading-relaxed">
                Hoy atendemos a más de 500 clientes entre empresas y particulares, con un equipo certificado y un 98% de satisfacción.
              </p>
            </div>
            <div className="space-y-0">
              {timeline.map((item, index) => (
                <div key={item.year} className="relative pl-8 pb-8 last:pb-0">
                  {index < timeline.length - 1 && (
                    <div className="absolute left-[11px] top-8 bottom-0 w-0.5 bg-primary-200 dark:bg-primary-800" />
                  )}
                  <div className="absolute left-0 top-1 w-6 h-6 rounded-full bg-primary-600 flex items-center justify-center">
                    <div className="w-2 h-2 rounded-full bg-white" />
                  </div>
                  <div>
                    <span className="text-sm font-bold text-primary-600 dark:text-primary-400">{item.year}</span>
                    <h3 className="text-lg font-semibold text-gray-900 dark:text-white mt-1">{item.title}</h3>
                    <p className="text-gray-600 dark:text-gray-400 mt-1">{item.description}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Valores */}
      <section className="py-20 md:py-32 bg-gray-50 dark:bg-gray-900">
        <div className="section-container">
          <div className="text-center mb-16">
            <h2 className="section-title">Nuestros valores</h2>
            <p className="section-subtitle mx-auto">
              Principios que guían cada decisión y cada servicio que ofrecemos.
            </p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {values.map((value) => (
              <div key={value.title} className="card-base p-8 text-center">
                <div className="w-14 h-14 rounded-2xl bg-primary-100 dark:bg-primary-900/30 flex items-center justify-center mx-auto mb-5">
                  <value.icon className="w-7 h-7 text-primary-600 dark:text-primary-400" aria-hidden="true" />
                </div>
                <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-3">{value.title}</h3>
                <p className="text-gray-600 dark:text-gray-400 leading-relaxed">{value.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Equipo */}
      <section className="py-20 md:py-32 bg-white dark:bg-gray-950">
        <div className="section-container">
          <div className="text-center mb-16">
            <h2 className="section-title">Nuestro equipo</h2>
            <p className="section-subtitle mx-auto">
              Profesionales certificados y apasionados por la tecnología.
            </p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {team.map((member) => (
              <div key={member.name} className="card-base p-6 text-center">
                <div className="text-5xl mb-4">{member.avatar}</div>
                <h3 className="text-lg font-bold text-gray-900 dark:text-white">{member.name}</h3>
                <p className="text-sm font-medium text-primary-600 dark:text-primary-400 mb-3">{member.role}</p>
                <p className="text-sm text-gray-600 dark:text-gray-400 leading-relaxed">{member.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Certificaciones */}
      <section className="py-20 md:py-32 bg-gray-50 dark:bg-gray-900">
        <div className="section-container">
          <div className="text-center mb-16">
            <h2 className="section-title">Certificaciones y partners</h2>
            <p className="section-subtitle mx-auto">
              Trabajamos con las mejores marcas del sector tecnológico.
            </p>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
            {[
              { name: 'Microsoft Partner', icon: '🏢', desc: 'Soluciones Microsoft 365 y Azure' },
              { name: 'Google Cloud', icon: '☁️', desc: 'Google Workspace y GCP' },
              { name: 'Cisco Certified', icon: '🌐', desc: 'Redes Cisco certificadas' },
              { name: 'ISO 27001', icon: '🔒', desc: 'Seguridad de la información' },
            ].map((cert) => (
              <div key={cert.name} className="card-base p-6 text-center">
                <div className="text-4xl mb-3">{cert.icon}</div>
                <h3 className="font-semibold text-gray-900 dark:text-white mb-2">{cert.name}</h3>
                <p className="text-sm text-gray-600 dark:text-gray-400">{cert.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-20 md:py-32 relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-r from-primary-600 via-primary-700 to-primary-800" />
        <div className="section-container relative">
          <div className="mx-auto max-w-3xl text-center">
            <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold text-white mb-6">
              ¿Quieres conocernos mejor?
            </h2>
            <p className="text-lg text-primary-100 mb-8">
              Contacta con nosotros. Primera consulta gratuita y sin compromiso.
            </p>
            <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
              <Link href={ROUTES.contacto}>
                <Button size="lg" variant="secondary" className="group bg-white text-primary-600 hover:bg-gray-100 w-full sm:w-auto">
                  Contactar ahora
                  <ArrowRight className="w-5 h-5 transition-transform group-hover:translate-x-1" aria-hidden="true" />
                </Button>
              </Link>
              <Link href={ROUTES.servicios}>
                <Button size="lg" variant="ghost" className="w-full sm:w-auto text-white border border-white/30 hover:bg-white/10 group">
                  Ver servicios
                  <ArrowRight className="w-5 h-5 transition-transform group-hover:translate-x-1" aria-hidden="true" />
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </section>
    </div>
  )
}

