'use client'

import { useState, useEffect } from 'react'
import Link from 'next/link'
import { ArrowRight, Monitor, Shield, Wifi, Database, Cpu, Headphones, Check, ChevronRight } from 'lucide-react'
import { Button } from '@/components/ui'
import { ROUTES } from '@/lib/constants'
import { createClient } from '@/lib/supabase/client'

const defaultServices = [
  {
    name: 'Reparación PC',
    description: 'Diagnóstico y reparación de hardware y software para equipos de sobremesa y portátiles.',
    icon: Cpu,
    href: `${ROUTES.servicios}#reparacion-pc`,
    features: ['Cambio de componentes', 'Limpieza y mantenimiento', 'Optimización de rendimiento', 'Recuperación de datos'],
  },
  {
    name: 'Mantenimiento',
    description: 'Planes de mantenimiento preventivo y correctivo para mantener tus equipos siempre operativos.',
    icon: Monitor,
    href: `${ROUTES.servicios}#mantenimiento`,
    features: ['Limpieza interna', 'Actualizaciones de software', 'Monitoreo remoto', 'Soporte prioritario'],
  },
  {
    name: 'Redes y WiFi',
    description: 'Instalación, configuración y optimización de redes cableadas e inalámbricas para empresas y hogares.',
    icon: Wifi,
    href: `${ROUTES.servicios}#redes-wifi`,
    features: ['Cableado estructurado', 'Configuración WiFi Mesh', 'Seguridad de red', 'Optimización de señal'],
  },
  {
    name: 'Seguridad',
    description: 'Protege tu información con soluciones de ciberseguridad, antivirus, firewalls y copias de seguridad.',
    icon: Shield,
    href: `${ROUTES.servicios}#seguridad`,
    features: ['Antivirus empresarial', 'Firewall y VPN', 'Copias de seguridad', 'Auditorías de seguridad'],
  },
  {
    name: 'Recuperación Datos',
    description: 'Recuperación profesional de datos de discos duros, SSDs, USB y tarjetas de memoria.',
    icon: Database,
    href: `${ROUTES.servicios}#recuperacion-datos`,
    features: ['Discos duros mecánicos', 'SSD y NVMe', 'Dispositivos móviles', 'Tarjetas de memoria'],
  },
  {
    name: 'Asesoría IT',
    description: 'Consultoría tecnológica para optimizar tu infraestructura, reducir costes y mejorar la productividad.',
    icon: Headphones,
    href: `${ROUTES.servicios}#asesoria-it`,
    features: ['Auditoría tecnológica', 'Planificación estratégica', 'Migración a la nube', 'Formación de equipos'],
  },
]

const defaultStats = [
  { value: '500+', label: 'Clientes satisfechos' },
  { value: '15+', label: 'Años de experiencia' },
  { value: '98%', label: 'Tasa de resolución' },
  { value: '24/7', label: 'Soporte disponible' },
]

const trustBadges = [
  { name: 'Microsoft Partner', icon: '🏢' },
  { name: 'ISO 27001 Certified', icon: '🔒' },
  { name: 'Google Cloud Partner', icon: '☁️' },
  { name: 'Cisco Certified', icon: '🌐' },
]

export default function HomePage() {
  const [stats, setStats] = useState(defaultStats)
  const [services, setServices] = useState(defaultServices)
  const supabase = createClient()

  useEffect(() => {
    async function loadData() {
      try {
        // Load stats from configuracion
        const { data: configData, error: configError } = await supabase
          .from('configuracion')
          .select('clave, valor')
          .like('clave', 'public_stat_%')

        if (configError) throw configError

        if (configData && configData.length > 0) {
          const map: Record<string, string> = {}
          configData.forEach(item => {
            let val = item.valor
            if (typeof val === 'string') {
              try {
                val = JSON.parse(val)
              } catch {
                // leave as string
              }
            }
            map[item.clave] = String(val)
          })

          setStats([
            {
              value: map['public_stat_clientes_value'] || '500+',
              label: map['public_stat_clientes_label'] || 'Clientes satisfechos'
            },
            {
              value: map['public_stat_experiencia_value'] || '15+',
              label: map['public_stat_experiencia_label'] || 'Años de experiencia'
            },
            {
              value: map['public_stat_resolucion_value'] || '98%',
              label: map['public_stat_resolucion_label'] || 'Tasa de resolución'
            },
            {
              value: map['public_stat_soporte_value'] || '24/7',
              label: map['public_stat_soporte_label'] || 'Soporte disponible'
            }
          ])
        }
      } catch (err) {
        console.error('Error loading stats from DB:', err)
      }

      try {
        // Load services from servicios table
        const { data: dbServices, error: servicesError } = await supabase
          .from('servicios')
          .select('*')
          .eq('activo', true)
          .order('orden', { ascending: true })

        if (servicesError) throw servicesError

        if (dbServices && dbServices.length > 0) {
          const mapped = dbServices.map((s: any) => {
            // Try to match with defaultServices to get the rich features/benefits and icon
            const matched = defaultServices.find(ds =>
              ds.name.toLowerCase() === s.titulo.toLowerCase() ||
              s.titulo.toLowerCase().includes(ds.name.toLowerCase())
            )
            return {
              name: s.titulo,
              description: s.descripcion || '',
              icon: matched?.icon || Cpu,
              href: matched?.href || `${ROUTES.servicios}#${s.id}`,
              features: matched?.features || []
            }
          })
          setServices(mapped)
        }
      } catch (err) {
        console.error('Error loading services from DB:', err)
      }
    }

    loadData()
  }, [])

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="relative overflow-hidden bg-gradient-to-b from-primary-50 to-white dark:from-gray-900 dark:to-gray-950 py-20 md:py-32">
        <div className="section-container">
          <div className="mx-auto max-w-4xl text-center">
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-primary-100 dark:bg-primary-900/30 text-primary-700 dark:text-primary-300 text-sm font-medium mb-6 animate-fade-in">
              <span className="relative flex h-2 w-2">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-primary-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2 w-2 bg-primary-500"></span>
              </span>
              Disponibilidad inmediata - Soporte 24/7
            </div>
            <h1 className="section-title text-4xl md:text-5xl lg:text-6xl mb-6 animate-fade-in" style={{ animationDelay: '100ms' }}>
              Soluciones tecnológicas
              <br />
              <span className="text-gradient">que impulsan tu negocio</span>
            </h1>
            <p className="section-subtitle text-xl md:text-2xl mb-10 animate-fade-in" style={{ animationDelay: '200ms' }}>
              Tu partner tecnológico de confianza. Ofrecemos servicios IT integrales, soporte especializado y desarrollo a medida para empresas y particulares.
            </p>
            <div className="flex flex-col sm:flex-row items-center justify-center gap-4 animate-fade-in" style={{ animationDelay: '300ms' }}>
              <Link href={ROUTES.contacto}>
                <Button size="lg" className="group w-full sm:w-auto">
                  Solicitar presupuesto
                  <ArrowRight className="w-5 h-5 transition-transform group-hover:translate-x-1" aria-hidden="true" />
                </Button>
              </Link>
              <Link href={ROUTES.servicios}>
                <Button variant="outline" size="lg" className="w-full sm:w-auto">
                  Ver todos los servicios
                </Button>
              </Link>
            </div>
          </div>

          {/* Stats */}
          <div className="mt-20 grid grid-cols-2 md:grid-cols-4 gap-8 animate-fade-in" style={{ animationDelay: '400ms' }}>
            {stats.map((stat, index) => (
              <div key={stat.label} className="text-center p-6 bg-white/50 dark:bg-gray-900/50 rounded-2xl border border-gray-200 dark:border-gray-800">
                <div className="text-3xl md:text-4xl font-bold text-primary-600 dark:text-primary-400 mb-2">{stat.value}</div>
                <div className="text-gray-600 dark:text-gray-400">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>

        {/* Decorative elements */}
        <div className="absolute top-0 left-0 right-0 bottom-0 overflow-hidden pointer-events-none">
          <div className="absolute -top-40 -right-40 w-80 h-80 rounded-full bg-primary-100/50 dark:bg-primary-900/20 blur-3xl" />
          <div className="absolute -bottom-40 -left-40 w-80 h-80 rounded-full bg-accent-100/50 dark:bg-accent-900/20 blur-3xl" />
        </div>
      </section>

      {/* Trust Badges */}
      <section className="py-12 border-y border-gray-200 dark:border-gray-800">
        <div className="section-container">
          <div className="flex flex-wrap items-center justify-center gap-8 md:gap-16 text-gray-500 dark:text-gray-400">
            {trustBadges.map((badge) => (
              <div key={badge.name} className="flex items-center gap-2 text-sm font-medium">
                <span className="text-2xl">{badge.icon}</span>
                <span>{badge.name}</span>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section id="servicios" className="py-20 md:py-32 bg-white dark:bg-gray-950">
        <div className="section-container">
          <div className="text-center mb-16">
            <h2 className="section-title">Nuestros Servicios</h2>
            <p className="section-subtitle mx-auto">
              Soluciones completas adaptadas a tus necesidades. Desde reparaciones puntuales hasta gestión integral de tu infraestructura IT.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {services.map((service, index) => (
              <article
                key={service.name}
                className="group card-base p-6 md:p-8 hover:shadow-xl hover:border-primary-200 dark:hover:border-primary-800 transition-all duration-300 animate-scale-in"
                style={{ animationDelay: `${index * 100}ms` }}
              >
                <div className="w-14 h-14 rounded-2xl bg-primary-100 dark:bg-primary-900/30 flex items-center justify-center mb-6 group-hover:scale-110 transition-transform duration-300">
                  <service.icon className="w-7 h-7 text-primary-600 dark:text-primary-400" aria-hidden="true" />
                </div>
                <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-3">{service.name}</h3>
                <p className="text-gray-600 dark:text-gray-400 mb-6 leading-relaxed">{service.description}</p>
                <ul className="space-y-2 mb-6">
                  {service.features.map((feature) => (
                    <li key={feature} className="flex items-center gap-2 text-sm text-gray-600 dark:text-gray-400">
                      <Check className="w-4 h-4 text-accent-600 dark:text-accent-400 flex-shrink-0" aria-hidden="true" />
                      {feature}
                    </li>
                  ))}
                </ul>
                <Link href={service.href} className="inline-flex items-center gap-2 text-primary-600 dark:text-primary-400 font-medium hover:text-primary-700 dark:hover:text-primary-300 transition-colors group">
                  Más detalles
                  <ChevronRight className="w-4 h-4 transition-transform group-hover:translate-x-1" aria-hidden="true" />
                </Link>
              </article>
            ))}
          </div>

          <div className="mt-12 text-center">
            <Link href={ROUTES.servicios}>
              <Button variant="outline" size="lg">
                Ver todos los servicios
                <ArrowRight className="w-5 h-5" aria-hidden="true" />
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 md:py-32 relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-r from-primary-600 via-primary-700 to-primary-800" />
        <div className="absolute inset-0 bg-[url('/images/pattern.png')] opacity-10" />
        <div className="section-container relative">
          <div className="mx-auto max-w-3xl text-center">
            <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold text-white mb-6">
              ¿Necesitas ayuda con tu tecnología?
            </h2>
            <p className="text-lg text-primary-100 mb-8">
              Nuestro equipo de expertos está listo para resolver tus problemas IT. Contacta con nosotros y te responderemos en menos de 2 horas.
            </p>
            <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
              <Link href={ROUTES.contacto}>
                <Button size="lg" variant="secondary" className="group w-full sm:w-auto bg-white text-primary-600 hover:bg-gray-100">
                  Contactar ahora
                  <ArrowRight className="w-5 h-5 transition-transform group-hover:translate-x-1" aria-hidden="true" />
                </Button>
              </Link>
              <Link href={ROUTES.whatsapp}>
                <Button size="lg" variant="ghost" className="w-full sm:w-auto text-white border-white hover:bg-white/10 group">
                  WhatsApp directo
                  <ArrowRight className="w-5 h-5 transition-transform group-hover:translate-x-1" aria-hidden="true" />
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Why Choose Us */}
      <section className="py-20 md:py-32 bg-gray-50 dark:bg-gray-900">
        <div className="section-container">
          <div className="text-center mb-16">
            <h2 className="section-title">Por qué elegir Destek Soporte</h2>
            <p className="section-subtitle mx-auto">
              Más de 15 años resolviendo problemas tecnológicos para empresas y particulares en toda España.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[
              {
                icon: '⚡',
                title: 'Respuesta rápida',
                description: 'Tiempo de respuesta medio inferior a 2 horas. Priorizamos la urgencia de tu negocio.',
              },
              {
                icon: '🛡️',
                title: 'Garantía total',
                description: 'Todos nuestros servicios incluyen garantía. Si no quedas satisfecho, volvemos sin coste.',
              },
              {
                icon: '💡',
                title: 'Transparencia',
                description: 'Presupuestos claros sin sorpresas. Te explicamos el problema y la solución en lenguaje llano.',
              },
            ].map((item, index) => (
              <div key={item.title} className="card-base p-8 text-center animate-scale-in" style={{ animationDelay: `${index * 100}ms` }}>
                <div className="text-4xl mb-4">{item.icon}</div>
                <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-3">{item.title}</h3>
                <p className="text-gray-600 dark:text-gray-400">{item.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Final CTA */}
      <section className="py-20 md:py-32">
        <div className="section-container">
          <div className="mx-auto max-w-3xl text-center card-base p-8 md:p-12">
            <h2 className="section-title mb-4">¿Listo para empezar?</h2>
            <p className="section-subtitle mx-auto mb-8">
              Únete a más de 500 clientes que confían en nosotros para su tecnología. Primera consulta gratuita.
            </p>
            <Link href={ROUTES.contacto}>
              <Button size="xl" className="group">
                Solicitar consulta gratuita
                <ArrowRight className="w-6 h-6 transition-transform group-hover:translate-x-1" aria-hidden="true" />
              </Button>
            </Link>
          </div>
        </div>
      </section>
    </div>
  )
}