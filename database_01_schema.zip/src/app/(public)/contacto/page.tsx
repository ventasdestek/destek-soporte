'use client'

import { useState } from 'react'
import Link from 'next/link'
import { Mail, Phone, MapPin, Clock, Send, MessageCircle, ArrowRight } from 'lucide-react'
import { Button } from '@/components/ui'
import { ROUTES, COMPANY_CONFIG } from '@/lib/constants'
import toast from 'react-hot-toast'

const tiposConsulta = [
  { value: 'reparacion', label: 'Reparación PC / Portátil' },
  { value: 'mantenimiento', label: 'Mantenimiento IT' },
  { value: 'redes', label: 'Redes y WiFi' },
  { value: 'seguridad', label: 'Ciberseguridad' },
  { value: 'recuperacion', label: 'Recuperación de Datos' },
  { value: 'asesoria', label: 'Asesoría / Consultoría IT' },
  { value: 'otro', label: 'Otro / Consulta general' },
]

const contactInfo = [
  {
    icon: Phone,
    title: 'Teléfono',
    value: COMPANY_CONFIG.phone,
    href: `tel:${COMPANY_CONFIG.phone.replace(/\s/g, '')}`,
    description: 'Lun-Vie 9:00-19:00',
  },
  {
    icon: Mail,
    title: 'Email',
    value: COMPANY_CONFIG.email,
    href: `mailto:${COMPANY_CONFIG.email}`,
    description: 'Respondemos en < 2h',
  },
  {
    icon: MapPin,
    title: 'Dirección',
    value: COMPANY_CONFIG.address,
    href: '#',
    description: 'Con cita previa',
  },
  {
    icon: Clock,
    title: 'Horario',
    value: 'Lun-Vie: 9:00 - 19:00',
    href: '#',
    description: 'Urgencias 24/7',
  },
]

export default function ContactoPage() {
  const [formData, setFormData] = useState({
    nombre: '',
    email: '',
    telefono: '',
    empresa: '',
    tipoConsulta: '',
    mensaje: '',
    aceptaPrivacidad: false,
  })
  const [loading, setLoading] = useState(false)
  const [enviado, setEnviado] = useState(false)

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target
    setFormData((prev) => ({ ...prev, [name]: value }))
  }

  const handleCheckbox = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFormData((prev) => ({ ...prev, aceptaPrivacidad: e.target.checked }))
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!formData.nombre || !formData.email || !formData.mensaje) {
      toast.error('Por favor, completa los campos obligatorios')
      return
    }
    if (!formData.aceptaPrivacidad) {
      toast.error('Debes aceptar la política de privacidad')
      return
    }
    setLoading(true)
    try {
      // Simular envío (se integrará con Supabase en fase posterior)
      await new Promise((resolve) => setTimeout(resolve, 1500))
      setEnviado(true)
      toast.success('¡Mensaje enviado correctamente! Te responderemos pronto.')
      setFormData({ nombre: '', email: '', telefono: '', empresa: '', tipoConsulta: '', mensaje: '', aceptaPrivacidad: false })
    } catch {
      toast.error('Error al enviar el mensaje. Inténtalo de nuevo.')
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="min-h-screen">
      {/* Hero */}
      <section className="relative overflow-hidden bg-gradient-to-b from-primary-50 to-white dark:from-gray-900 dark:to-gray-950 py-20 md:py-28">
        <div className="section-container">
          <div className="mx-auto max-w-4xl text-center">
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-primary-100 dark:bg-primary-900/30 text-primary-700 dark:text-primary-300 text-sm font-medium mb-6">
              <Mail className="w-4 h-4" aria-hidden="true" />
              Contacto
            </div>
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-gray-900 dark:text-white tracking-tight mb-6">
              ¿Cómo podemos{' '}
              <span className="text-gradient">ayudarte</span>?
            </h1>
            <p className="text-lg md:text-xl text-gray-600 dark:text-gray-400 max-w-2xl mx-auto leading-relaxed">
              Cuéntanos tu necesidad y te responderemos en menos de 2 horas. Presupuesto gratuito y sin compromiso.
            </p>
          </div>
        </div>
      </section>

      {/* Info de contacto */}
      <section className="py-12 bg-white dark:bg-gray-950 border-b border-gray-200 dark:border-gray-800">
        <div className="section-container">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {contactInfo.map((info) => (
              <a
                key={info.title}
                href={info.href}
                className="card-base p-6 flex items-start gap-4 hover:shadow-lg transition-shadow"
              >
                <div className="w-12 h-12 rounded-xl bg-primary-100 dark:bg-primary-900/30 flex items-center justify-center flex-shrink-0">
                  <info.icon className="w-6 h-6 text-primary-600 dark:text-primary-400" aria-hidden="true" />
                </div>
                <div>
                  <h3 className="font-semibold text-gray-900 dark:text-white">{info.title}</h3>
                  <p className="text-sm text-gray-700 dark:text-gray-300 mt-1">{info.value}</p>
                  <p className="text-xs text-gray-500 dark:text-gray-500 mt-1">{info.description}</p>
                </div>
              </a>
            ))}
          </div>
        </div>
      </section>


      {/* Formulario + WhatsApp */}
      <section className="py-20 md:py-32 bg-gray-50 dark:bg-gray-900">
        <div className="section-container">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
            <div className="lg:col-span-2 card-base p-8 md:p-12">
              <h2 className="text-2xl md:text-3xl font-bold text-gray-900 dark:text-white mb-2">
                Envíanos un mensaje
              </h2>
              <p className="text-gray-600 dark:text-gray-400 mb-8">
                Rellena el formulario y nos pondremos en contacto contigo lo antes posible.
              </p>

              {enviado ? (
                <div className="p-8 rounded-2xl bg-green-50 dark:bg-green-950/30 text-center">
                  <h3 className="text-2xl font-bold mb-2">¡Mensaje Recibido!</h3>
                  <p className="text-gray-600 dark:text-gray-400 mb-6">Te responderemos en breve (&lt; 2h).</p>
                  <Button onClick={() => setEnviado(false)} variant="outline">Enviar otro mensaje</Button>
                </div>
              ) : (
                <form onSubmit={handleSubmit} className="space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                      <label className="block text-sm font-medium mb-2">Nombre *</label>
                      <input type="text" name="nombre" value={formData.nombre} onChange={handleChange} required placeholder="Tu nombre" className="input-base" />
                    </div>
                    <div>
                      <label className="block text-sm font-medium mb-2">Email *</label>
                      <input type="email" name="email" value={formData.email} onChange={handleChange} required placeholder="tu@email.com" className="input-base" />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                      <label className="block text-sm font-medium mb-2">Teléfono</label>
                      <input type="tel" name="telefono" value={formData.telefono} onChange={handleChange} placeholder="+34 600 000 000" className="input-base" />
                    </div>
                    <div>
                      <label className="block text-sm font-medium mb-2">Empresa</label>
                      <input type="text" name="empresa" value={formData.empresa} onChange={handleChange} placeholder="Nombre empresa" className="input-base" />
                    </div>
                  </div>

                  <div>
                    <label className="block text-sm font-medium mb-2">Tipo de consulta</label>
                    <select name="tipoConsulta" value={formData.tipoConsulta} onChange={handleChange} className="input-base">
                      <option value="">Selecciona un servicio</option>
                      {tiposConsulta.map((tipo) => (
                        <option key={tipo.value} value={tipo.value}>{tipo.label}</option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="block text-sm font-medium mb-2">Mensaje *</label>
                    <textarea name="mensaje" value={formData.mensaje} onChange={handleChange} required rows={5} placeholder="Describe tu consulta..." className="input-base" />
                  </div>

                  <div className="flex items-start gap-3">
                    <input type="checkbox" id="aceptaPrivacidad" name="aceptaPrivacidad" checked={formData.aceptaPrivacidad} onChange={handleCheckbox} className="mt-1 h-4 w-4 rounded" />
                    <label htmlFor="aceptaPrivacidad" className="text-sm text-gray-600 dark:text-gray-400">
                      Acepto la <Link href={ROUTES.privacidad} className="text-primary-600 underline">política de privacidad</Link>
                    </label>
                  </div>

                  <Button type="submit" size="lg" loading={loading} className="w-full sm:w-auto">
                    <Send className="w-5 h-5 mr-2" /> Enviar mensaje
                  </Button>
                </form>
              )}
            </div>

            {/* Sidebar WhatsApp */}
            <div className="space-y-6">
              <div className="card-base p-8 bg-gradient-to-br from-green-500 to-emerald-700 text-white">
                <div className="w-14 h-14 rounded-2xl bg-white/20 flex items-center justify-center mb-6">
                  <MessageCircle className="w-8 h-8 text-white" />
                </div>
                <h3 className="text-2xl font-bold mb-3">¿Prefieres WhatsApp?</h3>
                <p className="text-green-100 mb-6">Respuesta inmediata para urgencias y consultas rápidas.</p>
                <a href={ROUTES.whatsapp} target="_blank" rel="noopener noreferrer" className="inline-flex items-center justify-center gap-2 w-full px-6 py-3 rounded-xl bg-white text-green-700 font-bold hover:bg-green-50 transition-colors shadow-lg">
                  Abrir WhatsApp Chat <ArrowRight className="w-5 h-5" />
                </a>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  )
}

