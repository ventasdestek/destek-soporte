'use client'

import { useState } from 'react'
import Link from 'next/link'
import { useRouter } from 'next/navigation'
import { UserPlus, Mail, Lock, User, Phone, ArrowRight } from 'lucide-react'
import { Button } from '@/components/ui'
import { createClient } from '@/lib/supabase/client'
import { ROUTES } from '@/lib/constants'
import toast from 'react-hot-toast'

export default function RegistroPage() {
  const router = useRouter()
  const [formData, setFormData] = useState({
    nombre: '', apellido: '', email: '', telefono: '', password: '', confirmPassword: '',
  })
  const [loading, setLoading] = useState(false)
  const supabase = createClient()

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFormData({ ...formData, [e.target.name]: e.target.value })
  }

  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!formData.nombre || !formData.email || !formData.password) {
      toast.error('Completa los campos requeridos')
      return
    }
    if (formData.password !== formData.confirmPassword) {
      toast.error('Las contraseñas no coinciden')
      return
    }

    setLoading(true)
    try {
      const { data, error } = await supabase.auth.signUp({
        email: formData.email,
        password: formData.password,
        options: { data: { nombre: formData.nombre, apellido: formData.apellido, telefono: formData.telefono, role: 'cliente' } },
      })
      if (error) {
        toast.error(error.message)
        return
      }
      if (data.session) {
        toast.success('¡Registro exitoso!')
        router.push(ROUTES.dashboard)
      } else {
        toast.success('¡Registro completado! Revisa tu email.')
        router.push(ROUTES.login)
      }
      router.refresh()
    } catch {
      toast.error('Error al registrar usuario')
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="min-h-screen flex items-center justify-center py-16 px-4 bg-gray-50 dark:bg-gray-950">
      <div className="w-full max-w-lg card-base p-8 md:p-10 shadow-xl border border-gray-200 dark:border-gray-800">
        <div className="text-center mb-8">
          <div className="w-12 h-12 rounded-2xl bg-primary-100 dark:bg-primary-900/30 text-primary-600 dark:text-primary-400 flex items-center justify-center mx-auto mb-4">
            <UserPlus className="w-6 h-6" />
          </div>
          <h1 className="text-2xl md:text-3xl font-bold text-gray-900 dark:text-white">Crear una Cuenta</h1>
          <p className="text-sm text-gray-600 dark:text-gray-400 mt-2">
            Regístrate para solicitar servicios y gestionar tu soporte técnico
          </p>
        </div>

        <form onSubmit={handleRegister} className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium mb-1">Nombre *</label>
              <input type="text" name="nombre" value={formData.nombre} onChange={handleChange} required placeholder="Tu nombre" className="input-base" />
            </div>
            <div>
              <label className="block text-sm font-medium mb-1">Apellidos</label>
              <input type="text" name="apellido" value={formData.apellido} onChange={handleChange} placeholder="Tus apellidos" className="input-base" />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium mb-1">Email *</label>
              <input type="email" name="email" value={formData.email} onChange={handleChange} required placeholder="tu@email.com" className="input-base" />
            </div>
            <div>
              <label className="block text-sm font-medium mb-1">Teléfono</label>
              <input type="tel" name="telefono" value={formData.telefono} onChange={handleChange} placeholder="+34 600 000 000" className="input-base" />
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium mb-1">Contraseña *</label>
            <input type="password" name="password" value={formData.password} onChange={handleChange} required minLength={6} placeholder="••••••••" className="input-base" />
          </div>

          <div>
            <label className="block text-sm font-medium mb-1">Confirmar Contraseña *</label>
            <input type="password" name="confirmPassword" value={formData.confirmPassword} onChange={handleChange} required placeholder="••••••••" className="input-base" />
          </div>

          <Button type="submit" loading={loading} className="w-full justify-center group mt-6" size="lg">
            Crear Cuenta <ArrowRight className="w-5 h-5 ml-2" />
          </Button>
        </form>

        <div className="mt-8 pt-6 border-t border-gray-200 dark:border-gray-800 text-center">
          <p className="text-sm text-gray-600 dark:text-gray-400">
            ¿Ya tienes una cuenta?{' '}
            <Link href={ROUTES.login} className="text-primary-600 dark:text-primary-400 font-semibold hover:underline">
              Inicia sesión aquí
            </Link>
          </p>
        </div>
      </div>
    </div>
  )
}
