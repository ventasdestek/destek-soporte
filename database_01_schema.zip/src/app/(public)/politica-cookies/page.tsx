import { Metadata } from 'next'

export const metadata: Metadata = {
  title: 'Política de Cookies | Destek Soporte',
  description: 'Información sobre la política de cookies utilizada en Destek Soporte.',
}

export default function PoliticaCookiesPage() {
  return (
    <div className="min-h-screen py-20 md:py-32">
      <div className="section-container max-w-4xl">
        <h1 className="text-4xl font-bold mb-8 text-gray-900 dark:text-white">Política de Cookies</h1>
        <div className="prose dark:prose-invert max-w-none space-y-6 text-gray-600 dark:text-gray-400">
          <p>Utilizamos cookies propias y de terceros para mejorar nuestros servicios y mostrarle publicidad relacionada con sus preferencias mediante el análisis de sus hábitos de navegación.</p>
          <h2 className="text-2xl font-semibold text-gray-900 dark:text-white mt-8">¿Qué es una cookie?</h2>
          <p>Una cookie es un fichero que se descarga en su ordenador al acceder a determinadas páginas web.</p>
          <h2 className="text-2xl font-semibold text-gray-900 dark:text-white mt-8">Desactivación de cookies</h2>
          <p>Puede usted permitir, bloquear o eliminar las cookies instaladas en su equipo mediante la configuración de las opciones del navegador instalado en su ordenador.</p>
        </div>
      </div>
    </div>
  )
}
