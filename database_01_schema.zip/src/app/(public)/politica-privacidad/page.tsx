import { Metadata } from 'next'

export const metadata: Metadata = {
  title: 'Política de Privacidad | Destek Soporte',
  description: 'Política de privacidad y protección de datos de Destek Soporte.',
}

export default function PoliticaPrivacidadPage() {
  return (
    <div className="min-h-screen py-20 md:py-32">
      <div className="section-container max-w-4xl">
        <h1 className="text-4xl font-bold mb-8 text-gray-900 dark:text-white">Política de Privacidad</h1>
        <div className="prose dark:prose-invert max-w-none space-y-6 text-gray-600 dark:text-gray-400">
          <p>En Destek Soporte garantizamos la protección de los datos de nuestros clientes y usuarios conforme al Reglamento General de Protección de Datos (RGPD) (UE) 2016/679.</p>
          <h2 className="text-2xl font-semibold text-gray-900 dark:text-white mt-8">1. Responsable del Tratamiento</h2>
          <p>Destek Soporte S.L. - Email: contacto@desteksoporte.com</p>
          <h2 className="text-2xl font-semibold text-gray-900 dark:text-white mt-8">2. Finalidad del Tratamiento</h2>
          <p>Tratamos la información que nos facilitan las personas interesadas con el fin de prestar los servicios solicitados y enviar comunicaciones comerciales relativas a nuestras ofertas y servicios.</p>
          <h2 className="text-2xl font-semibold text-gray-900 dark:text-white mt-8">3. Derechos de los Usuarios</h2>
          <p>Cualquier persona tiene derecho a obtener confirmación sobre si en Destek Soporte estamos tratando datos personales que les conciernan, a acceder a sus datos, solicitar la rectificación o supresión.</p>
        </div>
      </div>
    </div>
  )
}
