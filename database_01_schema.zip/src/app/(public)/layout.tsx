import { Metadata } from 'next'
import { Navbar } from '@/components/layout/Navbar'
import { Footer } from '@/components/layout/Footer'

export const metadata: Metadata = {
  title: 'Destek Soporte | Servicios Tecnológicos, Soporte y Desarrollo',
  description: 'Empresa de servicios tecnológicos: asesoría, soporte remoto, desarrollo de software a medida y venta de hardware.',
}

export default function PublicLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <>
      <Navbar />
      <main id="main-content" className="pt-16 min-h-[calc(100vh-4rem)]">
        {children}
      </main>
      <Footer />
    </>
  )
}