'use client'

import { useState } from 'react'
import Link from 'next/link'
import { KeyRound, Mail, ArrowRight, ArrowLeft } from 'lucide-react'
import { Button } from '@/components/ui'
import { createClient } from '@/lib/supabase/client'
import { ROUTES } from '@/lib/constants'
import toast from 'react-hot-toast'

export default function RecuperarPasswordPage() {
  const [email, setEmail] = useState('')
  const [loading, setLoading] = useState(false)
  const [enviado, setEnviado] = useState(false)
  const supabase = createClient()

  const handleReset = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!email) {
      toast.error('Por favor, ingresa tu email')
      return
    }

    setLoading(true)
    try {
      const { error } = await supabase.auth.resetPasswordForEmail(email, {
        redirectTo: `${window.location.origin}/dashboard/perfil`,
      })

      if (error) {
        toast.error(error.message)
        return
      }

      setEnviado(true)
      toast.success('Te hemos enviado un correo con instrucciones')
    } catch {
      toast.error('Error al solicitar la recuperación')
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="min-h-screen flex items-center justify-center py-16 px-4 bg-gray-50 dark:bg-gray-950">
      <div className="w-full max-w-md card-base p-8 md:p-10 shadow-xl border border-gray-200 dark:border-gray-800">
        <div className="text-center mb-8">
          <div className="w-12 h-12 rounded-2xl bg-primary-100 dark:bg-primary-900/30 text-primary-600 dark:text-primary-400 flex items-center justify-center mx-auto mb-4">
            <KeyRound className="w-6 h-6" />
          </div>
          <h1 className="text-2xl md:text-3xl font-bold text-gray-900 dark:text-white">Recuperar Contraseña</h1>
          <p className="text-sm text-gray-600 dark:text-gray-400 mt-2">
            Ingresa tu correo y te enviaremos un enlace de recuperación
          </p>
        </div>

        {enviado ? (
          <div className="text-center space-y-4">
            <div className="p-4 rounded-xl bg-green-50 dark:bg-green-950/30 text-green-700 dark:text-green-300 text-sm">
              Hemos enviado las instrucciones a <strong>{email}</strong>. Revisa tu bandeja de entrada o spam.
            </div>
            <Link href={ROUTES.login} className="inline-flex items-center text-sm font-semibold text-primary-600 dark:text-primary-400 hover:underline">
              <ArrowLeft className="w-4 h-4 mr-1" /> Volver al inicio de sesión
            </Link>
          </div>
        ) : (
          <form onSubmit={handleReset} className="space-y-5">
            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1.5">
                Correo electrónico
              </label>
              <div className="relative">
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  required
                  placeholder="tu@email.com"
                  className="input-base pl-11"
                />
                <Mail className="w-5 h-5 text-gray-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
              </div>
            </div>

            <Button type="submit" loading={loading} className="w-full justify-center group" size="lg">
              Enviar Enlace <ArrowRight className="w-5 h-5 ml-2 transition-transform group-hover:translate-x-1" />
            </Button>
          </form>
        )}

        <div className="mt-8 pt-6 border-t border-gray-200 dark:border-gray-800 text-center">
          <Link href={ROUTES.login} className="text-sm text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-white inline-flex items-center">
            <ArrowLeft className="w-4 h-4 mr-1" /> Volver a Iniciar Sesión
          </Link>
        </div>
      </div>
    </div>
  )
}
