'use client'

import { useState, useEffect } from 'react'
import Link from 'next/link'
import { Package, Search, ArrowRight, Loader2 } from 'lucide-react'
import { Button, Badge } from '@/components/ui'
import { formatPrice } from '@/utils/format'
import { createClient } from '@/lib/supabase/client'

interface Producto {
  id: string
  nombre: string
  categoria: string
  descripcion: string
  precio: number
  stock: number
}

export default function ProductosPage() {
  const [productos, setProductos] = useState<Producto[]>([])
  const [categorias, setCategorias] = useState<string[]>(['todas'])
  const [categoria, setCategoria] = useState('todas')
  const [busqueda, setBusqueda] = useState('')
  const [loading, setLoading] = useState(true)
  const supabase = createClient()

  useEffect(() => {
    async function loadData() {
      setLoading(true)
      try {
        // Fetch active categories
        const { data: catData, error: catError } = await supabase
          .from('categorias')
          .select('nombre')
          .eq('activo', true)
          .order('orden', { ascending: true })

        if (catError) throw catError
        if (catData) {
          setCategorias(['todas', ...catData.map((c: any) => c.nombre)])
        }

        // Fetch products with their category
        const { data: prodData, error: prodError } = await supabase
          .from('productos')
          .select('*, categorias(nombre)')
          .eq('activo', true)
          .order('orden', { ascending: true })

        if (prodError) throw prodError
        if (prodData) {
          const mapped: Producto[] = prodData.map((p: any) => ({
            id: p.id,
            nombre: p.nombre,
            categoria: p.categorias?.nombre || 'General',
            descripcion: p.descripcion || '',
            precio: Number(p.precio) || 0,
            stock: p.stock || 0
          }))
          setProductos(mapped)
        }
      } catch (err) {
        console.error('Error loading products from DB:', err)
      } finally {
        setLoading(false)
      }
    }
    loadData()
  }, [])

  const filtrados = productos.filter((prod) => {
    const coincideCat = categoria === 'todas' || prod.categoria === categoria
    const coincideBusq = prod.nombre.toLowerCase().includes(busqueda.toLowerCase())
    return coincideCat && coincideBusq
  })

  return (
    <div className="py-12 bg-gray-50 dark:bg-gray-950 min-h-screen">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto mb-12">
          <Badge variant="info" className="mb-4">Catálogo Tecnológico</Badge>
          <h1 className="text-3xl md:text-4xl font-bold text-gray-900 dark:text-white">
            Productos y Hardware Especializado
          </h1>
          <p className="text-base text-gray-600 dark:text-gray-400 mt-3">
            Sistemas, kits de seguridad CCTV y equipamiento de red con garantía y soporte directo.
          </p>
        </div>

        <div className="card-base p-6 mb-8 flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="relative w-full md:w-96">
            <input
              type="text"
              placeholder="Buscar producto..."
              value={busqueda}
              onChange={(e) => setBusqueda(e.target.value)}
              className="input-base pl-10"
            />
            <Search className="w-5 h-5 text-gray-400 absolute left-3 top-1/2 -translate-y-1/2" />
          </div>

          <div className="flex gap-2 w-full md:w-auto overflow-x-auto pb-2 md:pb-0">
            {categorias.map((cat) => (
              <button
                key={cat}
                onClick={() => setCategoria(cat)}
                className={`px-4 py-2 rounded-xl text-xs font-semibold whitespace-nowrap transition-colors ${
                  categoria === cat ? 'bg-primary-600 text-white' : 'bg-gray-100 dark:bg-gray-800 text-gray-600 dark:text-gray-400'
                }`}
              >
                {cat === 'todas' ? 'Todas las Categorías' : cat}
              </button>
            ))}
          </div>
        </div>

        {loading ? (
          <div className="p-12 flex flex-col items-center justify-center text-gray-500 card-base">
            <Loader2 className="w-8 h-8 animate-spin text-primary-600 mb-2" />
            <p className="text-sm">Cargando productos del catálogo...</p>
          </div>
        ) : filtrados.length === 0 ? (
          <div className="p-12 text-center text-gray-500 card-base col-span-full">
            <Package className="w-12 h-12 mx-auto mb-2 opacity-35" />
            <p className="text-sm">No se encontraron productos en esta categoría.</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {filtrados.map((prod) => (
              <div key={prod.id} className="card-base p-6 flex flex-col justify-between hover:shadow-xl transition-all border border-gray-200 dark:border-gray-800">
                <div>
                  <div className="w-full h-40 rounded-2xl bg-primary-50 dark:bg-primary-950/40 flex items-center justify-center mb-6">
                    <Package className="w-14 h-14 text-primary-600" />
                  </div>
                  <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-2">{prod.nombre}</h3>
                  <p className="text-sm text-gray-600 dark:text-gray-400 mb-6">{prod.descripcion}</p>
                </div>

                <div>
                  <div className="flex items-center justify-between pt-4 border-t border-gray-200 dark:border-gray-800 mb-4">
                    <span className="text-2xl font-bold text-primary-600">{formatPrice(prod.precio)}</span>
                    <Badge variant={prod.stock > 0 ? 'success' : 'danger'}>Stock: {prod.stock}</Badge>
                  </div>
                  <Link href={`/productos/${prod.id}`}>
                    <Button className="w-full justify-center">Ver Detalles <ArrowRight className="w-4 h-4 ml-2" /></Button>
                  </Link>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  )
}
