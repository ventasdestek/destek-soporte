'use client'

import Link from 'next/link'
import { useParams } from 'next/navigation'
import { Package, ShieldCheck, Truck, ArrowLeft, PhoneCall, CheckCircle } from 'lucide-react'
import { Button, Badge } from '@/components/ui'
import { ROUTES, COMPANY_CONFIG } from '@/lib/constants'
import { formatPrice } from '@/utils/format'

export default function ProductoDetallePage() {
  const params = useParams()
  const id = params?.id

  return (
    <div className="py-16 bg-gray-50 dark:bg-gray-950 min-h-screen">
      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
        <Link href={ROUTES.productos} className="inline-flex items-center text-sm font-semibold text-primary-600 dark:text-primary-400 hover:underline mb-8">
          <ArrowLeft className="w-4 h-4 mr-2" /> Volver al catálogo de productos
        </Link>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-10 card-base p-8 md:p-12">
          {/* Imagen Placeholder */}
          <div className="w-full h-80 rounded-2xl bg-gradient-to-br from-primary-500/10 to-primary-900/20 flex flex-col items-center justify-center border border-gray-200 dark:border-gray-800 p-6 text-center">
            <Package className="w-24 h-24 text-primary-600 dark:text-primary-400 mb-4" />
            <span className="text-xs text-gray-500 font-mono">ID Producto: {id}</span>
          </div>

          {/* Información */}
          <div className="space-y-6">
            <Badge variant="info">Equipamiento Técnico Garantizado</Badge>
            <h1 className="text-2xl md:text-3xl font-bold text-gray-900 dark:text-white">
              Kit 4 Cámaras CCTV IP 4K UltraHD
            </h1>
            <p className="text-3xl font-bold text-primary-600 dark:text-primary-400">{formatPrice(299)}</p>

            <p className="text-sm text-gray-600 dark:text-gray-400 leading-relaxed">
              Kit completo de videovigilancia profesional para empresas y hogares. Incluye NVR de 4 canales con disco duro de 1TB preinstalado, cámaras IP 4K con detección de movimiento por IA y visión nocturna a color.
            </p>

            <ul className="space-y-2 text-sm text-gray-700 dark:text-gray-300">
              <li className="flex items-center gap-2"><CheckCircle className="w-4 h-4 text-green-500" /> Instalación técnica bajo solicitud</li>
              <li className="flex items-center gap-2"><CheckCircle className="w-4 h-4 text-green-500" /> 2 Años de garantía oficial</li>
              <li className="flex items-center gap-2"><CheckCircle className="w-4 h-4 text-green-500" /> Envíos express 24/48h</li>
            </ul>

            <div className="pt-6 border-t border-gray-200 dark:border-gray-800 flex flex-col sm:flex-row gap-4">
              <a href={`${COMPANY_CONFIG.whatsapp}?text=Hola,%20me%20interesa%20comprar%20el%20producto%20ID:%20${id}`} target="_blank" rel="noopener noreferrer" className="w-full">
                <Button className="w-full justify-center" size="lg">
                  <PhoneCall className="w-4 h-4 mr-2" /> Consultar / Solicitar Compra
                </Button>
              </a>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
