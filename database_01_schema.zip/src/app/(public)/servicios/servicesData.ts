import { Monitor, Shield, Wifi, Database, Cpu, Headphones } from 'lucide-react'

export interface ServiceItem {
  id: string
  name: string
  description: string
  longDescription: string
  icon: typeof Cpu
  features: string[]
  benefits: string[]
}

export const services: ServiceItem[] = [
  {
    id: 'reparacion-pc',
    name: 'Reparación PC',
    description: 'Diagnóstico y reparación de hardware y software para equipos de sobremesa y portátiles. Solucionamos cualquier avería con garantía.',
    longDescription: 'Nuestro servicio de reparación de PC cubre todo tipo de incidencias hardware y software. Desde cambios de componentes dañados (fuentes de alimentación, placas base, tarjetas gráficas, discos duros, memoria RAM) hasta resolución de problemas de software (sistema operativo, controladores, virus, malware, lentitud).',
    icon: Cpu,
    features: [
      'Cambio de componentes (fuentes, placas base, GPUs, RAM, discos)',
      'Limpieza y mantenimiento preventivo interno',
      'Optimización de rendimiento y limpieza de inicio',
      'Recuperación de datos de discos dañados',
      'Reinstalación y configuración de Windows/Linux',
      'Eliminación de virus, malware y ransomware',
      'Reparación de portátiles (pantallas, teclados, conectores)',
      'Diagnóstico gratuito si realizas la reparación',
    ],
    benefits: [
      'Garantía de 6 meses en todas las reparaciones',
      'Diagnóstico gratuito si aceptas el presupuesto',
      'Piezas originales o de calidad equivalente',
      'Tiempo medio de reparación: 24-48h',
    ],
  },
  {
    id: 'mantenimiento',
    name: 'Mantenimiento',
    description: 'Planes de mantenimiento preventivo y correctivo para mantener tus equipos siempre operativos y evitar paradas inesperadas.',
    longDescription: 'Ofrecemos planes de mantenimiento adaptados a cada necesidad. Desde mantenimiento puntual hasta contratos mensuales con monitorización remota 24/7, actualizaciones automáticas y soporte prioritario.',
    icon: Monitor,
    features: [
      'Limpieza interna y externa de equipos',
      'Actualizaciones de software y parches de seguridad',
      'Monitoreo remoto 24/7 de servidores y equipos críticos',
      'Soporte prioritario con tiempo de respuesta < 2h',
      'Gestión de inventario IT y ciclo de vida de equipos',
      'Copias de seguridad verificadas y test de restauración',
      'Informes mensuales de estado y recomendaciones',
      'Sustitución proactiva de componentes en fin de vida',
    ],
    benefits: [
      'Reduce un 80% las incidencias imprevistas',
      'Alarga la vida útil de tus equipos 3-5 años',
      'Coste fijo mensual sin sorpresas',
      'Incluye soporte remoto ilimitado',
    ],
  },
  {
    id: 'redes-wifi',
    name: 'Redes y WiFi',
    description: 'Instalación, configuración y optimización de redes cableadas e inalámbricas para empresas y hogares. Cobertura total y máxima velocidad.',
    longDescription: 'Diseñamos e implementamos infraestructuras de red robustas y seguras. Desde cableado estructurado Cat6/Cat6a hasta redes WiFi Mesh empresariales con roaming transparente, VLANs, QoS y gestión centralizada.',
    icon: Wifi,
    features: [
      'Cableado estructurado Cat6, Cat6a, Fibra óptica',
      'Configuración WiFi Mesh empresarial y doméstica',
      'Seguridad de red: Firewall, VLANs, VPN, 802.1X',
      'Optimización de señal y análisis de interferencias',
      'Puntos de acceso PoE y switches gestionables',
      'Configuración de QoS para voz/vídeo prioritario',
      'Auditoría de seguridad wireless y pentesting básico',
      'Certificación de cableado con informes Fluke',
    ],
    benefits: [
      'Cobertura WiFi 100% en todas las estancias',
      'Velocidad cableada real 1Gbps/10Gbps',
      'Red segregada: invitados, IoT, corporativa',
      'Gestión cloud centralizada (UniFi, Omada, Meraki)',
    ],
  },
  {
    id: 'seguridad',
    name: 'Seguridad',
    description: 'Protege tu información con soluciones de ciberseguridad: antivirus empresarial, firewalls, VPN, copias de seguridad y auditorías.',
    longDescription: 'Implementamos una estrategia de defensa en capas para proteger tus activos de información. Desde endpoint protection (EDR/XDR) hasta firewalls next-gen, backup inmutable y formación en concienciación de seguridad.',
    icon: Shield,
    features: [
      'Antivirus/EDR empresarial gestionado centralmente',
      'Firewall next-gen con IPS/IDS, control de aplicaciones',
      'VPN de acceso remoto seguro (WireGuard, OpenVPN)',
      'Copias de seguridad inmutables (3-2-1 rule) y DRP',
      'Auditorías de seguridad y análisis de vulnerabilidades',
      'Formación en concienciación (phishing, ingeniería social)',
      'Gestión de parches y vulnerabilidades (CVE)',
      'Cifrado de discos y comunicaciones (BitLocker, TLS)',
    ],
    benefits: [
      'Cumplimiento RGPD y LOPDGDD',
      'Protección frente a ransomware con backup inmutable',
      'Visibilidad total de amenazas en consola única',
      'Respuesta a incidentes en < 4h',
    ],
  },
  {
    id: 'recuperacion-datos',
    name: 'Recuperación Datos',
    description: 'Recuperación profesional de datos de discos duros, SSDs, USB y tarjetas de memoria. Laboratorio propio con cámara limpia.',
    longDescription: 'Servicio especializado de recuperación de datos con laboratorio propio y cámara limpia ISO 5. Recuperamos información de cualquier medio: HDD mecánicos, SSD SATA/NVMe, memorias USB, tarjetas SD, móviles. Diagnóstico gratuito y presupuesto sin compromiso.',
    icon: Database,
    features: [
      'Discos duros mecánicos (fallos mecánicos, electrónicos, lógicos)',
      'SSD y NVMe (desgaste, controlador, firmware, encriptación)',
      'Dispositivos USB, tarjetas SD, microSD, CFexpress',
      'Móviles y tablets (iOS, Android) - extracción chip-off',
      'Cifrado BitLocker, FileVault, LUKS, VeraCrypt',
      'Borrado accidental, formateo, partición perdida, ransomware',
      'Cámara limpia ISO 5 para apertura de discos sellados',
    ],
    benefits: [
      'Diagnóstico gratuito y presupuesto sin compromiso',
      'Tasa de éxito > 95% en casos lógicos y electrónicos',
      'Confidencialidad total (NDA firmado)',
      'No recovery, no fee (si no recuperamos, no pagas)',
    ],
  },
  {
    id: 'asesoria-it',
    name: 'Asesoría IT',
    description: 'Consultoría tecnológica estratégica para optimizar tu infraestructura, reducir costes y guiar la transformación digital de tu empresa.',
    longDescription: 'Te acompañamos como tu CIO/CTO externo. Analizamos tu infraestructura actual, identificamos ineficiencias, riesgos y oportunidades de mejora, y diseñamos una hoja de ruta tecnológica alineada con tus objetivos de negocio.',
    icon: Headphones,
    features: [
      'Auditoría completa de infraestructura IT y licencias',
      'Diseño de arquitectura cloud (AWS, Azure, Google Cloud)',
      'Planes de transformación digital y modernización',
      'Optimización y reducción de costes en licencias/servicios',
      'Selección e implantación de ERP, CRM, software de gestión',
      'Planes de continuidad de negocio (BCP) y DRP',
      'Asesoría en cumplimiento normativo (RGPD, ENS, ISO 27001)',
      'Gestión de proveedores tecnológicos y contratación',
    ],
    benefits: [
      'Ahorro medio del 25% en costes IT',
      'Alineación total entre tecnología y negocio',
      'Independencia de proveedores (te recomendamos lo mejor)',
      'Acompañamiento continuo en la toma de decisiones',
    ],
  },
]
