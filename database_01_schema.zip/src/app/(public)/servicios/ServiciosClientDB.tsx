'use client'

import { useState, useEffect } from 'react'
import Link from 'next/link'
import { Database, Shield, Clock, Check, AlertCircle } from 'lucide-react'
import { Button, Badge } from '@/components/ui'
import { createClient } from '@/lib/supabase/client'

export interface ServicioDB {
  id: string
  titulo: string
  descripcion: string
  precio: number
  duracion: string | null
  modalidad: 'online' | 'presencial' | 'hibrido'
  imagen_url: string | null
  activo: boolean
  orden: number
}

export interface Servicio {
  id: string
  titulo: string
  descripcion: string | null
  precio: number
  duracion: string | null
  modalidad: 'online' | 'presencial' | 'hibrido'
  imagen_url: string | null
  activo: boolean
  caracteristicas?: string[]
  beneficios?: string[]
}

export function useServicios() {
  const [servicios, setServicios] = useState<Servicio[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    fetchServicios()
  }, [])

  const fetchServicios = async () => {
    try {
      const supabase = createClient()
      const { data, error } = await supabase
        .from('servicios')
        .select('*')
        .order('orden', { ascending: true })

      if (error) throw error

      const formateados: Servicio[] = (data || []).map((s: any) => ({
        id: s.id,
        titulo: s.titulo,
        descripcion: s.descripcion,
        precio: s.precio,
        duracion: s.duracion,
        modalidad: s.modalidad,
        imagen_url: s.imagen_url,
        activo: s.activo,
        caracteristicas: s.caracteristicas || [],
        beneficios: s.beneficios || [],
      }))

      setServicios(formateados)
      setLoading(false)
    } catch (error) {
      console.error('Error fetching servicios:', error)
      setLoading(false)
    }
  }

  return { servicios, loading }
}