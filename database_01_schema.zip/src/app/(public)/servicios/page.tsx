import { Metadata } from 'next'
import ServiciosClient from './ServiciosClient'

export const metadata: Metadata = {
  title: 'Servicios IT | Destek Soporte',
  description: 'Descubre todos nuestros servicios tecnológicos: reparación PC, mantenimiento, redes y WiFi, seguridad, recuperación de datos y asesoría IT.',
}

export default function ServiciosPage() {
  return <ServiciosClient />
}
