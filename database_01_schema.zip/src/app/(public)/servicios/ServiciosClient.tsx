'use client'

import { useState, useEffect } from 'react'
import Link from 'next/link'
import { ArrowRight, Shield, Check, ChevronRight, ArrowLeft, Monitor, Wifi, Database, Cpu, Headphones, Wrench } from 'lucide-react'
import { Button, Badge } from '@/components/ui'
import { ROUTES } from '@/lib/constants'
import { formatPrice } from '@/utils/format'
import { createClient } from '@/lib/supabase/client'

interface ServicioDB {
  id: string
  titulo: string
  descripcion: string
  precio: number
  duracion: string | null
  modalidad: 'online' | 'presencial' | 'hibrido'
  imagen_url: string | null
  activo: boolean
  orden: number
}

interface ServicioUI extends ServicioDB {
  icon: typeof Cpu
  features: string[]
  benefits: string[]
  longDescription: string
}

function getServiceIcon(titulo: string, modalidad: string): typeof Cpu {
  const title = titulo.toLowerCase()
  if (title.includes('reparación') || title.includes('pc') || title.includes('hardware')) return Cpu
  if (title.includes('mantenimiento') || title.includes('monitor')) return Monitor
  if (title.includes('red') || title.includes('wifi')) return Wifi
  if (title.includes('seguridad') || title.includes('auditor') || title.includes('shield')) return Shield
  if (title.includes('datos') || title.includes('recuperación') || title.includes('database')) return Database
  if (title.includes('asesor') || title.includes('consult')) return Headphones
  if (modalidad === 'online') return Monitor
  if (modalidad === 'presencial') return Cpu
  return Wrench
}
function getServiceExtras(titulo: string): { features: string[]; benefits: string[]; longDescription: string } {
  const title = titulo.toLowerCase()
  if (title.includes('reparación') || title.includes('pc')) {
    return { features: ['Cambio de componentes', 'Limpieza y mantenimiento preventivo', 'Optimización de rendimiento', 'Recuperación de datos', 'Reinstalación Windows/Linux', 'Eliminación virus y malware', 'Reparación portátiles', 'Diagnóstico gratuito'], benefits: ['Garantía 6 meses', 'Diagnóstico gratuito', 'Piezas originales', 'Reparación 24-48h'], longDescription: 'Nuestro servicio de reparación de PC cubre todo tipo de incidencias hardware y software. Desde cambios de componentes dañados hasta resolución de problemas de software.' }
  }
  if (title.includes('mantenimiento')) {
    return { features: ['Limpieza equipos', 'Actualizaciones seguridad', 'Monitoreo 24/7', 'Soporte prioritario <2h', 'Gestión inventario IT', 'Backups verificados', 'Informes mensuales', 'Sustitución proactiva'], benefits: ['Reduce 80% incidencias', 'Alarga vida útil 3-5 años', 'Coste fijo mensual', 'Soporte remoto ilimitado'], longDescription: 'Ofrecemos planes de mantenimiento adaptados a cada necesidad. Desde mantenimiento puntual hasta contratos mensuales con monitorización remota 24/7.' }
  }
  if (title.includes('red') || title.includes('wifi')) {
    return { features: ['Cableado Cat6/Cat6a/Fibra', 'WiFi Mesh empresarial', 'Firewall, VLANs, VPN', 'Optimización señal', 'Puntos acceso PoE', 'QoS voz/vídeo'], benefits: ['Cobertura total', 'Velocidad máxima', 'Red segura', 'Gestión centralizada'], longDescription: 'Diseñamos infraestructuras de red robustas y seguras. Cableado estructurado, redes WiFi Mesh, VLANs, QoS y gestión centralizada.' }
  }
  if (title.includes('seguridad') || title.includes('auditor')) {
    return { features: ['Antivirus/EDR centralizado', 'Firewall next-gen IPS/IDS', 'VPN WireGuard/OpenVPN', 'Backups inmutables 3-2-1', 'Auditorías vulnerabilidades', 'Formación phishing', 'Gestión parches CVE', 'Cifrado BitLocker/TLS'], benefits: ['Cumplimiento RGPD', 'Protección ransomware', 'Visibilidad amenazas', 'Respuesta <4h'], longDescription: 'Estrategia defensa en capas: endpoint protection, firewalls next-gen, backup inmutable, formación concienciación.' }
  }
  if (title.includes('recuperación') || title.includes('datos')) {
    return { features: ['HDD mecánicos', 'SSD/NVMe', 'USB, tarjetas SD', 'Móviles iOS/Android', 'Cifrado BitLocker/LUKS', 'Borrado accidental/formateo', 'Cámara limpia ISO 5'], benefits: ['Diagnóstico gratuito', 'Tasa éxito >95%', 'Confidencialidad NDA', 'No recovery no fee'], longDescription: 'Recuperación datos con laboratorio propio y cámara limpia ISO 5. HDD, SSD, USB, SD, móviles. Diagnóstico gratuito.' }
  }
  if (title.includes('asesor') || title.includes('consult')) {
    return { features: ['Auditoría IT y licencias', 'Arquitectura cloud AWS/Azure/GCP', 'Transformación digital', 'Optimización costes', 'ERP/CRM implantación', 'BCP/DRP', 'Cumplimiento RGPD/ISO27001', 'Gestión proveedores'], benefits: ['Ahorro 25% costes IT', 'Alineación tech-negocio', 'Independencia proveedores', 'Acompañamiento continuo'], longDescription: 'CIO/CTO externo. Auditoría infraestructura, hoja ruta tecnológica alineada a objetivos negocio.' }
  }
  return { features: ['Servicio personalizado', 'Equipo certificado', 'Garantía satisfacción'], benefits: ['Solución adaptada', 'Soporte post-servicio'], longDescription: 'Servicio profesional adaptado a tus necesidades. Evaluamos tu caso y proponemos la mejor solución.' }
}
export default function ServiciosClient() {
  const [servicios, setServicios] = useState<ServicioUI[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const supabase = createClient()

  useEffect(() => {
    async function loadServicios() {
      setLoading(true)
      setError(null)
      try {
        const { data, error: dbError } = await supabase
          .from('servicios')
          .select('*')
          .eq('activo', true)
          .order('orden', { ascending: true })
          .order('created_at', { ascending: false })

        if (dbError) throw dbError

        const serviciosConUI: ServicioUI[] = (data || []).map((s: any) => {
          const extras = getServiceExtras(s.titulo)
          return {
            id: s.id,
            titulo: s.titulo,
            descripcion: s.descripcion,
            precio: Number(s.precio) || 0,
            duracion: s.duracion,
            modalidad: s.modalidad,
            imagen_url: s.imagen_url,
            activo: s.activo,
            orden: s.orden,
            icon: getServiceIcon(s.titulo, s.modalidad),
            features: extras.features,
            benefits: extras.benefits,
            longDescription: extras.longDescription,
          }
        })

        setServicios(serviciosConUI)
      } catch (err: any) {
        console.error('Error loading servicios from DB:', err)
        setError(err?.message || 'Error al cargar servicios')
      } finally {
        setLoading(false)
      }
    }

    loadServicios()
  }, [])
if (loading) {
    return (
      <div className="min-h-screen py-20 flex items-center justify-center bg-gray-50 dark:bg-gray-950">
        <div className="flex flex-col items-center gap-4">
          <div className="w-12 h-12 border-4 border-primary-600 border-t-transparent rounded-full animate-spin" />
          <p className="text-gray-600 dark:text-gray-400">Cargando servicios desde la base de datos...</p>
        </div>
      </div>
    )
  }

  if (error) {
    return (
      <div className="min-h-screen py-20 flex items-center justify-center bg-gray-50 dark:bg-gray-950">
        <div className="text-center p-8 card-base max-w-md mx-4">
          <Shield className="w-16 h-16 text-red-500 mx-auto mb-4" />
          <h2 className="text-xl font-bold text-gray-900 dark:text-white mb-2">Error al cargar servicios</h2>
          <p className="text-gray-600 dark:text-gray-400 mb-6">{error}</p>
          <Button onClick={() => window.location.reload()}>Reintentar</Button>
        </div>
      </div>
    )
  }

  if (servicios.length === 0) {
    return (
      <div className="min-h-screen py-20 flex items-center justify-center bg-gray-50 dark:bg-gray-950">
        <div className="text-center p-8 card-base max-w-md mx-4">
          <Shield className="w-16 h-16 text-gray-400 mx-auto mb-4" />
          <h2 className="text-xl font-bold text-gray-900 dark:text-white mb-2">No hay servicios disponibles</h2>
          <p className="text-gray-600 dark:text-gray-400">Actualmente no hay servicios publicados en el catálogo.</p>
        </div>
      </div>
    )
  }
return (
    <div className="min-h-screen">
      <section className="relative overflow-hidden bg-gradient-to-b from-primary-50 to-white dark:from-gray-900 dark:to-gray-950 py-20 md:py-32">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <Link href={ROUTES.home} className="inline-flex items-center gap-2 text-primary-600 dark:text-primary-400 hover:underline mb-8">
            <ArrowLeft className="w-4 h-4" aria-hidden="true" />
            Volver al inicio
          </Link>
          <div className="mx-auto max-w-4xl text-center">
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-gray-900 dark:text-white mb-6">
              Nuestros
              <br />
              <span className="bg-gradient-to-r from-primary-600 to-primary-400 bg-clip-text text-transparent">
                Servicios IT
              </span>
            </h1>
            <p className="text-xl md:text-2xl text-gray-600 dark:text-gray-400 mb-10 max-w-2xl mx-auto">
              Soluciones completas adaptadas a tus necesidades. Desde reparaciones puntuales hasta gestión integral de tu infraestructura tecnológica.
            </p>
          </div>
        </div>
        <div className="absolute top-0 left-0 right-0 bottom-0 overflow-hidden pointer-events-none">
          <div className="absolute -top-40 -right-40 w-80 h-80 rounded-full bg-primary-100/50 dark:bg-primary-900/20 blur-3xl" />
          <div className="absolute -bottom-40 -left-40 w-80 h-80 rounded-full bg-accent-100/50 dark:bg-accent-900/20 blur-3xl" />
        </div>
      </section>

      <section className="py-20 md:py-32 bg-white dark:bg-gray-950">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
            <div className="lg:col-span-1">
              <nav className="sticky top-24 space-y-2" aria-label="Lista de servicios">
                {servicios.map((service) => (
                  <Link
                    key={service.id}
                    href={`#${service.id}`}
                    className="group flex items-center gap-3 px-4 py-3 rounded-xl bg-gray-50 dark:bg-gray-900 hover:bg-primary-50 dark:hover:bg-primary-900/30 border border-gray-200 dark:border-gray-800 hover:border-primary-200 dark:hover:border-primary-800 transition-all duration-200"
                  >
                    <div className="w-10 h-10 rounded-xl bg-primary-100 dark:bg-primary-900/30 flex items-center justify-center flex-shrink-0 group-hover:scale-110 transition-transform">
                      <service.icon className="w-5 h-5 text-primary-600 dark:text-primary-400" aria-hidden="true" />
                    </div>
                    <div className="text-left">
                      <div className="font-medium text-gray-900 dark:text-white group-hover:text-primary-600 dark:group-hover:text-primary-400 transition-colors">
                        {service.titulo}
                      </div>
                      <div className="text-sm text-gray-500 dark:text-gray-400 line-clamp-1">{service.descripcion}</div>
                    </div>
                  </Link>
                ))}
              </nav>
            </div>

            <div className="lg:col-span-2 space-y-16">
{servicios.map((service) => (
                <article
                  key={service.id}
                  id={service.id}
                  className="card-base p-8 md:p-12 space-y-8"
                >
                  <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 border-b border-gray-200 dark:border-gray-800 pb-8">
                    <div>
                      <Badge variant="info" className="mb-3 capitalize">{service.modalidad}</Badge>
                      <h2 className="text-3xl font-bold text-gray-900 dark:text-white">{service.titulo}</h2>
                      <p className="text-sm text-gray-500 mt-1">{service.descripcion}</p>
                    </div>
                    <div className="text-right">
                      <span className="text-xs text-gray-400 block">Precio</span>
                      <span className="text-3xl font-bold text-primary-600">{formatPrice(service.precio)}</span>
                      {service.duracion && (
                        <span className="text-sm text-gray-500 block mt-1">{service.duracion}</span>
                      )}
                    </div>
                  </div>

                  <div className="space-y-4">
                    <h3 className="text-lg font-bold text-gray-900 dark:text-white">¿En qué consiste este servicio?</h3>
                    <p className="text-base text-gray-600 dark:text-gray-400 leading-relaxed">{service.longDescription}</p>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-8">
                    <div>
                      <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4 flex items-center gap-2">
                        <Check className="w-5 h-5 text-accent-600 dark:text-accent-400" aria-hidden="true" />
                        Qué incluye
                      </h3>
                      <ul className="space-y-3">
                        {service.features.map((feature) => (
                          <li key={feature} className="flex items-start gap-3 text-gray-600 dark:text-gray-400">
                            <Check className="w-5 h-5 text-accent-600 dark:text-accent-400 flex-shrink-0 mt-0.5" aria-hidden="true" />
                            <span>{feature}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                    <div>
                      <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4 flex items-center gap-2">
                        <Shield className="w-5 h-5 text-primary-600 dark:text-primary-400" aria-hidden="true" />
                        Beneficios
                      </h3>
                      <ul className="space-y-3">
                        {service.benefits.map((benefit) => (
                          <li key={benefit} className="flex items-start gap-3 text-gray-600 dark:text-gray-400">
                            <ArrowRight className="w-5 h-5 text-primary-600 dark:text-primary-400 flex-shrink-0 mt-0.5" aria-hidden="true" />
                            <span>{benefit}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  </div>

                  <Link
                    href={ROUTES.contacto}
                    className="inline-flex items-center gap-2 text-primary-600 dark:text-primary-400 font-medium hover:text-primary-700 dark:hover:text-primary-300 transition-colors group"
                  >
                    Solicitar presupuesto para {service.titulo}
                    <ChevronRight className="w-4 h-4 transition-transform group-hover:translate-x-1" aria-hidden="true" />
                  </Link>
                </article>
              ))}
            </div>
          </div>
        </div>
      </section>

      <section className="py-20 md:py-32 relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-r from-primary-600 via-primary-700 to-primary-800" />
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
          <div className="mx-auto max-w-3xl text-center">
            <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold text-white mb-6">
              ¿No encuentras lo que buscas?
            </h2>
            <p className="text-lg text-primary-100 mb-8">
              Diseñamos soluciones a medida. Cuéntanos tu caso y te propondremos la mejor opción.
            </p>
            <Link href={ROUTES.contacto}>
              <Button size="lg" variant="secondary" className="group bg-white text-primary-600 hover:bg-gray-100">
                Contactar ahora
                <ArrowRight className="w-5 h-5 transition-transform group-hover:translate-x-1" aria-hidden="true" />
              </Button>
            </Link>
          </div>
        </div>
      </section>
    </div>
  )
}
