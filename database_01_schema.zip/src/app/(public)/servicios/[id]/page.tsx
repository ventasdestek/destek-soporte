'use client'

import { useState, useEffect } from 'react'
import Link from 'next/link'
import { useParams } from 'next/navigation'
import { Wrench, ArrowLeft, PhoneCall, CheckCircle, Clock, ShieldCheck, Monitor, Wifi, Database, Cpu, Headphones, Shield } from 'lucide-react'
import { Button, Badge } from '@/components/ui'
import { ROUTES, COMPANY_CONFIG } from '@/lib/constants'
import { formatPrice } from '@/utils/format'
import { createClient } from '@/lib/supabase/client'

interface ServicioDB {
  id: string
  titulo: string
  descripcion: string
  precio: number
  duracion: string | null
  modalidad: 'online' | 'presencial' | 'hibrido'
  imagen_url: string | null
  activo: boolean
  orden: number
}

function getServiceIcon(titulo: string, modalidad: string) {
  const title = titulo.toLowerCase()
  if (title.includes('reparación') || title.includes('pc') || title.includes('hardware')) return Cpu
  if (title.includes('mantenimiento') || title.includes('monitor')) return Monitor
  if (title.includes('red') || title.includes('wifi')) return Wifi
  if (title.includes('seguridad') || title.includes('auditor') || title.includes('shield')) return Shield
  if (title.includes('datos') || title.includes('recuperación') || title.includes('database')) return Database
  if (title.includes('asesor') || title.includes('consult')) return Headphones
  if (modalidad === 'online') return Monitor
  if (modalidad === 'presencial') return Cpu
  return Wrench
}

function getServiceExtras(titulo: string): { features: string[]; benefits: string[]; longDescription: string } {
  const title = titulo.toLowerCase()
  if (title.includes('reparación') || title.includes('pc')) {
    return { features: ['Cambio de componentes', 'Limpieza y mantenimiento preventivo', 'Optimización de rendimiento', 'Recuperación de datos', 'Reinstalación Windows/Linux', 'Eliminación virus y malware', 'Reparación portátiles', 'Diagnóstico gratuito'], benefits: ['Garantía 6 meses', 'Diagnóstico gratuito', 'Piezas originales', 'Reparación 24-48h'], longDescription: 'Nuestro servicio de reparación de PC cubre todo tipo de incidencias hardware y software. Desde cambios de componentes dañados hasta resolución de problemas de software.' }
  }
  if (title.includes('mantenimiento')) {
    return { features: ['Limpieza equipos', 'Actualizaciones seguridad', 'Monitoreo 24/7', 'Soporte prioritario <2h', 'Gestión inventario IT', 'Backups verificados', 'Informes mensuales', 'Sustitución proactiva'], benefits: ['Reduce 80% incidencias', 'Alarga vida útil 3-5 años', 'Coste fijo mensual', 'Soporte remoto ilimitado'], longDescription: 'Ofrecemos planes de mantenimiento adaptados a cada necesidad. Desde mantenimiento puntual hasta contratos mensuales con monitorización remota 24/7.' }
  }
  if (title.includes('red') || title.includes('wifi')) {
    return { features: ['Cableado Cat6/Cat6a/Fibra', 'WiFi Mesh empresarial', 'Firewall, VLANs, VPN', 'Optimización señal', 'Puntos acceso PoE', 'QoS voz/vídeo'], benefits: ['Cobertura total', 'Velocidad máxima', 'Red segura', 'Gestión centralizada'], longDescription: 'Diseñamos infraestructuras de red robustas y seguras. Cableado estructurado, redes WiFi Mesh, VLANs, QoS y gestión centralizada.' }
  }
  if (title.includes('seguridad') || title.includes('auditor')) {
    return { features: ['Antivirus/EDR centralizado', 'Firewall next-gen IPS/IDS', 'VPN WireGuard/OpenVPN', 'Backups inmutables 3-2-1', 'Auditorías vulnerabilidades', 'Formación phishing', 'Gestión parches CVE', 'Cifrado BitLocker/TLS'], benefits: ['Cumplimiento RGPD', 'Protección ransomware', 'Visibilidad amenazas', 'Respuesta <4h'], longDescription: 'Estrategia defensa en capas: endpoint protection, firewalls next-gen, backup inmutable, formación concienciación.' }
  }
  if (title.includes('recuperación') || title.includes('datos')) {
    return { features: ['HDD mecánicos', 'SSD/NVMe', 'USB, tarjetas SD', 'Móviles iOS/Android', 'Cifrado BitLocker/LUKS', 'Borrado accidental/formateo', 'Cámara limpia ISO 5'], benefits: ['Diagnóstico gratuito', 'Tasa éxito >95%', 'Confidencialidad NDA', 'No recovery no fee'], longDescription: 'Recuperación datos con laboratorio propio y cámara limpia ISO 5. HDD, SSD, USB, SD, móviles. Diagnóstico gratuito.' }
  }
  if (title.includes('asesor') || title.includes('consult')) {
    return { features: ['Auditoría IT y licencias', 'Arquitectura cloud AWS/Azure/GCP', 'Transformación digital', 'Optimización costes', 'ERP/CRM implantación', 'BCP/DRP', 'Cumplimiento RGPD/ISO27001', 'Gestión proveedores'], benefits: ['Ahorro 25% costes IT', 'Alineación tech-negocio', 'Independencia proveedores', 'Acompañamiento continuo'], longDescription: 'CIO/CTO externo. Auditoría infraestructura, hoja ruta tecnológica alineada a objetivos negocio.' }
  }
  return { features: ['Servicio personalizado', 'Equipo certificado', 'Garantía satisfacción'], benefits: ['Solución adaptada', 'Soporte post-servicio'], longDescription: 'Servicio profesional adaptado a tus necesidades. Evaluamos tu caso y proponemos la mejor solución.' }
}

export default function ServicioDetallePage() {
  const params = useParams()
  const id = params?.id
  const [servicio, setServicio] = useState<ServicioDB | null>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const supabase = createClient()
useEffect(() => {
    if (!id) return

    async function loadServicio() {
      setLoading(true)
      setError(null)
      try {
        const { data, error: dbError } = await supabase
          .from('servicios')
          .select('*')
          .eq('id', id)
          .eq('activo', true)
          .single()

        if (dbError) throw dbError

        setServicio(data)
      } catch (err: any) {
        console.error('Error loading servicio from DB:', err)
        setError(err?.message || 'Error al cargar el servicio')
      } finally {
        setLoading(false)
      }
    }

    loadServicio()
  }, [id])

  if (loading) {
    return (
      <div className="py-16 bg-gray-50 dark:bg-gray-950 min-h-screen">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 flex items-center justify-center h-96">
          <div className="flex flex-col items-center gap-4">
            <div className="w-12 h-12 border-4 border-primary-600 border-t-transparent rounded-full animate-spin" />
            <p className="text-gray-600 dark:text-gray-400">Cargando servicio...</p>
          </div>
        </div>
      </div>
    )
  }

  if (error || !servicio) {
    return (
      <div className="py-16 bg-gray-50 dark:bg-gray-950 min-h-screen">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <Link href={ROUTES.servicios} className="inline-flex items-center text-sm font-semibold text-primary-600 dark:text-primary-400 hover:underline mb-8">
            <ArrowLeft className="w-4 h-4 mr-2" /> Volver a la lista de servicios
          </Link>
          <div className="text-center p-8 card-base max-w-md mx-auto">
            <ShieldCheck className="w-16 h-16 text-red-500 mx-auto mb-4" />
            <h2 className="text-xl font-bold text-gray-900 dark:text-white mb-2">Servicio no encontrado</h2>
            <p className="text-gray-600 dark:text-gray-400 mb-6">{error || 'El servicio solicitado no existe o no está disponible.'}</p>
            <Link href={ROUTES.servicios}>
              <Button>Volver a Servicios</Button>
            </Link>
          </div>
        </div>
      </div>
    )
  }

  const IconComponent = getServiceIcon(servicio.titulo, servicio.modalidad)
  const extras = getServiceExtras(servicio.titulo)

  return (
    <div className="py-16 bg-gray-50 dark:bg-gray-950 min-h-screen">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <Link href={ROUTES.servicios} className="inline-flex items-center text-sm font-semibold text-primary-600 dark:text-primary-400 hover:underline mb-8">
          <ArrowLeft className="w-4 h-4 mr-2" /> Volver a la lista de servicios
        </Link>

        <div className="card-base p-8 md:p-12 space-y-8">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 border-b border-gray-200 dark:border-gray-800 pb-8">
            <div>
              <Badge variant="info" className="mb-3 capitalize">{servicio.modalidad}</Badge>
              <h1 className="text-3xl font-bold text-gray-900 dark:text-white">{servicio.titulo}</h1>
              <p className="text-sm text-gray-500 mt-1">{servicio.descripcion}</p>
            </div>
            <div className="text-right">
              <span className="text-xs text-gray-400 block">Precio</span>
              <span className="text-3xl font-bold text-primary-600">{formatPrice(servicio.precio)}</span>
              {servicio.duracion && (
                <span className="text-sm text-gray-500 block mt-1">{servicio.duracion}</span>
              )}
            </div>
          </div>

          <div className="space-y-4">
            <h2 className="text-lg font-bold text-gray-900 dark:text-white">¿En qué consiste este servicio?</h2>
            <p className="text-base text-gray-600 dark:text-gray-400 leading-relaxed">{extras.longDescription}</p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-4">
            <div className="p-4 rounded-xl bg-gray-100 dark:bg-gray-800 flex items-start gap-3">
              <Clock className="w-5 h-5 text-primary-600 mt-0.5" />
              <div>
                <p className="font-bold text-sm text-gray-900 dark:text-white">Tiempo de Respuesta</p>
                <p className="text-xs text-gray-500">Según modalidad y disponibilidad</p>
              </div>
            </div>
            <div className="p-4 rounded-xl bg-gray-100 dark:bg-gray-800 flex items-start gap-3">
              <ShieldCheck className="w-5 h-5 text-primary-600 mt-0.5" />
              <div>
                <p className="font-bold text-sm text-gray-900 dark:text-white">Garantía de Calidad</p>
                <p className="text-xs text-gray-500">Servicio profesional con garantía</p>
              </div>
            </div>
          </div>

          <div className="pt-6 border-t border-gray-200 dark:border-gray-800 flex flex-col sm:flex-row gap-4">
            <Link href={ROUTES.contacto} className="w-full sm:w-1/2">
              <Button className="w-full justify-center" size="lg">
                Solicitar Este Servicio
              </Button>
            </Link>
            <a href={`${COMPANY_CONFIG.whatsapp}?text=Hola,%20necesito%20información%20sobre%20${encodeURIComponent(servicio.titulo)}`} target="_blank" rel="noopener noreferrer" className="w-full sm:w-1/2">
              <Button variant="outline" className="w-full justify-center" size="lg">
                <PhoneCall className="w-4 h-4 mr-2" /> WhatsApp Técnico Directo
              </Button>
            </a>
          </div>
        </div>
      </div>
    </div>
  )
}
