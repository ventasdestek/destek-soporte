import { Metadata } from 'next'

export const metadata: Metadata = {
  title: 'Aviso Legal | Destek Soporte',
  description: 'Aviso legal y términos de uso de Destek Soporte.',
}

export default function AvisoLegalPage() {
  return (
    <div className="min-h-screen py-20 md:py-32">
      <div className="section-container max-w-4xl">
        <h1 className="text-4xl font-bold mb-8 text-gray-900 dark:text-white">Aviso Legal</h1>
        <div className="prose dark:prose-invert max-w-none space-y-6 text-gray-600 dark:text-gray-400">
          <p>En cumplimiento con el deber de información recogido en artículo 10 de la Ley 34/2002, de 11 de julio, de Servicios de la Sociedad de la Información y del Comercio Electrónico, a continuación se refleja los siguientes datos:</p>
          <h2 className="text-2xl font-semibold text-gray-900 dark:text-white mt-8">1. Datos Identificativos</h2>
          <p>La empresa titular de esta web es Destek Soporte S.L., con domicilio a estos efectos en Calle Ejemplo 123, Madrid, España, N.I.F.: B-00000000. Correo electrónico de contacto: contacto@desteksoporte.com.</p>
          <h2 className="text-2xl font-semibold text-gray-900 dark:text-white mt-8">2. Usuarios</h2>
          <p>El acceso y/o uso de este portal de Destek Soporte atribuye la condición de USUARIO, que acepta, desde dicho acceso y/o uso, las Condiciones Generales de Uso aquí reflejadas.</p>
          <h2 className="text-2xl font-semibold text-gray-900 dark:text-white mt-8">3. Propiedad Intelectual e Industrial</h2>
          <p>Destek Soporte es titular de todos los derechos de propiedad intelectual e industrial de su página web, así como de los elementos contenidos en la misma.</p>
        </div>
      </div>
    </div>
  )
}
