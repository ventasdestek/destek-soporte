'use client'

import { useState } from 'react'
import { Save } from 'lucide-react'
import { Button } from '@/components/ui'
import { useAuth } from '@/components/providers/AuthProvider'
import { createClient } from '@/lib/supabase/client'
import toast from 'react-hot-toast'

function ProfileForm({ user, onUpdated }: { user: NonNullable<ReturnType<typeof useAuth>['user']>; onUpdated: () => Promise<void> }) {
  const [loading, setLoading] = useState(false)
  const [formData, setFormData] = useState(() => ({
    nombre: user.user_metadata?.nombre || '',
    apellido: user.user_metadata?.apellido || '',
    telefono: user.user_metadata?.telefono || '',
    direccion: user.user_metadata?.direccion || '',
  }))

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFormData({ ...formData, [e.target.name]: e.target.value })
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)
    const supabase = createClient()

    try {
      const { error } = await supabase.auth.updateUser({
        data: {
          nombre: formData.nombre,
          apellido: formData.apellido,
          telefono: formData.telefono,
          direccion: formData.direccion,
        },
      })
      if (error) {
        toast.error(error.message)
        return
      }
      await onUpdated()
      toast.success('Perfil actualizado correctamente')
    } catch {
      toast.error('Error al actualizar el perfil')
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="space-y-8 max-w-4xl">
      <div>
        <h1 className="text-2xl md:text-3xl font-bold text-gray-900 dark:text-white">Mi Perfil</h1>
        <p className="text-sm text-gray-600 dark:text-gray-400 mt-1">
          Actualiza tus datos personales y preferencias de contacto
        </p>
      </div>

      <div className="card-base p-8">
        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="flex items-center gap-4 pb-6 border-b border-gray-200 dark:border-gray-800">
            <div className="w-16 h-16 rounded-full bg-primary-100 dark:bg-primary-900/40 text-primary-600 dark:text-primary-400 flex items-center justify-center text-2xl font-bold">
              {formData.nombre?.charAt(0) || user?.email?.charAt(0) || 'U'}
            </div>
            <div>
              <p className="font-bold text-gray-900 dark:text-white text-lg">
                {formData.nombre} {formData.apellido}
              </p>
              <p className="text-sm text-gray-500">{user?.email}</p>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
            <div>
              <label className="block text-sm font-medium mb-1">Nombre</label>
              <input type="text" name="nombre" value={formData.nombre} onChange={handleChange} placeholder="Tu nombre" className="input-base" />
            </div>
            <div>
              <label className="block text-sm font-medium mb-1">Apellidos</label>
              <input type="text" name="apellido" value={formData.apellido} onChange={handleChange} placeholder="Tus apellidos" className="input-base" />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
            <div>
              <label className="block text-sm font-medium mb-1">Correo Electrónico</label>
              <input type="email" value={user?.email || ''} disabled className="input-base bg-gray-100 dark:bg-gray-800 text-gray-500 cursor-not-allowed" />
            </div>
            <div>
              <label className="block text-sm font-medium mb-1">Teléfono</label>
              <input type="tel" name="telefono" value={formData.telefono} onChange={handleChange} placeholder="+34 600 000 000" className="input-base" />
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium mb-1">Dirección / Empresa</label>
            <input type="text" name="direccion" value={formData.direccion} onChange={handleChange} placeholder="Dirección completa" className="input-base" />
          </div>

          <div className="pt-4 flex justify-end">
            <Button type="submit" loading={loading} className="w-full sm:w-auto">
              <Save className="w-4 h-4 mr-2" /> Guardar Cambios
            </Button>
          </div>
        </form>
      </div>
    </div>
  )
}

export default function PerfilPage() {
  const { user, refreshUser } = useAuth()

  if (!user) {
    return (
      <div className="text-center py-12 text-gray-600 dark:text-gray-400">Cargando perfil…</div>
    )
  }

  return <ProfileForm user={user} onUpdated={refreshUser} />
}
