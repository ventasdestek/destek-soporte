'use client'

import { useState, useEffect } from 'react'
import Link from 'next/link'
import { Headphones, Clock, CheckCircle, PlusCircle, ArrowRight, ShieldCheck, PhoneCall, Loader2 } from 'lucide-react'
import { useAuth } from '@/components/providers/AuthProvider'
import { Button } from '@/components/ui'
import { ROUTES, COMPANY_CONFIG } from '@/lib/constants'
import { createClient } from '@/lib/supabase/client'

export default function DashboardPage() {
  const { user } = useAuth()
  const supabase = createClient()
  const nombre = user?.user_metadata?.nombre || 'Estimado cliente'

  const [pendientesCount, setPendientesCount] = useState<number | null>(null)
  const [resueltosCount, setResueltosCount] = useState<number | null>(null)
  const [estadoCuenta, setEstadoCuenta] = useState<string>('Al Día')
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    if (!user) return

    async function loadUserStats() {
      setLoading(true)
      try {
        // Query pending/processing orders
        const { count: pending, error: pendingErr } = await supabase
          .from('pedidos')
          .select('*', { count: 'exact', head: true })
          .eq('cliente_id', user.id)
          .in('estado', ['pendiente', 'procesando'])

        if (pendingErr) throw pendingErr

        // Query resolved services
        const { count: resolved, error: resolvedErr } = await supabase
          .from('pedidos')
          .select('*', { count: 'exact', head: true })
          .eq('cliente_id', user.id)
          .eq('tipo', 'servicio')
          .eq('estado', 'completado')

        if (resolvedErr) throw resolvedErr

        setPendientesCount(pending || 0)
        setResueltosCount(resolved || 0)
        setEstadoCuenta((pending || 0) > 0 ? 'Pendiente' : 'Al Día')
      } catch (err) {
        console.error('Error loading user stats from DB:', err)
      } finally {
        setLoading(false)
      }
    }

    loadUserStats()
  }, [user])

  return (
    <div className="space-y-8">
      {/* Header Bienvenida */}
      <div className="card-base p-8 bg-gradient-to-r from-primary-600 to-primary-800 text-white border-0">
        <h1 className="text-2xl md:text-3xl font-bold">¡Hola, {nombre}! 👋</h1>
        <p className="text-primary-100 mt-2 max-w-2xl">
          Bienvenido a tu panel de gestión técnica en Destek Soporte. Desde aquí puedes consultar tus solicitudes activas, pedir asistencia y comunicarte con nuestros técnicos.
        </p>
        <div className="mt-6 flex flex-wrap gap-4">
          <Link href={ROUTES.contacto}>
            <Button variant="secondary" className="bg-white text-primary-600 hover:bg-gray-100">
              <PlusCircle className="w-4 h-4 mr-2" /> Nueva Solicitud de Soporte
            </Button>
          </Link>
          <a href={ROUTES.whatsapp} target="_blank" rel="noopener noreferrer">
            <Button variant="ghost" className="text-white border border-white/30 hover:bg-white/10">
              <PhoneCall className="w-4 h-4 mr-2" /> WhatsApp Técnico Directo
            </Button>
          </a>
        </div>
      </div>

      {/* Tarjetas de Resumen */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="card-base p-6 border-l-4 border-l-yellow-500">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-500">Solicitudes Pendientes</p>
              <p className="text-3xl font-bold text-gray-900 dark:text-white mt-1">
                {loading ? <Loader2 className="w-5 h-5 animate-spin text-gray-400" /> : pendientesCount}
              </p>
            </div>
            <div className="w-12 h-12 rounded-xl bg-yellow-100 dark:bg-yellow-900/30 text-yellow-600 flex items-center justify-center">
              <Clock className="w-6 h-6" />
            </div>
          </div>
        </div>

        <div className="card-base p-6 border-l-4 border-l-green-500">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-500">Servicios Resueltos</p>
              <p className="text-3xl font-bold text-gray-900 dark:text-white mt-1">
                {loading ? <Loader2 className="w-5 h-5 animate-spin text-gray-400" /> : resueltosCount}
              </p>
            </div>
            <div className="w-12 h-12 rounded-xl bg-green-100 dark:bg-green-900/30 text-green-600 flex items-center justify-center">
              <CheckCircle className="w-6 h-6" />
            </div>
          </div>
        </div>

        <div className="card-base p-6 border-l-4 border-l-blue-500">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-500">Estado de Cuenta</p>
              <p className={`text-xl font-bold mt-1 ${loading ? 'text-gray-400' : estadoCuenta === 'Al Día' ? 'text-green-600 dark:text-green-400' : 'text-yellow-600 dark:text-yellow-400'}`}>
                {loading ? <Loader2 className="w-5 h-5 animate-spin text-gray-400" /> : estadoCuenta}
              </p>
            </div>
            <div className="w-12 h-12 rounded-xl bg-blue-100 dark:bg-blue-900/30 text-blue-600 flex items-center justify-center">
              <ShieldCheck className="w-6 h-6" />
            </div>
          </div>
        </div>
      </div>

      {/* Accesos rápidos e información de soporte */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <div className="card-base p-6">
          <h2 className="text-lg font-bold text-gray-900 dark:text-white mb-4 flex items-center gap-2">
            <Headphones className="w-5 h-5 text-primary-600" /> Soporte Telefónico Prioritario
          </h2>
          <p className="text-sm text-gray-600 dark:text-gray-400 mb-4 leading-relaxed">
            Si estás experimentando una falla crítica en tus servidores o sistemas, contáctanos directamente a nuestra línea de emergencia.
          </p>
          <div className="p-4 rounded-xl bg-gray-100 dark:bg-gray-800 flex items-center justify-between">
            <div>
              <p className="text-xs text-gray-500">Línea Directa Cliente</p>
              <p className="font-mono font-bold text-gray-900 dark:text-white">{COMPANY_CONFIG.phone}</p>
            </div>
            <a href={`tel:${COMPANY_CONFIG.phone}`}>
              <Button size="sm">Llamar Ahora</Button>
            </a>
          </div>
        </div>

        <div className="card-base p-6">
          <h2 className="text-lg font-bold text-gray-900 dark:text-white mb-4">¿Necesitas ayuda con tu equipo?</h2>
          <p className="text-sm text-gray-600 dark:text-gray-400 mb-6 leading-relaxed">
            Puedes descargar nuestro software de asistencia remota previa instrucción de uno de nuestros ingenieros técnicos.
          </p>
          <div className="flex gap-4">
            <Link href={ROUTES.servicios} className="w-full">
              <Button variant="outline" className="w-full justify-center">
                Ver Servicios Contratables <ArrowRight className="w-4 h-4 ml-2" />
              </Button>
            </Link>
          </div>
        </div>
      </div>
    </div>
  )
}
