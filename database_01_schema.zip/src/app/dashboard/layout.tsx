'use client'

import Link from 'next/link'
import { usePathname, useRouter } from 'next/navigation'
import { LayoutDashboard, User, ClipboardList, LogOut, Home, Monitor } from 'lucide-react'
import { useAuth } from '@/components/providers/AuthProvider'
import { ROUTES } from '@/lib/constants'
import { cn } from '@/utils/cn'

const navigation = [
  { name: 'Resumen', href: ROUTES.dashboard, icon: LayoutDashboard },
  { name: 'Mis Solicitudes', href: ROUTES.misSolicitudes, icon: ClipboardList },
  { name: 'Mi Perfil', href: ROUTES.perfil, icon: User },
]

export default function DashboardLayout({ children }: { children: React.ReactNode }) {
  const pathname = usePathname()
  const router = useRouter()
  const { user, signOut } = useAuth()

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-950 flex flex-col md:flex-row">
      {/* Sidebar Desktop & Header Mobile */}
      <aside className="w-full md:w-64 bg-white dark:bg-gray-900 border-r border-gray-200 dark:border-gray-800 flex-shrink-0">
        <div className="p-6 border-b border-gray-200 dark:border-gray-800 flex items-center justify-between">
          <Link href={ROUTES.home} className="flex items-center gap-2">
            <div className="w-9 h-9 rounded-xl bg-primary-600 flex items-center justify-center text-white">
              <Monitor className="w-5 h-5" />
            </div>
            <span className="font-bold text-lg text-gray-900 dark:text-white">Destek Soporte</span>
          </Link>
        </div>

        {/* User preview */}
        <div className="p-4 mx-4 my-4 rounded-xl bg-primary-50 dark:bg-primary-950/50 border border-primary-100 dark:border-primary-900">
          <p className="text-xs text-primary-600 dark:text-primary-400 font-semibold uppercase tracking-wider">Cliente</p>
          <p className="text-sm font-bold text-gray-900 dark:text-white truncate">
            {user?.user_metadata?.nombre || user?.email || 'Usuario'}
          </p>
          <p className="text-xs text-gray-500 truncate">{user?.email}</p>
        </div>

        {/* Nav Links */}
        <nav className="p-4 space-y-1.5">
          {navigation.map((item) => {
            const isActive = pathname === item.href
            return (
              <Link
                key={item.name}
                href={item.href}
                className={cn(
                  'flex items-center gap-3 px-4 py-3 text-sm font-medium rounded-xl transition-colors',
                  isActive
                    ? 'bg-primary-600 text-white shadow-glow'
                    : 'text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-800'
                )}
              >
                <item.icon className="w-5 h-5" />
                {item.name}
              </Link>
            )
          })}

          <div className="pt-6 mt-6 border-t border-gray-200 dark:border-gray-800 space-y-1.5">
            <Link
              href={ROUTES.home}
              className="flex items-center gap-3 px-4 py-3 text-sm font-medium text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-800 rounded-xl transition-colors"
            >
              <Home className="w-5 h-5" />
              Volver a la Web
            </Link>
            <button
              onClick={async () => { await signOut(); router.push(ROUTES.login) }}
              className="w-full flex items-center gap-3 px-4 py-3 text-sm font-medium text-red-600 dark:text-red-400 hover:bg-red-50 dark:hover:bg-red-950 rounded-xl transition-colors"
            >
              <LogOut className="w-5 h-5" />
              Cerrar Sesión
            </button>
          </div>
        </nav>
      </aside>

      {/* Main Content Area */}
      <main className="flex-1 p-6 md:p-10 overflow-y-auto">
        {children}
      </main>
    </div>
  )
}
