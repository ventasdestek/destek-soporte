'use client'

import { useState, useEffect } from 'react'
import Link from 'next/link'
import { ClipboardList, PlusCircle, Search, Clock, CheckCircle2, AlertCircle, XCircle, Loader2 } from 'lucide-react'
import { Button, Badge } from '@/components/ui'
import { ROUTES } from '@/lib/constants'
import { createClient } from '@/lib/supabase/client'
import { useAuth } from '@/components/providers/AuthProvider'

interface Solicitud {
  id: string
  servicio: string
  modalidad: string
  fecha: string
  estado: string
  detalles: string
}

export default function MisSolicitudesPage() {
  const { user } = useAuth()
  const supabase = createClient()
  const [solicitudes, setSolicitudes] = useState<Solicitud[]>([])
  const [filtro, setFiltro] = useState('todos')
  const [busqueda, setBusqueda] = useState('')
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    if (!user) return

    async function loadSolicitudes() {
      setLoading(true)
      try {
        const { data, error } = await supabase
          .from('pedidos')
          .select('*')
          .eq('cliente_id', user.id)
          .order('created_at', { ascending: false })

        if (error) throw error

        if (data) {
          const mapped = data.map((item: any) => ({
            id: `SOL-${item.id.slice(0, 8).toUpperCase()}`,
            servicio: item.item,
            modalidad: item.tipo === 'servicio' ? 'Servicio' : 'Producto',
            fecha: new Date(item.created_at).toLocaleDateString('es-ES'),
            estado: item.estado,
            detalles: item.notes || item.notas || 'Sin descripción o notas adicionales.',
          }))
          setSolicitudes(mapped)
        }
      } catch (err) {
        console.error('Error fetching solicitudes:', err)
      } finally {
        setLoading(false)
      }
    }

    loadSolicitudes()
  }, [user])

  const solicitudesFiltradas = solicitudes.filter((s) => {
    const coincideEstado = filtro === 'todos' || s.estado === filtro
    const coincideBusq = s.servicio.toLowerCase().includes(busqueda.toLowerCase()) || s.id.toLowerCase().includes(busqueda.toLowerCase())
    return coincideEstado && coincideBusq
  })

  const getBadgeVariant = (estado: string) => {
    switch (estado) {
      case 'completado': return 'success'
      case 'procesando': return 'info'
      case 'pendiente': return 'warning'
      case 'cancelado': return 'danger'
      default: return 'default'
    }
  }

  return (
    <div className="space-y-8">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl md:text-3xl font-bold text-gray-900 dark:text-white">Mis Solicitudes</h1>
          <p className="text-sm text-gray-600 dark:text-gray-400 mt-1">
            Historial de servicios contratados y estado de asistencias técnicas
          </p>
        </div>
        <Link href={ROUTES.contacto}>
          <Button className="w-full sm:w-auto">
            <PlusCircle className="w-4 h-4 mr-2" /> Nueva Solicitud
          </Button>
        </Link>
      </div>

      {/* Filtros y Buscador */}
      <div className="card-base p-4 flex flex-col md:flex-row gap-4 justify-between items-center">
        <div className="relative w-full md:w-80">
          <input
            type="text"
            placeholder="Buscar por ID o servicio..."
            value={busqueda}
            onChange={(e) => setBusqueda(e.target.value)}
            className="input-base pl-10 text-sm py-2"
          />
          <Search className="w-4 h-4 text-gray-400 absolute left-3 top-1/2 -translate-y-1/2" />
        </div>

        <div className="flex gap-2 w-full md:w-auto overflow-x-auto">
          {['todos', 'pendiente', 'procesando', 'completado'].map((cat) => (
            <button
              key={cat}
              onClick={() => setFiltro(cat)}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold capitalize transition-colors ${
                filtro === cat
                  ? 'bg-primary-600 text-white'
                  : 'bg-gray-100 dark:bg-gray-800 text-gray-600 dark:text-gray-400 hover:bg-gray-200'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>
      </div>

      {/* Lista de solicitudes */}
      <div className="space-y-4">
        {loading ? (
          <div className="card-base p-12 text-center flex flex-col items-center justify-center text-gray-500">
            <Loader2 className="w-8 h-8 animate-spin text-primary-600 mb-2" />
            <p className="text-sm">Cargando tus solicitudes...</p>
          </div>
        ) : solicitudesFiltradas.length > 0 ? (
          solicitudesFiltradas.map((solicitud) => (
            <div key={solicitud.id} className="card-base p-6 hover:border-primary-500/50 transition-colors">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-gray-200 dark:border-gray-800 pb-4 mb-4">
                <div>
                  <span className="text-xs font-mono font-bold text-primary-600 dark:text-primary-400">{solicitud.id}</span>
                  <h3 className="text-lg font-bold text-gray-900 dark:text-white mt-0.5">{solicitud.servicio}</h3>
                </div>
                <div className="flex items-center gap-3">
                  <Badge variant={getBadgeVariant(solicitud.estado)} className="capitalize px-3 py-1 text-xs">
                    {solicitud.estado}
                  </Badge>
                  <span className="text-xs text-gray-500 font-medium">{solicitud.fecha}</span>
                </div>
              </div>
              <p className="text-sm text-gray-600 dark:text-gray-400 mb-3">{solicitud.detalles}</p>
              <div className="flex items-center gap-4 text-xs text-gray-500">
                <span>Tipo: <strong>{solicitud.modalidad}</strong></span>
              </div>
            </div>
          ))
        ) : (
          <div className="card-base p-12 text-center">
            <ClipboardList className="w-12 h-12 text-gray-400 mx-auto mb-3" />
            <p className="text-lg font-semibold text-gray-900 dark:text-white">No se encontraron solicitudes</p>
            <p className="text-sm text-gray-500 mt-1">Intenta cambiar los filtros o realiza una nueva solicitud.</p>
          </div>
        )}
      </div>
    </div>
  )
}
