'use client'

import { HTMLAttributes, forwardRef } from 'react'
import { cn } from '@/utils/cn'

export interface SpinnerProps extends HTMLAttributes<HTMLDivElement> {
  size?: 'sm' | 'md' | 'lg' | 'xl'
  color?: 'primary' | 'white' | 'gray' | 'accent'
}

export const Spinner = forwardRef<HTMLDivElement, SpinnerProps>(
  ({ className, size = 'md', color = 'primary', ...props }, ref) => {
    const sizes = {
      sm: 'w-4 h-4 border-2',
      md: 'w-6 h-6 border-2',
      lg: 'w-8 h-8 border-3',
      xl: 'w-12 h-12 border-4',
    }

    const colors = {
      primary: 'border-primary-600 border-t-transparent',
      white: 'border-white border-t-transparent',
      gray: 'border-gray-600 border-t-transparent',
      accent: 'border-accent-600 border-t-transparent',
    }

    return (
      <div
        ref={ref}
        className={cn(
          'inline-block rounded-full animate-spin',
          sizes[size],
          colors[color],
          className
        )}
        role="status"
        aria-label="Cargando"
        {...props}
      >
        <span className="sr-only">Cargando...</span>
      </div>
    )
  }
)

Spinner.displayName = 'Spinner'

// Spinner de página completa
export function PageSpinner({ message = 'Cargando...' }: { message?: string }) {
  return (
    <div className="fixed inset-0 z-50 flex flex-col items-center justify-center bg-white/80 dark:bg-gray-900/80 backdrop-blur-sm">
      <Spinner size="xl" color="primary" />
      <p className="mt-4 text-gray-600 dark:text-gray-400 text-sm">{message}</p>
    </div>
  )
}

// Spinner para botones
export function ButtonSpinner({ size = 'md' }: { size?: 'sm' | 'md' | 'lg' }) {
  return <Spinner size={size} color="white" />
}