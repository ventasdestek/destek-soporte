'use client'

import { HTMLAttributes, forwardRef } from 'react'
import { cn } from '@/utils/cn'

export interface SkeletonProps extends HTMLAttributes<HTMLDivElement> {
  variant?: 'text' | 'circular' | 'rectangular'
  width?: string | number
  height?: string | number
}

export const Skeleton = forwardRef<HTMLDivElement, SkeletonProps>(
  ({ className, variant = 'text', width, height, ...props }, ref) => {
    const variants = {
      text: 'h-4 rounded w-full',
      circular: 'rounded-full',
      rectangular: 'rounded-xl',
    }

    return (
      <div
        ref={ref}
        className={cn(
          'animate-pulse bg-gray-200 dark:bg-gray-700',
          variants[variant],
          className
        )}
        style={{ width, height }}
        {...props}
      />
    )
  }
)

Skeleton.displayName = 'Skeleton'

// Skeletons predefinidos para componentes comunes
export function CardSkeleton() {
  return (
    <div className="space-y-4 p-6">
      <Skeleton variant="rectangular" height="200" width="100%" />
      <Skeleton variant="text" width="60%" />
      <Skeleton variant="text" width="40%" />
      <Skeleton variant="text" width="80%" />
      <div className="flex gap-2 pt-4">
        <Skeleton variant="rectangular" width="80" height="36" />
        <Skeleton variant="rectangular" width="80" height="36" />
      </div>
    </div>
  )
}

export function TableSkeleton({ rows = 5, columns = 4 }: { rows?: number; columns?: number }) {
  return (
    <div className="space-y-3">
      {/* Header */}
      <div className="grid gap-4 p-4 bg-gray-100 dark:bg-gray-800 rounded-xl">
        <div className="grid gap-4" style={{ gridTemplateColumns: `repeat(${columns}, 1fr)` }}>
          {Array.from({ length: columns }).map((_, i) => (
            <Skeleton key={i} variant="text" width="80%" />
          ))}
        </div>
      </div>
      {/* Rows */}
      {Array.from({ length: rows }).map((_, rowIndex) => (
        <div key={rowIndex} className="grid gap-4 p-4 border-b border-gray-200 dark:border-gray-700">
          <div className="grid gap-4" style={{ gridTemplateColumns: `repeat(${columns}, 1fr)` }}>
            {Array.from({ length: columns }).map((_, colIndex) => (
              <Skeleton key={colIndex} variant="text" width="90%" />
            ))}
          </div>
        </div>
      ))}
    </div>
  )
}

export function ServiceCardSkeleton() {
  return (
    <div className="space-y-4">
      <Skeleton variant="rectangular" height="180" width="100%" />
      <Skeleton variant="text" width="70%" />
      <Skeleton variant="text" width="50%" />
      <Skeleton variant="text" width="100%" />
      <div className="flex items-center justify-between pt-2">
        <Skeleton variant="text" width="60" height="24" />
        <Skeleton variant="rectangular" width="100" height="36" />
      </div>
    </div>
  )
}

export function ProductCardSkeleton() {
  return (
    <div className="space-y-3">
      <Skeleton variant="rectangular" height="180" width="100%" />
      <Skeleton variant="text" width="80%" />
      <Skeleton variant="text" width="50%" />
      <div className="flex items-center justify-between">
        <Skeleton variant="text" width="80" height="24" />
        <Skeleton variant="rectangular" width="100" height="36" />
      </div>
    </div>
  )
}

export function DashboardStatsSkeleton() {
  return (
    <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
      {Array.from({ length: 4 }).map((_, i) => (
        <div key={i} className="p-6 bg-white dark:bg-gray-800 rounded-2xl border border-gray-200 dark:border-gray-700">
          <Skeleton variant="text" width="60%" />
          <div className="mt-4 flex items-baseline gap-2">
            <Skeleton variant="text" width="60" height="32" />
            <Skeleton variant="text" width="40" height="20" />
          </div>
        </div>
      ))}
    </div>
  )
}