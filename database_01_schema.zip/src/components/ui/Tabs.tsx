﻿'use client'

import React, { createContext, useContext, forwardRef, HTMLAttributes, useState } from 'react'
import { cn } from '@/utils/cn'

interface TabsContextType {
  value: string
  onValueChange: (value: string) => void
}

const TabsContext = createContext<TabsContextType | undefined>(undefined)

function useTabsContext() {
  const ctx = useContext(TabsContext)
  if (!ctx) throw new Error('Tabs components must be used inside <Tabs>')
  return ctx
}

interface TabsProps {
  defaultValue: string
  onValueChange?: (value: string) => void
  children: React.ReactNode
  className?: string
  variant?: 'default' | 'underline' | 'pills'
}

interface TabsListProps extends HTMLAttributes<HTMLDivElement> {
  children: React.ReactNode
}

interface TabsTriggerProps extends HTMLAttributes<HTMLButtonElement> {
  value: string
  disabled?: boolean
}

interface TabsContentProps extends HTMLAttributes<HTMLDivElement> {
  value: string
}

export function Tabs({ defaultValue, onValueChange, children, className }: TabsProps) {
  const [value, setValue] = useState(defaultValue)

  const handleChange = (newValue: string) => {
    setValue(newValue)
    onValueChange?.(newValue)
  }

  return (
    <TabsContext.Provider value={{ value, onValueChange: handleChange }}>
      <div className={cn('w-full', className)}>{children}</div>
    </TabsContext.Provider>
  )
}

export const TabsList = forwardRef<HTMLDivElement, TabsListProps>(
  ({ className, children, ...props }, ref) => (
    <div
      ref={ref}
      className={cn(
        'flex gap-1 p-1 bg-gray-100 dark:bg-gray-800 rounded-xl',
        className
      )}
      role="tablist"
      {...props}
    >
      {children}
    </div>
  )
)
TabsList.displayName = 'TabsList'

export const TabsTrigger = forwardRef<HTMLButtonElement, TabsTriggerProps>(
  ({ className, value, disabled, children, ...props }, ref) => {
    const { value: activeValue, onValueChange } = useTabsContext()
    const isActive = activeValue === value

    return (
      <button
        ref={ref}
        type="button"
        role="tab"
        aria-selected={isActive}
        aria-disabled={disabled}
        disabled={disabled}
        className={cn(
          'flex-1 px-4 py-2.5 text-sm font-medium rounded-lg',
          'transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-primary-500',
          isActive
            ? 'bg-white dark:bg-gray-900 shadow-sm text-primary-600 dark:text-primary-400'
            : 'text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-gray-100',
          disabled && 'opacity-50 cursor-not-allowed',
          className
        )}
        data-state={isActive ? 'active' : 'inactive'}
        onClick={() => !disabled && onValueChange(value)}
        {...props}
      >
        {children}
      </button>
    )
  }
)
TabsTrigger.displayName = 'TabsTrigger'

export const TabsContent = forwardRef<HTMLDivElement, TabsContentProps>(
  ({ className, value, children, ...props }, ref) => {
    const { value: activeValue } = useTabsContext()

    if (activeValue !== value) return null

    return (
      <div
        ref={ref}
        className={cn('mt-4', className)}
        role="tabpanel"
        {...props}
      >
        {children}
      </div>
    )
  }
)
TabsContent.displayName = 'TabsContent'
