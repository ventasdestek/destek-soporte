'use client'

import React, { forwardRef, HTMLAttributes, useId } from 'react'
import { cn } from '@/utils/cn'

interface RadioGroupProps {
  value?: string
  onValueChange?: (value: string) => void
  children: React.ReactNode
  className?: string
  orientation?: 'horizontal' | 'vertical'
  name?: string
}

interface RadioGroupItemProps extends React.InputHTMLAttributes<HTMLInputElement> {
  value: string
  label: string
  description?: string
  disabled?: boolean
}

export function RadioGroup({ value, onValueChange, children, className, orientation = 'vertical', name }: RadioGroupProps) {
  const generatedId = useId()
  const groupName = name || generatedId

  return (
    <div
      className={cn(
        'space-y-3',
        orientation === 'horizontal' && 'flex flex-wrap gap-4',
        className
      )}
      role="radiogroup"
      aria-orientation={orientation}
    >
      {React.Children.map(children, (child) => {
        if (React.isValidElement(child)) {
          return React.cloneElement(child, { name: groupName, checked: child.props.value === value, onChange: () => onValueChange?.(child.props.value) })
        }
        return child
      })}
    </div>
  )
}

export const RadioGroupItem = forwardRef<HTMLInputElement, RadioGroupItemProps>(
  ({ className, value, label, description, disabled, name, checked, onChange, ...props }, ref) => {
    const itemId = useId()

    return (
      <label className={cn('flex items-start gap-3 cursor-pointer', className)}>
        <input
          ref={ref}
          type="radio"
          name={name}
          value={value}
          checked={checked}
          onChange={onChange}
          disabled={disabled}
          className={cn(
            'mt-1 h-4 w-4 appearance-none',
            'border-gray-300 text-primary-600',
            'focus:outline-none focus:ring-2 focus:ring-primary-500 focus:ring-offset-2',
            'disabled:opacity-50 disabled:cursor-not-allowed',
            'transition-colors duration-200'
          )}
          id={itemId}
          {...props}
        />
        <div className="flex flex-col">
          <span className={cn(
            'text-sm font-medium',
            disabled ? 'text-gray-400 dark:text-gray-500' : 'text-gray-900 dark:text-gray-100'
          )}>
            {label}
          </span>
          {description && (
            <span className="text-sm text-gray-500 dark:text-gray-400">
              {description}
            </span>
          )}
        </div>
      </label>
    )
  }
)

RadioGroupItem.displayName = 'RadioGroupItem'