'use client'

import { forwardRef, HTMLAttributes } from 'react'
import { cn } from '@/utils/cn'

export interface AvatarProps extends HTMLAttributes<HTMLDivElement> {
  src?: string | null
  alt?: string
  name?: string
  size?: 'xs' | 'sm' | 'md' | 'lg' | 'xl' | '2xl'
  shape?: 'circle' | 'square'
}

function getInitials(name: string) {
  return name
    .split(' ')
    .map((part) => part[0])
    .join('')
    .toUpperCase()
    .slice(0, 2)
}

export const Avatar = forwardRef<HTMLDivElement, AvatarProps>(
  ({ className, src, alt, name, size = 'md', shape = 'circle', ...props }, ref) => {
    const sizes = {
      xs: 'w-6 h-6 text-xs',
      sm: 'w-8 h-8 text-sm',
      md: 'w-10 h-10 text-base',
      lg: 'w-12 h-12 text-lg',
      xl: 'w-16 h-16 text-xl',
      '2xl': 'w-24 h-24 text-2xl',
    }

    const shapes = {
      circle: 'rounded-full',
      square: 'rounded-xl',
    }

    const fallbackColorClasses = [
      'bg-primary-100 text-primary-700 dark:bg-primary-900 dark:text-primary-300',
      'bg-accent-100 text-accent-700 dark:bg-accent-900 dark:text-accent-300',
      'bg-purple-100 text-purple-700 dark:bg-purple-900 dark:text-purple-300',
      'bg-pink-100 text-pink-700 dark:bg-pink-900 dark:text-pink-300',
      'bg-orange-100 text-orange-700 dark:bg-orange-900 dark:text-orange-300',
      'bg-cyan-100 text-cyan-700 dark:bg-cyan-900 dark:text-cyan-300',
    ]

    // Generar color consistente basado en el nombre
    const getColorClass = (name: string) => {
      let hash = 0
      for (let i = 0; i < name.length; i++) {
        hash = name.charCodeAt(i) + ((hash << 5) - hash)
      }
      return fallbackColorClasses[Math.abs(hash) % fallbackColorClasses.length]
    }

    return (
      <div
        ref={ref}
        className={cn(
          'inline-flex items-center justify-center font-medium overflow-hidden',
          'bg-gray-100 text-gray-600 dark:bg-gray-700 dark:text-gray-400',
          sizes[size],
          shapes[shape],
          className
        )}
        {...props}
      >
        {src ? (
          <img
            src={src}
            alt={alt || name || 'Avatar'}
            className="w-full h-full object-cover"
            onError={(e) => {
              e.currentTarget.style.display = 'none'
            }}
          />
        ) : name ? (
          <span className={getColorClass(name)}>{getInitials(name)}</span>
        ) : (
          <svg
            className="w-1/2 h-1/2 text-gray-400 dark:text-gray-500"
            fill="none"
            stroke="currentColor"
            viewBox="0 0 24 24"
            aria-hidden="true"
          >
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth={1.5}
              d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"
            />
          </svg>
        )}
      </div>
    )
  }
)

Avatar.displayName = 'Avatar'