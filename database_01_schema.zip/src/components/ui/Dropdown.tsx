'use client'

import { forwardRef, ReactNode, useState, useRef, useEffect } from 'react'
import { cn } from '@/utils/cn'
import { ChevronDown, X } from 'lucide-react'

export interface DropdownProps {
  trigger: ReactNode
  content: ReactNode
  align?: 'left' | 'right'
}

export function Dropdown({ trigger, content, align = 'right' }: DropdownProps) {
  const [open, setOpen] = useState(false)
  const dropdownRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setOpen(false)
      }
    }

    document.addEventListener('mousedown', handleClickOutside)
    return () => document.removeEventListener('mousedown', handleClickOutside)
  }, [])

  return (
    <div ref={dropdownRef} className="relative inline-block">
      <div onClick={() => setOpen(!open)} className="cursor-pointer">
        {trigger}
      </div>

      {open && (
        <div
          className={cn(
            'fixed z-50 mt-2 min-w-[180px] bg-white dark:bg-gray-800 rounded-xl shadow-elevated',
            'border border-gray-200 dark:border-gray-700',
            'animate-fade-in',
            align === 'right' ? 'right-0' : 'left-0'
          )}
          role="menu"
        >
          <div className="py-1">{content}</div>
        </div>
      )}
    </div>
  )
}

export interface DropdownItemProps {
  onClick?: () => void
  className?: string
  children: ReactNode
  destructive?: boolean
  icon?: ReactNode
}

export const DropdownItem = forwardRef<HTMLButtonElement, DropdownItemProps>(
  ({ className, children, onClick, destructive, icon, ...props }, ref) => (
    <button
      ref={ref}
      type="button"
      onClick={() => {
        onClick?.()
      }}
      className={cn(
        'w-full px-4 py-2.5 text-sm flex items-center gap-3',
        'text-gray-700 dark:text-gray-300',
        'hover:bg-gray-100 dark:hover:bg-gray-700',
        'transition-colors duration-150',
        destructive && 'text-red-600 dark:text-red-400 hover:bg-red-50 dark:hover:bg-red-950',
        className
      )}
      role="menuitem"
      {...props}
    >
      {icon}
      {children}
    </button>
  )
)
DropdownItem.displayName = 'DropdownItem'

export const DropdownDivider = () => (
  <hr className="my-1 border-gray-200 dark:border-gray-700" role="separator" />
)

export const DropdownHeader = ({ children }: { children: ReactNode }) => (
  <div className="px-4 py-2 text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wider">
    {children}
  </div>
)