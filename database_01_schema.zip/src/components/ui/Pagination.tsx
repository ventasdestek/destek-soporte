'use client'

import { cn } from '@/utils/cn'
import { ChevronLeft, ChevronRight, ChevronFirst, ChevronLast } from 'lucide-react'
import { Button } from './Button'

interface PaginationProps {
  currentPage: number
  totalPages: number
  onPageChange: (page: number) => void
  showFirstLast?: boolean
  showPageNumbers?: boolean
  maxPageNumbers?: number
  className?: string
}

export function Pagination({
  currentPage,
  totalPages,
  onPageChange,
  showFirstLast = true,
  showPageNumbers = true,
  maxPageNumbers = 5,
  className,
}: PaginationProps) {
  if (totalPages <= 1) return null

  const pages = getPageNumbers(currentPage, totalPages, maxPageNumbers)

  return (
    <nav
      className={cn('flex items-center justify-center gap-2', className)}
      aria-label="Paginación"
    >
      {/* Primera página */}
      {showFirstLast && (
        <Button
          variant="outline"
          size="sm"
          onClick={() => onPageChange(1)}
          disabled={currentPage === 1}
          aria-label="Primera página"
        >
          <ChevronFirst className="w-4 h-4" />
        </Button>
      )}

      {/* Página anterior */}
      <Button
        variant="outline"
        size="sm"
        onClick={() => onPageChange(currentPage - 1)}
        disabled={currentPage === 1}
        aria-label="Página anterior"
      >
        <ChevronLeft className="w-4 h-4" />
      </Button>

      {/* Números de página */}
      {showPageNumbers && (
        <div className="flex items-center gap-1" role="navigation" aria-label="Números de página">
          {pages.map((page, index) => {
            if (page === '...') {
              return (
                <span key={`ellipsis-${index}`} className="px-2 text-gray-500 dark:text-gray-400">
                  ...
                </span>
              )
            }

            return (
              <Button
                key={page}
                variant={page === currentPage ? 'primary' : 'ghost'}
                size="sm"
                onClick={() => onPageChange(page)}
                aria-label={`Página ${page}`}
                aria-current={page === currentPage ? 'page' : undefined}
              >
                {page}
              </Button>
            )
          })}
        </div>
      )}

      {/* Página siguiente */}
      <Button
        variant="outline"
        size="sm"
        onClick={() => onPageChange(currentPage + 1)}
        disabled={currentPage === totalPages}
        aria-label="Página siguiente"
      >
        <ChevronRight className="w-4 h-4" />
      </Button>

      {/* Última página */}
      {showFirstLast && (
        <Button
          variant="outline"
          size="sm"
          onClick={() => onPageChange(totalPages)}
          disabled={currentPage === totalPages}
          aria-label="Última página"
        >
          <ChevronLast className="w-4 h-4" />
        </Button>
      )}
    </nav>
  )
}

function getPageNumbers(currentPage: number, totalPages: number, maxPages: number): (number | '...')[] {
  if (totalPages <= maxPages) {
    return Array.from({ length: totalPages }, (_, i) => i + 1)
  }

  const half = Math.floor(maxPages / 2)
  let start = Math.max(1, currentPage - half)
  const end = Math.min(totalPages, start + maxPages - 1)

  if (end - start + 1 < maxPages) {
    start = Math.max(1, end - maxPages + 1)
  }

  const pages: (number | '...')[] = []

  // Primera página
  pages.push(1)

  // Ellipsis al inicio
  if (start > 2) {
    pages.push('...')
  } else if (start === 2) {
    pages.push(2)
  }

  // Páginas centrales
  for (let i = start; i <= end; i++) {
    if (i !== 1 && i !== totalPages) {
      pages.push(i)
    }
  }

  // Ellipsis al final
  if (end < totalPages - 1) {
    pages.push('...')
  } else if (end === totalPages - 1) {
    pages.push(totalPages)
  }

  // Última página
  if (totalPages > 1) {
    pages.push(totalPages)
  }

  return pages
}