'use client'

import { createContext, useContext, useEffect, useCallback, useSyncExternalStore, ReactNode } from 'react'

type Theme = 'light' | 'dark' | 'system'
type ResolvedTheme = 'light' | 'dark'

interface ThemeContextType {
  theme: Theme
  resolvedTheme: ResolvedTheme
  setTheme: (theme: Theme) => void
}

const ThemeContext = createContext<ThemeContextType | undefined>(undefined)
const STORAGE_KEY = 'theme'

const listeners = new Set<() => void>()
const mediaQuery = typeof window !== 'undefined' ? window.matchMedia('(prefers-color-scheme: dark)') : null

function emit() {
  listeners.forEach((l) => l())
}

function subscribe(listener: () => void) {
  listeners.add(listener)
  mediaQuery?.addEventListener('change', emit)
  return () => {
    listeners.delete(listener)
    mediaQuery?.removeEventListener('change', emit)
  }
}

function getStoredTheme(): Theme {
  if (typeof window === 'undefined') return 'system'
  const stored = window.localStorage.getItem(STORAGE_KEY)
  return stored === 'light' || stored === 'dark' || stored === 'system' ? stored : 'system'
}

function getResolvedTheme(theme: Theme): ResolvedTheme {
  if (theme !== 'system' || !mediaQuery) return theme === 'dark' ? 'dark' : 'light'
  return mediaQuery.matches ? 'dark' : 'light'
}

export function ThemeProvider({ children, defaultTheme = 'system' }: { children: ReactNode; defaultTheme?: Theme }) {
  const theme = useSyncExternalStore(subscribe, getStoredTheme, () => defaultTheme)
  const resolvedTheme = useSyncExternalStore(
    subscribe,
    () => getResolvedTheme(theme),
    () => getResolvedTheme(defaultTheme)
  )

  useEffect(() => {
    if (typeof window === 'undefined') return
    const root = window.document.documentElement
    root.classList.remove('light', 'dark')
    root.classList.add(resolvedTheme)
    window.localStorage.setItem(STORAGE_KEY, theme)
  }, [theme, resolvedTheme])

  const setTheme = useCallback((next: Theme) => {
    if (typeof window !== 'undefined') {
      window.localStorage.setItem(STORAGE_KEY, next)
    }
    emit()
  }, [])

  return (
    <ThemeContext.Provider value={{ theme, resolvedTheme, setTheme }}>
      {children}
    </ThemeContext.Provider>
  )
}

export function useTheme() {
  const context = useContext(ThemeContext)
  if (!context) {
    throw new Error('useTheme debe usarse dentro de ThemeProvider')
  }
  return context
}