'use client'

import { useState, useEffect } from 'react'
import Link from 'next/link'
import { usePathname, useRouter } from 'next/navigation'
import { Menu, X, Sun, Moon, Monitor } from 'lucide-react'
import { cn } from '@/utils/cn'
import { Button } from '@/components/ui'
import { Dropdown, DropdownItem, DropdownDivider, DropdownHeader } from '@/components/ui'
import { useAuth } from '@/components/providers/AuthProvider'
import { useTheme } from '@/components/providers/ThemeProvider'
import { ROUTES } from '@/lib/constants'
import { Separator } from '@/components/ui'

const navigation = [
  { name: 'Servicios', href: ROUTES.servicios },
  { name: 'Productos', href: ROUTES.productos },
  { name: 'Nosotros', href: ROUTES.nosotros },
  { name: 'Contacto', href: ROUTES.contacto },
]

export function Navbar() {
  const pathname = usePathname()
  const router = useRouter()
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false)
  const [scrolled, setScrolled] = useState(false)
  const { user, signOut, loading } = useAuth()
  const { theme, resolvedTheme, setTheme } = useTheme()

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 20)
    }
    handleScroll()
    window.addEventListener('scroll', handleScroll, { passive: true })
    return () => window.removeEventListener('scroll', handleScroll)
  }, [])

  const toggleTheme = () => {
    if (theme === 'system') {
      setTheme(resolvedTheme === 'dark' ? 'light' : 'dark')
    } else {
      setTheme(theme === 'dark' ? 'light' : 'dark')
    }
  }

  return (
    <header
      className={cn(
        'fixed top-0 left-0 right-0 z-40 transition-all duration-300',
        scrolled
          ? 'bg-white/95 dark:bg-gray-900/95 backdrop-blur-md shadow-card border-b border-gray-200 dark:border-gray-800'
          : 'bg-transparent'
      )}
    >
      <nav className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8" aria-label="Navegación principal">
        <div className="flex h-16 items-center justify-between">
          <div className="flex-shrink-0">
            <Link href={ROUTES.home} className="flex items-center gap-2" aria-label="Destek Soporte - Inicio">
              <div className="w-10 h-10 rounded-xl bg-primary-600 flex items-center justify-center">
                <Monitor className="w-6 h-6 text-white" aria-hidden="true" />
              </div>
              <span className="font-heading font-bold text-xl text-gray-900 dark:text-white hidden sm:block">
                Destek Soporte
              </span>
            </Link>
          </div>

          <div className="hidden md:flex md:items-center md:gap-8">
            {navigation.map((item) => (
              <Link
                key={item.name}
                href={item.href}
                className={cn(
                  'text-sm font-medium transition-colors duration-200 relative',
                  'hover:text-primary-600 dark:hover:text-primary-400',
                  pathname === item.href || pathname.startsWith(item.href + '/')
                    ? 'text-primary-600 dark:text-primary-400'
                    : 'text-gray-700 dark:text-gray-300'
                )}
              >
                {item.name}
                {(pathname === item.href || pathname.startsWith(item.href + '/')) && (
                  <span className="absolute bottom-[-8px] left-1/2 -translate-x-1/2 w-1.5 h-1.5 rounded-full bg-primary-600" aria-hidden="true" />
                )}
              </Link>
            ))}
          </div>

          <div className="hidden md:flex md:items-center md:gap-4">
            <Button
              variant="ghost"
              size="sm"
              onClick={toggleTheme}
              aria-label={`Tema actual: ${theme}. Click para cambiar.`}
              className="relative"
            >
              {theme === 'system' ? (
                <> <Monitor className="w-5 h-5" aria-hidden="true" /> <span className="sr-only">Sistema</span> </>
              ) : resolvedTheme === 'dark' ? (
                <> <Moon className="w-5 h-5" aria-hidden="true" /> <span className="sr-only">Oscuro</span> </>
              ) : (
                <> <Sun className="w-5 h-5" aria-hidden="true" /> <span className="sr-only">Claro</span> </>
              )}
            </Button>

            {loading ? (
              <Button variant="ghost" size="sm" disabled>
                <span className="w-5 h-5" aria-hidden="true">⏳</span>
              </Button>
            ) : user ? (
              <Dropdown
                trigger={
                  <Button variant="ghost" size="sm" className="gap-2">
                    <div className="w-8 h-8 rounded-full bg-primary-100 dark:bg-primary-900 flex items-center justify-center">
                      {user.email?.charAt(0).toUpperCase()}
                    </div>
                    <span className="hidden lg:block text-sm font-medium text-gray-700 dark:text-gray-300">
                      {user.user_metadata?.nombre || user.email?.split('@')[0]}
                    </span>
                  </Button>
                }
                content={
                  <>
                    <DropdownHeader>Cuenta</DropdownHeader>
                    <DropdownItem onClick={() => window.location.href = ROUTES.dashboard}>
                      <span className="flex items-center gap-2"><span className="w-5 h-5">📊</span> Dashboard</span>
                    </DropdownItem>
                    <DropdownItem onClick={() => window.location.href = ROUTES.perfil}>
                      <span className="flex items-center gap-2"><span className="w-5 h-5">👤</span> Mi Perfil</span>
                    </DropdownItem>
                    <DropdownItem onClick={() => window.location.href = ROUTES.misSolicitudes}>
                      <span className="flex items-center gap-2"><span className="w-5 h-5">📋</span> Mis Solicitudes</span>
                    </DropdownItem>
                    {user.user_metadata?.role === 'admin' && (
                      <>
                        <DropdownDivider />
                        <DropdownHeader>Administración</DropdownHeader>
                        <DropdownItem onClick={() => window.location.href = ROUTES.admin}>
                          <span className="flex items-center gap-2"><span className="w-5 h-5">⚙️</span> Panel Admin</span>
                        </DropdownItem>
                      </>
                    )}
                    <DropdownDivider />
                    <DropdownItem onClick={async () => { await signOut(); router.push(ROUTES.login) }} destructive>
                      <span className="flex items-center gap-2"><span className="w-5 h-5">🚪</span> Cerrar Sesión</span>
                    </DropdownItem>
                  </>
                }
              />
            ) : (
              <div className="flex items-center gap-3">
                <Link href={ROUTES.login}><Button variant="ghost" size="sm">Iniciar Sesión</Button></Link>
                <Link href={ROUTES.registro}><Button size="sm">Registrarse</Button></Link>
              </div>
            )}
          </div>

          <div className="flex md:hidden items-center gap-2">
            <Button variant="ghost" size="sm" onClick={toggleTheme} aria-label={`Tema actual: ${theme}. Click para cambiar.`}>
              {theme === 'system' ? <Monitor className="w-5 h-5" /> : resolvedTheme === 'dark' ? <Moon className="w-5 h-5" /> : <Sun className="w-5 h-5" />}
            </Button>
            <Button variant="ghost" size="sm" onClick={() => setMobileMenuOpen(!mobileMenuOpen)} aria-label={mobileMenuOpen ? 'Cerrar menú' : 'Abrir menú'} aria-expanded={mobileMenuOpen}>
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </Button>
          </div>
        </div>

        {mobileMenuOpen && (
          <div className="md:hidden py-4 border-t border-gray-200 dark:border-gray-700 animate-slide-down">
            <div className="flex flex-col gap-4">
              {navigation.map((item) => (
                <Link
                  key={item.name}
                  href={item.href}
                  onClick={() => setMobileMenuOpen(false)}
                  className={cn(
                    'px-2 py-2 text-base font-medium rounded-lg transition-colors',
                    pathname === item.href || pathname.startsWith(item.href + '/')
                      ? 'bg-primary-50 text-primary-600 dark:bg-primary-950 dark:text-primary-400'
                      : 'text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-800'
                  )}
                >
                  {item.name}
                </Link>
              ))}

              <Separator className="my-2" />

              {!loading && !user ? (
                <div className="flex flex-col gap-2">
                  <Link href={ROUTES.login} onClick={() => setMobileMenuOpen(false)}>
                    <Button variant="outline" className="w-full justify-center">Iniciar Sesión</Button>
                  </Link>
                  <Link href={ROUTES.registro} onClick={() => setMobileMenuOpen(false)}>
                    <Button className="w-full justify-center">Registrarse</Button>
                  </Link>
                </div>
              ) : user ? (
                <div className="flex flex-col gap-2">
                  <Link href={ROUTES.dashboard} onClick={() => setMobileMenuOpen(false)}>
                    <Button variant="outline" className="w-full justify-start gap-3"><span className="w-5 h-5">📊</span> Dashboard</Button>
                  </Link>
                  <Link href={ROUTES.perfil} onClick={() => setMobileMenuOpen(false)}>
                    <Button variant="outline" className="w-full justify-start gap-3"><span className="w-5 h-5">👤</span> Mi Perfil</Button>
                  </Link>
                  <Link href={ROUTES.misSolicitudes} onClick={() => setMobileMenuOpen(false)}>
                    <Button variant="outline" className="w-full justify-start gap-3"><span className="w-5 h-5">📋</span> Mis Solicitudes</Button>
                  </Link>
                  {user.user_metadata?.role === 'admin' && (
                    <Link href={ROUTES.admin} onClick={() => setMobileMenuOpen(false)}>
                      <Button variant="outline" className="w-full justify-start gap-3"><span className="w-5 h-5">⚙️</span> Panel Admin</Button>
                    </Link>
                  )}
                  <Button variant="outline" onClick={async () => { await signOut(); router.push(ROUTES.login) }} className="w-full justify-start gap-3 text-red-600 dark:text-red-400 border-red-200 dark:border-red-900 hover:bg-red-50 dark:hover:bg-red-950"><span className="w-5 h-5">🚪</span> Cerrar Sesión</Button>
                </div>
              ) : (
                <div className="flex justify-center py-4"><Button variant="outline" disabled className="w-full">Cargando...</Button></div>
              )}
            </div>
          </div>
        )}
      </nav>
    </header>
  )
}