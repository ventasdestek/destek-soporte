'use client'

import Link from 'next/link'
import { cn } from '@/utils/cn'
import { Monitor, Mail, Phone, MapPin, Facebook, Twitter, Instagram, Linkedin, ArrowUpRight } from 'lucide-react'
import { ROUTES } from '@/lib/constants'

const footerLinks = {
  servicios: [
    { name: 'Reparación PC', href: `${ROUTES.servicios}#reparacion-pc` },
    { name: 'Mantenimiento', href: `${ROUTES.servicios}#mantenimiento` },
    { name: 'Redes y WiFi', href: `${ROUTES.servicios}#redes-wifi` },
    { name: 'Seguridad', href: `${ROUTES.servicios}#seguridad` },
    { name: 'Recuperación Datos', href: `${ROUTES.servicios}#recuperacion-datos` },
    { name: 'Asesoría IT', href: `${ROUTES.servicios}#asesoria-it` },
  ],
  empresa: [
    { name: 'Nosotros', href: ROUTES.nosotros },
    { name: 'Blog', href: ROUTES.blog },
    { name: 'Trabaja con nosotros', href: ROUTES.trabajo },
    { name: 'Política de privacidad', href: ROUTES.privacidad },
    { name: 'Términos y condiciones', href: ROUTES.terminos },
    { name: 'Cookies', href: ROUTES.cookies },
  ],
  soporte: [
    { name: 'Centro de ayuda', href: ROUTES.ayuda },
    { name: 'Preguntas frecuentes', href: ROUTES.faq },
    { name: 'Contacto', href: ROUTES.contacto },
    { name: 'Estado del sistema', href: ROUTES.estado },
    { name: 'API Docs', href: ROUTES.api },
  ],
}

const socialLinks = [
  { name: 'Facebook', icon: Facebook, href: 'https://facebook.com/desteksoporte', ariaLabel: 'Síguenos en Facebook' },
  { name: 'Twitter', icon: Twitter, href: 'https://twitter.com/desteksoporte', ariaLabel: 'Síguenos en Twitter' },
  { name: 'Instagram', icon: Instagram, href: 'https://instagram.com/desteksoporte', ariaLabel: 'Síguenos en Instagram' },
  { name: 'LinkedIn', icon: Linkedin, href: 'https://linkedin.com/company/desteksoporte', ariaLabel: 'Síguenos en LinkedIn' },
]

const contactInfo = [
  { icon: MapPin, text: 'Calle Mayor 123, 28001 Madrid, España' },
  { icon: Phone, text: '+34 900 123 456', href: 'tel:+34900123456' },
  { icon: Mail, text: 'soporte@destek.es', href: 'mailto:soporte@destek.es' },
]

export function Footer() {
  const currentYear = new Date().getFullYear()

  return (
    <footer className="bg-gray-50 dark:bg-gray-950 border-t border-gray-200 dark:border-gray-800">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-12">
          <div className="lg:col-span-2 space-y-6">
            <Link href={ROUTES.home} className="flex items-center gap-2" aria-label="Destek Soporte - Inicio">
              <div className="w-12 h-12 rounded-xl bg-primary-600 flex items-center justify-center">
                <Monitor className="w-7 h-7 text-white" aria-hidden="true" />
              </div>
              <span className="font-heading font-bold text-2xl text-gray-900 dark:text-white">
                Destek Soporte
              </span>
            </Link>
            <p className="text-gray-600 dark:text-gray-400 text-base leading-relaxed max-w-xs">
              Tu partner tecnológico de confianza. Ofrecemos soluciones IT integrales para empresas y particulares.
            </p>
            <div className="flex gap-4">
              {socialLinks.map((social) => (
                <a
                  key={social.name}
                  href={social.href}
                  target="_blank"
                  rel="noopener noreferrer"
                  aria-label={social.ariaLabel}
                  className={cn(
                    'w-10 h-10 rounded-lg flex items-center justify-center transition-all duration-200',
                    'bg-gray-100 dark:bg-gray-800 text-gray-600 dark:text-gray-400',
                    'hover:bg-primary-100 dark:hover:bg-primary-900 hover:text-primary-600 dark:hover:text-primary-400'
                  )}
                >
                  <social.icon className="w-5 h-5" aria-hidden="true" />
                </a>
              ))}
            </div>
          </div>

          <nav aria-label="Servicios">
            <h3 className="font-semibold text-gray-900 dark:text-white mb-4">Servicios</h3>
            <ul className="space-y-3">
              {footerLinks.servicios.map((link) => (
                <li key={link.name}>
                  <Link
                    href={link.href}
                    className="text-gray-600 dark:text-gray-400 hover:text-primary-600 dark:hover:text-primary-400 transition-colors text-sm"
                  >
                    {link.name}
                  </Link>
                </li>
              ))}
            </ul>
          </nav>

          <nav aria-label="Empresa">
            <h3 className="font-semibold text-gray-900 dark:text-white mb-4">Empresa</h3>
            <ul className="space-y-3">
              {footerLinks.empresa.map((link) => (
                <li key={link.name}>
                  <Link
                    href={link.href}
                    className="text-gray-600 dark:text-gray-400 hover:text-primary-600 dark:hover:text-primary-400 transition-colors text-sm"
                  >
                    {link.name}
                  </Link>
                </li>
              ))}
            </ul>
          </nav>
<nav aria-label="Soporte">
            <h3 className="font-semibold text-gray-900 dark:text-white mb-4">Soporte</h3>
            <ul className="space-y-3">
              {footerLinks.soporte.map((link) => (
                <li key={link.name}>
                  <Link
                    href={link.href}
                    className="text-gray-600 dark:text-gray-400 hover:text-primary-600 dark:hover:text-primary-400 transition-colors text-sm"
                  >
                    {link.name}
                  </Link>
                </li>
              ))}
            </ul>
          </nav>

          <div className="space-y-6">
            <h3 className="font-semibold text-gray-900 dark:text-white mb-4">Contacto</h3>
            <address className="not-italic space-y-4">
              {contactInfo.map((item, index) => (
                <div key={index} className="flex items-start gap-3">
                  <div className={cn(
                    'w-8 h-8 rounded-lg flex items-center justify-center flex-shrink-0',
                    'bg-primary-100 dark:bg-primary-900 text-primary-600 dark:text-primary-400'
                  )}>
                    <item.icon className="w-4 h-4" aria-hidden="true" />
                  </div>
                  <div>
                    {item.href ? (
                      <a
                        href={item.href}
                        className="text-gray-600 dark:text-gray-400 hover:text-primary-600 dark:hover:text-primary-400 transition-colors text-sm"
                      >
                        {item.text}
                      </a>
                    ) : (
                      <p className="text-gray-600 dark:text-gray-400 text-sm">{item.text}</p>
                    )}
                  </div>
                </div>
              ))}
            </address>
            <Link
              href={ROUTES.contacto}
              className="inline-flex items-center gap-2 text-primary-600 dark:text-primary-400 hover:text-primary-700 dark:hover:text-primary-300 font-medium text-sm transition-colors"
            >
              Más formas de contactar
              <ArrowUpRight className="w-4 h-4" aria-hidden="true" />
            </Link>
          </div>
        </div>

        <div className="mt-12 pt-8 border-t border-gray-200 dark:border-gray-800">
          <div className="flex flex-col md:flex-row items-center justify-between gap-4">
            <p className="text-gray-500 dark:text-gray-500 text-sm">
              © {currentYear} Destek Soporte. Todos los derechos reservados.
            </p>
            <div className="flex items-center gap-6 text-sm text-gray-500 dark:text-gray-500">
              <Link
                href={ROUTES.privacidad}
                className="hover:text-primary-600 dark:hover:text-primary-400 transition-colors"
              >
                Privacidad
              </Link>
              <Link
                href={ROUTES.terminos}
                className="hover:text-primary-600 dark:hover:text-primary-400 transition-colors"
              >
                Términos
              </Link>
              <Link
                href={ROUTES.cookies}
                className="hover:text-primary-600 dark:hover:text-primary-400 transition-colors"
              >
                Cookies
              </Link>
            </div>
          </div>
        </div>
      </div>
    </footer>
  )
}